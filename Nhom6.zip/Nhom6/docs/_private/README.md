# 🔒 Private Docs — Không push lên Git

Thư mục này được thiết lập trong `.gitignore` — mọi nội dung bên trong chỉ nằm trên máy cục bộ của bạn, không bao giờ bị đẩy lên remote repo.

## 📂 Cấu trúc gợi ý

```text
_private/
├── notes/       ← Ghi chú cá nhân, mẹo debug, thông tin cấu hình local
└── drafts/      ← Bản nháp doc / task trước khi hoàn thiện đưa vào docs chính thức
```

## 👥 Quy ước

Mọi thành viên đều có thể dùng `docs/_private/` trên máy mình để lưu ghi chú riêng. Thư mục này không làm bẩn git status hay ảnh hưởng đến thành viên khác.
