-- =============================================================================
--  WEB ĐỌC TRUYỆN — Lược đồ cơ sở dữ liệu
-- =============================================================================
--  Chạy file này MỘT LẦN để tạo database và toàn bộ bảng.
--  Xem README.md phần "Cài đặt database" để biết lệnh chạy.
-- =============================================================================

DROP DATABASE IF EXISTS webdoctruyen;
CREATE DATABASE webdoctruyen
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;
-- utf8mb4 chứ KHÔNG phải utf8: bảng mã "utf8" của MySQL chỉ chứa được 3 byte,
-- không đủ cho emoji. Truyện và bình luận chắc chắn sẽ có emoji.
-- Collation _unicode_ci: so sánh không phân biệt hoa thường, sắp xếp đúng
-- tiếng Việt có dấu.

USE webdoctruyen;


-- =============================================================================
--  users — tài khoản
-- =============================================================================
--  CHỈ CÓ MỘT BẢNG NGƯỜI DÙNG, KHÔNG CÓ BẢNG "authors" RIÊNG.
--  "Tác giả" không phải một loại người — nó là quan hệ: ai đăng truyện thì là
--  tác giả của truyện đó (stories.author_id). Cùng một tài khoản vừa có thể
--  là tác giả truyện A, vừa là độc giả truyện B. Tách bảng là nhân đôi dữ liệu.
-- =============================================================================
CREATE TABLE users (
    id            INT AUTO_INCREMENT PRIMARY KEY,
    username      VARCHAR(50)  NOT NULL UNIQUE,
    email         VARCHAR(150) NOT NULL UNIQUE,

    -- Lưu chuỗi BĂM, tuyệt đối không lưu mật khẩu gốc.
    -- 255 ký tự để chứa thoải mái chuỗi băm BCrypt (60) hoặc dài hơn sau này.
    -- Cho phép NULL từ ISSUE-001 phase 1: tài khoản chỉ đăng nhập bằng Google
    -- thì KHÔNG CÓ mật khẩu để mà băm. NULL thể hiện đúng bản chất: chưa có mật khẩu.
    password_hash VARCHAR(255) NULL,

    display_name  VARCHAR(100),
    avatar_url    VARCHAR(1000),
    bio           VARCHAR(500),

    -- Chỉ hai vai trò. Không cần AUTHOR — xem ghi chú đầu bảng.
    role          ENUM('USER','ADMIN')      NOT NULL DEFAULT 'USER',

    -- BANNED phục vụ chức năng "admin ban tài khoản".
    -- Bị ban thì chặn đăng nhập, nhưng TRUYỆN VẪN GIỮ NGUYÊN — độc giả đang
    -- đọc dở không bị mất. Đây là quyết định thiết kế, không phải thiếu sót.
    status        ENUM('ACTIVE','BANNED')   NOT NULL DEFAULT 'ACTIVE',
    ban_reason    VARCHAR(255),

    created_at    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    vip_expire_at DATETIME NULL,

    INDEX idx_users_status (status)
) ENGINE=InnoDB;


-- =============================================================================
--  user_identities — tài khoản này đăng nhập được bằng những đường nào
-- =============================================================================
--  MỘT NGƯỜI, NHIỀU ĐƯỜNG VÀO. Cùng một tài khoản có thể vào bằng mật khẩu,
--  bằng Google, và sau này bằng đường khác nữa.
--
--  VÌ SAO KHÔNG NHÉT google_sub THÀNH MỘT CỘT TRONG users
--    Nhét cột thì mỗi nhà cung cấp mới là một cột mới, và 99% số dòng để rỗng.
--    Thêm Facebook là thêm facebook_id, thêm GitHub là thêm github_id — bảng
--    users phình ra vì thứ chẳng liên quan gì tới người dùng.
--    Bảng nối thì thêm nhà cung cấp chỉ là thêm một giá trị vào ENUM.
--
--  provider_uid LÀ sub CỦA GOOGLE, KHÔNG PHẢI EMAIL.
--    Người ta đổi được email trong tài khoản Google của họ. sub thì không đổi
--    bao giờ. Khoá theo email nghĩa là hôm nào họ đổi email là mất tài khoản.
--    Email vẫn lưu, nhưng chỉ để HIỂN THỊ, không dùng để tra.
-- =============================================================================
CREATE TABLE user_identities (
    id           INT AUTO_INCREMENT PRIMARY KEY,
    user_id      INT NOT NULL,

    -- Hiện chỉ có GOOGLE. ENUM để thêm nhà cung cấp sau chỉ là sửa một dòng.
    provider     ENUM('GOOGLE') NOT NULL,

    -- Định danh do nhà cung cấp cấp. Với Google là trường `sub` trong idToken.
    -- 255 vì Google không cam kết độ dài, chỉ cam kết không quá 255.
    provider_uid VARCHAR(255) NOT NULL,

    -- Email lúc gắn. CHỈ ĐỂ HIỂN THỊ ở trang hồ sơ — không tra cứu theo cột này.
    email        VARCHAR(150),

    created_at   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,

    -- Một tài khoản Google chỉ gắn được vào ĐÚNG MỘT tài khoản trên web.
    -- Ràng buộc ở CSDL chứ không chỉ ở code: hai request gửi cùng lúc thì
    -- code kiểm trước-rồi-chèn vẫn lọt cả hai, CSDL thì không.
    UNIQUE KEY uq_identity_provider (provider, provider_uid),

    -- Một tài khoản cũng chỉ gắn được MỘT tài khoản Google, không phải ba.
    UNIQUE KEY uq_identity_user (user_id, provider)
) ENGINE=InnoDB;


-- =============================================================================
--  stories — truyện
-- =============================================================================
CREATE TABLE stories (
    id           INT AUTO_INCREMENT PRIMARY KEY,
    title        VARCHAR(200) NOT NULL,

    -- slug: chuỗi thân thiện URL, ví dụ "dau-pha-thuong-khung".
    -- Dùng cho URL đẹp và để chia sẻ link. UNIQUE để không đụng nhau.
    slug         VARCHAR(220) NOT NULL UNIQUE,

    description  TEXT,
    cover_url    VARCHAR(1000),

    author_id    INT NOT NULL,

    -- DRAFT     : tác giả đang viết, chưa ai thấy
    -- PUBLISHED : hiện công khai
    -- DELETED   : admin đã gỡ — XOÁ MỀM, không xoá thật khỏi bảng.
    --             Xoá thật thì bình luận và bookmark trỏ tới nó sẽ mồ côi,
    --             phải xử lý dây chuyền rất mệt. Ẩn đi là đủ.
    status       ENUM('DRAFT','PUBLISHED','DELETED') NOT NULL DEFAULT 'DRAFT',

    -- ONGOING: đang ra chương;  COMPLETED: đã hoàn thành
    progress     ENUM('ONGOING','COMPLETED')         NOT NULL DEFAULT 'ONGOING',

    -- TEXT : truyện chữ — nội dung chương nằm ở chapters.content
    -- COMIC: truyện tranh — mỗi chương là một dãy ảnh trong chapter_pages
    -- Thêm loại mới: xem ghi chú đầu database/migration-028-story-type.sql
    story_type   ENUM('TEXT','COMIC')                NOT NULL DEFAULT 'TEXT',

    -- Đếm sẵn lượt xem thay vì COUNT() mỗi lần tải trang — nhanh hơn nhiều.
    view_count   INT NOT NULL DEFAULT 0,

    -- Điểm đánh giá, PHI CHUẨN HOÁ CÓ CHỦ Ý.
    --
    -- Điểm trung bình tính được từ bảng ratings bằng AVG(score). Nhưng lưới
    -- kho truyện hiện 24 truyện một trang, mỗi truyện một ngôi sao — làm đúng
    -- chuẩn là 24 câu AVG cho một lần tải trang.
    --
    -- Giữ sẵn TỔNG và SỐ LƯỢT, chia ra là có trung bình. Lưu tổng chứ không
    -- lưu thẳng trung bình: cộng thêm một điểm mới chỉ là sum+=score,
    -- count+=1. Lưu trung bình thì phải nhân ngược lại rồi chia, sai số dồn
    -- dần sau vài nghìn lượt.
    --
    -- CÁI GIÁ: hai chỗ phải cùng đúng. RatingDAO sửa cả hai trong MỘT
    -- transaction, không có đường nào khác chạm vào hai cột này.
    rating_sum   INT NOT NULL DEFAULT 0,
    rating_count INT NOT NULL DEFAULT 0,

    created_at   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
                          ON UPDATE CURRENT_TIMESTAMP,

    -- ON DELETE CASCADE: xoá hẳn user thì truyện đi theo.
    -- (Thực tế ta chỉ BAN chứ không xoá user, nên nhánh này hiếm khi chạy.)
    FOREIGN KEY (author_id) REFERENCES users(id) ON DELETE CASCADE,

    INDEX idx_stories_status  (status),
    INDEX idx_stories_author  (author_id),
    INDEX idx_stories_updated (updated_at),
    INDEX idx_stories_type    (status, story_type)
) ENGINE=InnoDB;


-- =============================================================================
--  chapters — chương truyện
-- =============================================================================
--  Nội dung chương lưu thẳng trong DB (kiểu TEXT), không lưu ra file.
--  Lý do: đọc online theo từng chương, và nút "Tải truyện" chỉ việc ghép các
--  chương lại thành .txt. Lưu ra file thì phải quản lý thêm đường dẫn, sao
--  lưu, và deploy lại là mất.
-- =============================================================================
CREATE TABLE chapters (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    story_id    INT NOT NULL,

    -- Số thứ tự chương trong truyện (1, 2, 3...). Không dùng id để sắp xếp
    -- vì tác giả có thể chèn chương vào giữa.
    chapter_no  INT NOT NULL,

    title       VARCHAR(200) NOT NULL,

    -- MEDIUMTEXT chứa tới 16 MB. TEXT thường chỉ 64 KB — một chương dài
    -- tiếng Việt có dấu rất dễ vượt, và MySQL sẽ CẮT CỤT âm thầm.
    content     MEDIUMTEXT NOT NULL,

    created_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
                         ON UPDATE CURRENT_TIMESTAMP,

    FOREIGN KEY (story_id) REFERENCES stories(id) ON DELETE CASCADE,

    -- Trong một truyện không được có hai chương cùng số.
    -- Ràng buộc ở DB chứ không chỉ ở code: code có thể quên, DB thì không.
    UNIQUE KEY uq_story_chapter (story_id, chapter_no)
,

    /*
      CHI MUC TOAN VAN — de tim kiem TRONG NOI DUNG chuong.

      VI SAO KHONG DUNG LIKE '%tu khoa%'
        LIKE bat dau bang dau % thi MySQL KHONG dung duoc index nao ca: no
        phai doc tung dong, tung ky tu. Voi cot TEXT chua ca chuong truyen,
        vai nghin chuong la vai chuc trieu ky tu cho MOI lan tim.

        FULLTEXT dung so do dao nguoc: no tach san moi tu ra va nho tu do
        nam o nhung dong nao. Tim mot tu la tra bang, khong phai quet bang.

      GIA PHAI TRA
        1. Ghi cham hon mot chut, vi moi lan them/sua chuong deu phai cap
           nhat chi muc. Doi lai doc nhanh hon nhieu bac — dung danh doi voi
           mot bang ma nguoi ta doc nhieu hon ghi rat nhieu.

        2. Chi muc chiem them dung luong dia, co khi bang ca du lieu goc.

        3. MySQL mac dinh BO QUA tu ngan hon 3 ky tu
           (innodb_ft_min_token_size = 3). Tieng Viet nhieu tu hai am tiet
           viet roi ("ha", "me", "cho") se khong tim duoc. Vi vay ChapterDAO
           tu chuyen sang LIKE khi tu khoa qua ngan — cham hon nhung ra ket
           qua, con hon tra ve rong ma khong giai thich duoc tai sao.

      CO CA title VA content: nguoi ta go "chuong cuoi" thi mong tim thay ten
      chuong, khong phai chi ruot truyen.
    */
    FULLTEXT INDEX ft_chapter_text (title, content)
) ENGINE=InnoDB;


-- =============================================================================
--  chapter_pages — ảnh từng trang của chương TRUYỆN TRANH
-- =============================================================================
--  Chương truyện chữ không có dòng nào ở đây. Chương truyện tranh để
--  chapters.content rỗng và đọc ảnh theo page_no. Xem migration-028.
-- =============================================================================
CREATE TABLE chapter_pages (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    chapter_id  INT NOT NULL,

    -- Thứ tự trang, đếm từ 1 — cũng là "para_no" khi đánh dấu / đọc tiếp.
    page_no     INT NOT NULL,

    -- Tương đối trong thư mục uploads: pages/{storyId}/{chapterId}/x.jpg.
    -- UploadedFileServlet kiểm quyền đọc chương trước khi phát ảnh pages/.
    image_path  VARCHAR(255) NOT NULL,

    -- Kích thước gốc — trang đọc giữ chỗ đúng tỉ lệ trước khi ảnh tải xong.
    width       INT NULL,
    height      INT NULL,

    created_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,

    UNIQUE KEY uq_chapter_page (chapter_id, page_no),
    FOREIGN KEY (chapter_id) REFERENCES chapters(id) ON DELETE CASCADE
) ENGINE=InnoDB;


-- =============================================================================
--  tags — thể loại / nhãn
-- =============================================================================
CREATE TABLE tags (
    id    INT AUTO_INCREMENT PRIMARY KEY,
    name  VARCHAR(50)  NOT NULL UNIQUE,   -- "Tiên hiệp"
    slug  VARCHAR(60)  NOT NULL UNIQUE    -- "tien-hiep"  (dùng trong URL lọc)
) ENGINE=InnoDB;


-- =============================================================================
--  story_tags — bảng NỐI giữa truyện và tag  (quan hệ nhiều-nhiều)
-- =============================================================================
--  Một truyện có nhiều tag, một tag thuộc nhiều truyện. Quan hệ N–N thì BẮT
--  BUỘC phải có bảng nối — không thể nhét vào cột của bảng nào cả.
--
--  ĐỪNG làm kiểu stories.tags = "tien-hiep,huyen-huyen" (chuỗi ngăn phẩy).
--  Nhìn thì gọn, nhưng lọc theo tag sẽ phải LIKE '%tien-hiep%' — chậm, không
--  dùng được index, và khớp nhầm ("tien-hiep" khớp cả "tien-hiep-hai-huoc").
-- =============================================================================
CREATE TABLE story_tags (
    story_id  INT NOT NULL,
    tag_id    INT NOT NULL,

    -- Khoá chính gồm hai cột: một cặp (truyện, tag) chỉ tồn tại một lần.
    PRIMARY KEY (story_id, tag_id),

    FOREIGN KEY (story_id) REFERENCES stories(id) ON DELETE CASCADE,
    FOREIGN KEY (tag_id)   REFERENCES tags(id)    ON DELETE CASCADE,

    -- Index ngược, để truy vấn "tag này có những truyện nào" cũng nhanh.
    INDEX idx_story_tags_tag (tag_id)
) ENGINE=InnoDB;


-- =============================================================================
--  comments — bình luận
-- =============================================================================
--  Bình luận gắn với TRUYỆN, không gắn với từng chương. Đây là lựa chọn để
--  giảm độ phức tạp. Muốn nâng cấp sau: thêm cột chapter_id NULL-able, NULL
--  nghĩa là bình luận ở cấp truyện.
-- =============================================================================
CREATE TABLE comments (
    id         INT AUTO_INCREMENT PRIMARY KEY,
    story_id   INT NOT NULL,
    user_id    INT NOT NULL,

    content    VARCHAR(1000) NOT NULL,

    -- Admin gỡ bình luận vi phạm nội quy thì đổi sang HIDDEN, không xoá hẳn —
    -- giữ lại để còn bằng chứng khi xử lý tài khoản.
    status     ENUM('VISIBLE','HIDDEN') NOT NULL DEFAULT 'VISIBLE',

    /*
      TRẢ LỜI BÌNH LUẬN — quan hệ CHA-CON trong CÙNG MỘT BẢNG.

      NULL      = bình luận gốc
      có giá trị = trả lời cho bình luận có id đó

      VÌ SAO KHÔNG TÁCH BẢNG comment_replies RIÊNG
        Trả lời cũng là bình luận: cùng người viết, cùng nội dung, cùng cần
        ẩn khi vi phạm, cùng cần báo cáo. Tách bảng là chép y nguyên năm cột
        và nhân đôi mọi câu truy vấn quản trị.

      CHỈ LỒNG MỘT CẤP — quyết định có chủ ý, ép ở tầng Java.
        CSDL không cấm được A trả lời B trả lời C trả lời D. Nhưng lồng sâu
        thì trên màn hình điện thoại, tới cấp 4 là cột chữ chỉ còn vài từ mỗi
        dòng. CommentDAO.insert() ép mọi trả lời gắn về bình luận GỐC.

      ON DELETE CASCADE trỏ về chính bảng này: xoá bình luận gốc thì các trả
      lời của nó đi theo. Đúng ý muốn — một chuỗi trả lời mất phần đầu thì
      không ai hiểu người ta đang nói về cái gì.
    */
    parent_id  INT NULL,

    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (story_id)  REFERENCES stories(id)  ON DELETE CASCADE,
    FOREIGN KEY (user_id)   REFERENCES users(id)    ON DELETE CASCADE,
    FOREIGN KEY (parent_id) REFERENCES comments(id) ON DELETE CASCADE,

    INDEX idx_comments_story (story_id, created_at),

    -- Gom trả lời theo bình luận cha
    INDEX idx_comments_parent (parent_id)
) ENGINE=InnoDB;


-- =============================================================================
--  bookmarks — đánh dấu truyện
-- =============================================================================
--  CHỈ những truyện người dùng TỰ BẤM "Lưu truyện".
--
--  Trước đây bảng này còn gánh luôn "đang đọc tới chương mấy" (cột
--  last_chapter_id). Hậu quả: mở một chương là truyện tự nhảy vào tủ sách,
--  bấm "Bỏ lưu" thì mất luôn vị trí đọc. Vị trí đọc giờ nằm ở
--  reading_progress ngay bên dưới (xem migration-027).
-- =============================================================================
CREATE TABLE bookmarks (
    user_id         INT NOT NULL,
    story_id        INT NOT NULL,

    created_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,

    -- Một người chỉ đánh dấu một truyện một lần.
    PRIMARY KEY (user_id, story_id),

    FOREIGN KEY (user_id)         REFERENCES users(id)    ON DELETE CASCADE,
    FOREIGN KEY (story_id)        REFERENCES stories(id)  ON DELETE CASCADE
) ENGINE=InnoDB;


-- =============================================================================
--  reading_progress — vị trí đọc (tự ghi, người dùng không phải bấm gì)
-- =============================================================================
--  Lưu theo ĐOẠN VĂN chứ không theo pixel: đổi cỡ chữ hay đổi máy thì số
--  pixel vô nghĩa, còn "đoạn thứ 37 của chương 12" thì vẫn đúng.
-- =============================================================================
CREATE TABLE reading_progress (
    user_id     INT NOT NULL,
    story_id    INT NOT NULL,

    -- SET NULL: tác giả xoá đúng chương đang đọc dở thì chỉ mất vị trí.
    chapter_id  INT NULL,

    -- Đoạn trên cùng màn hình lúc rời trang, đếm từ 1. 0 = đầu chương.
    para_no     INT NOT NULL DEFAULT 0,

    updated_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

    PRIMARY KEY (user_id, story_id),
    FOREIGN KEY (user_id)    REFERENCES users(id)    ON DELETE CASCADE,
    FOREIGN KEY (story_id)   REFERENCES stories(id)  ON DELETE CASCADE,
    FOREIGN KEY (chapter_id) REFERENCES chapters(id) ON DELETE SET NULL
) ENGINE=InnoDB;


-- =============================================================================
--  chapter_bookmarks — đoạn văn người dùng đánh dấu để đọc lại
-- =============================================================================
CREATE TABLE chapter_bookmarks (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    user_id     INT NOT NULL,
    chapter_id  INT NOT NULL,

    -- Đoạn được đánh dấu, đếm từ 1. 0 = cả chương.
    para_no     INT NOT NULL DEFAULT 0,

    -- Vài chục chữ đầu của đoạn, chụp lúc đánh dấu — danh sách hiện được
    -- ngay mà không phải nạp lại nội dung từng chương.
    snippet     VARCHAR(200) NULL,

    created_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,

    UNIQUE KEY uq_chapter_bookmark (user_id, chapter_id, para_no),
    INDEX idx_cb_user (user_id, created_at),
    FOREIGN KEY (user_id)    REFERENCES users(id)    ON DELETE CASCADE,
    FOREIGN KEY (chapter_id) REFERENCES chapters(id) ON DELETE CASCADE
) ENGINE=InnoDB;


-- =============================================================================
--  ratings — chấm sao truyện
-- =============================================================================
--  MỖI NGƯỜI MỘT ĐIỂM CHO MỖI TRUYỆN — khoá chính kép ép điều đó ở tầng CSDL.
--  Chặn ở tầng Java thôi thì hai request gửi cùng lúc vẫn lọt được cả hai.
--  Cho phép chấm lại: UPDATE dòng cũ, không INSERT dòng mới.
-- =============================================================================
CREATE TABLE ratings (
    user_id    INT NOT NULL,
    story_id   INT NOT NULL,

    -- 1..5 sao. CHECK để dữ liệu rác không lọt vào bằng đường khác (import,
    -- sửa tay trong Workbench). MySQL 8.0.16 trở lên mới thực sự áp dụng CHECK.
    score      TINYINT NOT NULL CHECK (score BETWEEN 1 AND 5),

    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

    PRIMARY KEY (user_id, story_id),
    FOREIGN KEY (user_id)  REFERENCES users(id)   ON DELETE CASCADE,
    FOREIGN KEY (story_id) REFERENCES stories(id) ON DELETE CASCADE,

    -- Xếp hạng theo điểm cần quét theo truyện, không theo người.
    INDEX idx_rating_story (story_id)
) ENGINE=InnoDB;


-- =============================================================================
--  follows — theo dõi tác giả
-- =============================================================================
--  Quan hệ NHIỀU-NHIỀU của users với chính nó. Cả hai cột đều trỏ về users:
--  follower_id là người bấm theo dõi, author_id là người được theo dõi.
-- =============================================================================
CREATE TABLE follows (
    follower_id INT NOT NULL,
    author_id   INT NOT NULL,
    created_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,

    PRIMARY KEY (follower_id, author_id),
    FOREIGN KEY (follower_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (author_id)   REFERENCES users(id) ON DELETE CASCADE,

    -- Đếm "tác giả này có bao nhiêu người theo dõi" quét theo author_id.
    -- Khoá chính đã phủ chiều follower_id rồi nên chỉ cần thêm chiều này.
    INDEX idx_follow_author (author_id),

    -- Không cho tự theo dõi chính mình.
    CHECK (follower_id <> author_id)
) ENGINE=InnoDB;


-- =============================================================================
--  notifications — thông báo chương mới
-- =============================================================================
--  SINH RA LÚC ĐĂNG CHƯƠNG, không phải lúc mở trang thông báo.
--
--  Cách khác là để trống bảng này rồi mỗi lần mở trang mới đi hỏi "có chương
--  nào mới hơn lần đọc trước không". Cách đó không cần bảng, nhưng không đánh
--  dấu được đã đọc/chưa đọc từng cái, và câu truy vấn nặng dần theo số truyện.
-- =============================================================================
CREATE TABLE notifications (
    id         INT AUTO_INCREMENT PRIMARY KEY,

    -- Người NHẬN thông báo.
    user_id    INT NOT NULL,

    story_id   INT NULL,
    chapter_id INT NULL,

    -- Loại thông báo: NEW_CHAPTER, SYSTEM, TIP, UPDATE_CHAPTER...
    type       VARCHAR(32) NOT NULL DEFAULT 'SYSTEM',

    message    VARCHAR(255) NOT NULL,
    is_read    BOOLEAN  NOT NULL DEFAULT FALSE,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (user_id)    REFERENCES users(id)    ON DELETE CASCADE,
    FOREIGN KEY (story_id)   REFERENCES stories(id)  ON DELETE CASCADE,
    FOREIGN KEY (chapter_id) REFERENCES chapters(id) ON DELETE CASCADE,

    -- Câu truy vấn nóng nhất: "thông báo của tôi, mới nhất trước".
    -- Index gộp hai cột theo đúng thứ tự đó.
    INDEX idx_notif_user (user_id, created_at DESC)
) ENGINE=InnoDB;


-- =============================================================================
--  reports — báo cáo vi phạm
-- =============================================================================
--  MỘT BẢNG CHO CẢ TRUYỆN LẪN BÌNH LUẬN, phân biệt bằng target_type.
--
--  Đây là đánh đổi có ý thức: KHÔNG khai được khoá ngoại cho target_id, vì nó
--  trỏ sang hai bảng khác nhau tuỳ dòng. Đổi lại, thêm loại báo cáo mới (báo
--  cáo người dùng chẳng hạn) chỉ cần thêm một giá trị ENUM, không phải tạo
--  bảng mới và không phải viết lại trang xử lý báo cáo.
--
--  Với đồ án, thiếu một khoá ngoại ở bảng phụ trợ này chấp nhận được. Nếu là
--  hệ thống thật thì nên tách reports_story và reports_comment.
-- =============================================================================
CREATE TABLE reports (
    id          INT AUTO_INCREMENT PRIMARY KEY,

    reporter_id INT NOT NULL,
    target_type ENUM('STORY', 'COMMENT') NOT NULL,
    target_id   INT NOT NULL,

    /*
      PHÂN LOẠI VI PHẠM (ISSUE-025). Tám loại, xem bảng ở issue.md §3.1.

      MẶC ĐỊNH 'OTHER' — đây là điều kiện để nâng cấp không phải sửa tay: mọi
      báo cáo CŨ (chỉ có ô reason tự do) tự rơi vào "Khác", đọc vẫn đúng
      nghĩa, và không dòng nào phải chạy UPDATE.

      ENUM chứ không phải bảng riêng: một báo cáo có ĐÚNG MỘT loại. Quan hệ
      một-một thì cột là đúng, bảng nối là thừa. Thêm loại thứ chín sau này
      chỉ là sửa một dòng — cùng lý lẽ với cột target_type ngay phía trên.

      BA LOẠI NẶNG (ADULT, VIOLENCE, PRIVACY) được trang quản trị đẩy lên đầu
      hàng đợi. Không phải cho đẹp: nội dung người lớn và lộ thông tin cá nhân
      là loại mà mỗi giờ chậm là thêm người nhìn thấy. Spam thì để chiều xử
      cũng không sao.
    */
    category    ENUM('SPAM','ADULT','VIOLENCE','PRIVACY',
                     'PLAGIARISM','WRONG_INFO','HARASSMENT','OTHER')
                NOT NULL DEFAULT 'OTHER',

    -- Mô tả thêm của người báo cáo. Bắt buộc khi category = 'OTHER',
    -- tuỳ chọn với các loại còn lại.
    reason      VARCHAR(500) NOT NULL,

    -- PENDING: chờ xử lý · RESOLVED: đã xử lý · DISMISSED: bỏ qua
    status      ENUM('PENDING', 'RESOLVED', 'DISMISSED') NOT NULL DEFAULT 'PENDING',

    created_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    handled_at  DATETIME NULL,

    FOREIGN KEY (reporter_id) REFERENCES users(id) ON DELETE CASCADE,

    -- Trang xử lý luôn lọc "còn chờ xử lý" trước.
    INDEX idx_report_status (status, created_at),

    -- Bộ lọc theo loại vi phạm ở trang quản trị (ISSUE-025).
    INDEX idx_report_category (category, status, created_at)
) ENGINE=InnoDB;


-- =============================================================================
--  report_evidence — ảnh bằng chứng kèm theo báo cáo  (ISSUE-025)
-- =============================================================================
--  VÌ SAO BẢNG RIÊNG, KHÔNG PHẢI MỘT CỘT evidence_url TRÊN reports
--    Một cột chỉ chứa được một ảnh, mà ba ảnh là nhu cầu thật: ảnh chụp trang
--    truyện + ảnh chụp đúng chỗ vi phạm + ảnh bản gốc khi tố đạo văn. Nhét ba
--    đường dẫn ngăn phẩy vào một VARCHAR là đúng cái sai mà bảng story_tags đã
--    cảnh báo ("đừng làm kiểu tags = 'a,b'"): không đếm được, không xoá lẻ
--    được, và phải tự tách chuỗi ở tầng Java.
--
--  KHÔNG LƯU ẢNH VÀO CSDL, CHỈ LƯU ĐƯỜNG DẪN
--    Khác với nội dung chương (lưu thẳng MEDIUMTEXT, xem ghi chú bảng
--    chapters). Lý do ngược lại: ảnh là dữ liệu nhị phân vài trăm KB, đọc ra
--    là đọc nguyên khối, và trình duyệt cache được nếu nó là một file có URL
--    riêng. Nhét BLOB vào đây là mỗi lần mở trang quản trị kéo về vài MB.
--
--  ĐƯỜNG DẪN LUÔN BẮT ĐẦU BẰNG "evidence/"
--    Đây KHÔNG phải quy ước cho đẹp mà là hàng rào: UploadedFileServlet nhìn
--    tiền tố này để biết phải chặn người không phải admin. Ảnh tố cáo có thể
--    chứa ảnh chụp tin nhắn riêng hoặc thông tin cá nhân của người bị tố —
--    khác hẳn ảnh bìa truyện vốn để khoe.
--
--  GIỚI HẠN 3 ẢNH KHÔNG KHAI ĐƯỢC Ở ĐÂY
--    MySQL không có ràng buộc kiểu "nhiều nhất 3 dòng con". Nó được ép ở
--    ReportDAO.insertEvidence() trong cùng một transaction với lúc chèn.
-- =============================================================================
CREATE TABLE report_evidence (
    id         INT AUTO_INCREMENT PRIMARY KEY,

    report_id  INT NOT NULL,

    -- Ví dụ: "evidence/2026/09/a1b2c3d4.jpg". Tương đối với thư mục uploads.
    file_path  VARCHAR(255) NOT NULL,

    -- Cỡ file lúc tải lên, để trang quản trị hiện và để đối soát khi dọn đĩa.
    file_size  INT NOT NULL,

    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,

    -- Xoá báo cáo thì ảnh của nó đi theo. LƯU Ý: CASCADE chỉ xoá DÒNG, không
    -- xoá FILE trên ổ đĩa — ReportDAO.deleteWithEvidence() phải tự xoá file.
    FOREIGN KEY (report_id) REFERENCES reports(id) ON DELETE CASCADE,

    INDEX idx_evidence_report (report_id)
) ENGINE=InnoDB;


-- =============================================================================
--  view_logs — nhật ký lượt xem
-- =============================================================================
--  VÌ SAO PHẢI CÓ BẢNG NÀY KHI ĐÃ CÓ stories.view_count
--
--    view_count là MỘT con số cộng dồn từ ngày đăng. Nó trả lời được "truyện
--    này tổng cộng bao nhiêu lượt xem", nhưng KHÔNG trả lời được "tuần này
--    bao nhiêu" — vì nó không nhớ lượt xem xảy ra khi nào.
--
--    Muốn có bảng xếp hạng theo tuần/tháng thì bắt buộc phải ghi từng lượt xem
--    kèm thời điểm. Đây chính là chỗ đánh đổi giữa gộp sẵn (nhanh, mất chi
--    tiết) và ghi thô (chậm hơn, giữ đủ chi tiết) — dự án dùng CẢ HAI:
--      · view_count  cho con số hiển thị trên mọi thẻ truyện  (đọc rất nhiều)
--      · view_logs   cho bảng xếp hạng theo thời gian         (đọc ít)
--
--  BẢNG NÀY SẼ LỚN NHẤT HỆ THỐNG. Mỗi lượt mở truyện là một dòng. Hệ thống
--  thật sẽ dọn định kỳ (xoá dòng cũ hơn 90 ngày) vì bảng xếp hạng không cần
--  dữ liệu năm ngoái.
-- =============================================================================
CREATE TABLE view_logs (
    id        BIGINT AUTO_INCREMENT PRIMARY KEY,
    story_id  INT NOT NULL,

    -- NULL = khách chưa đăng nhập. Vẫn tính vào lượt xem.
    user_id   INT NULL,

    viewed_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (story_id) REFERENCES stories(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id)  REFERENCES users(id)   ON DELETE SET NULL,

    -- Xếp hạng tuần chạy: WHERE viewed_at >= ? GROUP BY story_id
    -- Thời gian đứng TRƯỚC vì nó là điều kiện lọc, story_id đứng sau để
    -- MySQL gom nhóm ngay trên index, khỏi phải đọc bảng.
    INDEX idx_viewlog_time (viewed_at, story_id),

    -- Lịch sử đọc (trang 31) hỏi NGƯỢC LẠI với xếp hạng:
    --     xếp hạng  -> "truyện nào được đọc nhiều trong 7 ngày"  (lọc theo thời gian)
    --     lịch sử   -> "NGƯỜI NÀY đã đọc những truyện nào"       (lọc theo người)
    -- Index trên đổi thứ tự cột nên không phục vụ được câu thứ hai.
    --
    -- Khoá ngoại user_id đã tự sinh một index một cột, đủ để LỌC nhanh. Nhưng
    -- câu lịch sử còn GROUP BY story_id, mà index một cột không giúp gì cho
    -- bước gom nhóm — EXPLAIN hiện "Using temporary": MySQL phải dựng bảng
    -- tạm. Thêm story_id và viewed_at vào sau user_id thì cả lọc, gom nhóm
    -- lẫn lấy MAX(viewed_at) đều xong ngay trên index, không đụng bảng.
    --
    -- Đáng thêm vì view_logs là bảng DUY NHẤT trong dự án phình vô hạn — mỗi
    -- lượt mở truyện một dòng. Các bảng khác lớn theo số truyện, số người;
    -- bảng này lớn theo số lần đọc.
    INDEX idx_viewlog_user (user_id, story_id, viewed_at)
) ENGINE=InnoDB;


-- =============================================================================
--  password_resets — vé đặt lại mật khẩu
-- =============================================================================
--  VÉ DÙNG MỘT LẦN, CÓ HẠN.
--
--  Không đặt token vào bảng users vì đó là dữ liệu TẠM: sống vài chục phút rồi
--  bỏ. Nhét vào users là mỗi tài khoản phải mang thêm hai cột gần như luôn
--  rỗng, và không lưu được lịch sử ai xin đặt lại bao nhiêu lần.
-- =============================================================================
CREATE TABLE password_resets (
    -- KHÔNG PHẢI VÉ, MÀ LÀ DẤU VÂN TAY CỦA VÉ (SHA-256, mã base64url).
    --
    -- Vé đặt lại mật khẩu chính là một mật khẩu tạm: ai cầm được nó là đổi
    -- được mật khẩu của tài khoản kia. Mật khẩu đã băm PBKDF2 rất kỹ mà vé
    -- lại nằm nguyên chữ ở đây thì công sức đó mất một nửa — lộ database là
    -- chiếm được mọi tài khoản còn vé chưa hết hạn.
    --
    -- Vé thật chỉ tồn tại trong đường link gửi cho người dùng.
    --
    -- Vì sao vẫn CHAR(43): SHA-256 ra 32 byte, mã base64url không đệm của 32
    -- byte là đúng 43 ký tự — trùng khít độ dài vé, nên không phải đổi cột.
    --
    -- Vì sao SHA-256 chứ không PBKDF2 như mật khẩu: xem PasswordResetDAO.
    -- Tóm tắt — vé là 256 bit ngẫu nhiên từ SecureRandom, không có gì để dò,
    -- nên băm chậm không thêm an toàn.
    token      CHAR(43)     NOT NULL PRIMARY KEY,

    user_id    INT NOT NULL,

    -- Hết hạn thì vé vô giá trị dù chưa dùng. Không có hạn thì một email cũ
    -- lộ ra sau ba năm vẫn đổi được mật khẩu.
    expires_at DATETIME NOT NULL,

    -- Đã dùng rồi thì không dùng lại. Giữ dòng lại thay vì xoá để còn thấy
    -- lịch sử.
    used_at    DATETIME NULL,

    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_reset_user (user_id)
) ENGINE=InnoDB;


-- =============================================================================
--  wallets & transactions — Ví xu ảo & ủng hộ tác giả (ISSUE-008)
-- =============================================================================
CREATE TABLE IF NOT EXISTS wallets (
    user_id     INT PRIMARY KEY,
    balance     INT NOT NULL DEFAULT 100,
    updated_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS transactions (
    id           INT AUTO_INCREMENT PRIMARY KEY,
    from_user_id INT NULL,
    to_user_id   INT NULL,
    story_id     INT NULL,
    amount       INT NOT NULL,
    message      VARCHAR(255) NULL,
    created_at   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (from_user_id) REFERENCES users(id) ON DELETE SET NULL,
    FOREIGN KEY (to_user_id)   REFERENCES users(id) ON DELETE SET NULL,
    FOREIGN KEY (story_id)     REFERENCES stories(id) ON DELETE SET NULL,
    INDEX idx_tx_to (to_user_id, created_at)
) ENGINE=InnoDB;


-- =============================================================================
--  audit_logs — nhật ký thao tác quản trị (ISSUE-023)
-- =============================================================================
CREATE TABLE IF NOT EXISTS audit_logs (
    id           BIGINT AUTO_INCREMENT PRIMARY KEY,
    admin_id     INT NULL,
    action       ENUM('DELETE_STORY','RESTORE_STORY',
                      'BAN_USER','UNBAN_USER',
                      'HIDE_COMMENT','SHOW_COMMENT',
                      'GRANT_COIN','REVOKE_COIN') NOT NULL,
    target_type  ENUM('STORY','USER','COMMENT','WALLET') NOT NULL,
    target_id    INT NOT NULL,
    target_label VARCHAR(200) NULL,
    reason       VARCHAR(500) NULL,
    created_at   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (admin_id) REFERENCES users(id) ON DELETE SET NULL,

    INDEX idx_audit_time (created_at DESC),
    INDEX idx_audit_admin (admin_id, created_at DESC)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- =============================================================================
--  Kiểm tra
-- =============================================================================
SHOW TABLES;
