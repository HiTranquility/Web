package truyen;

import static org.junit.jupiter.api.Assertions.*;

import java.sql.SQLException;
import java.util.List;
import java.util.Set;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import truyen.dao.GamificationDAO;
import truyen.dao.ReviewDAO;
import truyen.dao.UnlockDAO;
import truyen.model.DailyQuest;
import truyen.model.Review;

@DisplayName("New Features — Chương VIP, Đánh giá Spoiler & Gamification")
class NewFeaturesTest {

    private final UnlockDAO unlockDAO = new UnlockDAO();
    private final ReviewDAO reviewDAO = new ReviewDAO();
    private final GamificationDAO gamificationDAO = new GamificationDAO();

    @Test
    @DisplayName("Ca 1: UnlockDAO.hasUnlocked trả về false cho người dùng chưa mở khoá")
    void testUnlockDAOForNonUnlocked() throws SQLException {
        // userId 99999 chưa mở khoá chương 61
        boolean unlocked = unlockDAO.hasUnlocked(99999, 61);
        assertFalse(unlocked);
    }

    @Test
    @DisplayName("Ca 2: UnlockDAO.findUnlockedChapterIds trả về tập hợp an toàn không null")
    void testFindUnlockedChapterIds() throws SQLException {
        List<Integer> ids = unlockDAO.findUnlockedChapterIds(1, 1);
        assertNotNull(ids);
    }

    @Test
    @DisplayName("Ca 3: Review model lưu trữ đúng điểm số, cờ spoiler và số vote")
    void testReviewModel() {
        Review r = new Review();
        r.setId(100);
        r.setStoryId(1);
        r.setUserId(2);
        r.setScore(5);
        r.setTitle("Truyện xuất sắc");
        r.setContent("Phân tích cốt truyện chi tiết");
        r.setHasSpoiler(true);
        r.setHelpfulCount(12);
        r.setVotedByMe(true);

        assertEquals(5, r.getScore());
        assertTrue(r.isHasSpoiler());
        assertEquals(12, r.getHelpfulCount());
        assertTrue(r.isVotedByMe());
        assertEquals("Truyện xuất sắc", r.getTitle());
    }

    @Test
    @DisplayName("Ca 4: ReviewDAO.findByStory trả về danh sách không null")
    void testReviewDAOQuery() throws SQLException {
        List<Review> list = reviewDAO.findByStory(1, 1);
        assertNotNull(list);
    }

    @Test
    @DisplayName("Ca 5: Nhiệm vụ theo đúng chế độ có hoặc không có CSDL")
    void testGamificationQuests() throws SQLException {
        List<DailyQuest> quests = gamificationDAO.getDailyQuests(1);
        assertNotNull(quests);
        // Không có CSDL thì DAO trả rỗng, không giả lập tiến độ/nhiệm vụ đã nhận.
        if (!truyen.util.DBConnection.isReady()) {
            assertTrue(quests.isEmpty());
            return;
        }
        assertEquals(3, quests.size());
        assertTrue(quests.stream().anyMatch(q -> "DAILY_CHECKIN".equals(q.getKey())));
        assertTrue(quests.stream().anyMatch(q -> "READ_CHAPTER".equals(q.getKey())));
        assertTrue(quests.stream().anyMatch(q -> "COMMENT_REVIEW".equals(q.getKey())));
    }

    @Test
    @DisplayName("Ca 6: Notification icon phân biệt chính xác chương mới và cập nhật chương")
    void testNotificationIcons() {
        truyen.model.Notification n1 = new truyen.model.Notification();
        n1.setType("NEW_CHAPTER");
        assertEquals("📖", n1.getIcon());

        truyen.model.Notification n2 = new truyen.model.Notification();
        n2.setType("UPDATE_CHAPTER");
        assertEquals("📝", n2.getIcon());

        truyen.model.Notification n3 = new truyen.model.Notification();
        n3.setMessage("Ai đó đã trả lời bình luận của bạn");
        assertEquals("💬", n3.getIcon());

        truyen.model.Notification n4 = new truyen.model.Notification();
        n4.setType("SYSTEM");
        assertEquals("🔔", n4.getIcon());
    }

    @Test
    @DisplayName("Ca 7: NotificationDAO.notifyFollowers chạy an toàn khi danh sách rỗng hoặc DB demo")
    void testNotifyFollowersSafe() {
        truyen.dao.NotificationDAO dao = new truyen.dao.NotificationDAO();
        assertDoesNotThrow(() -> dao.notifyFollowers(null, 1, 1, "test"));
        assertDoesNotThrow(() -> dao.notifyFollowers(java.util.Collections.emptyList(), 1, 1, "UPDATE_CHAPTER", "test"));
    }
}
