<%@ page pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%--
================================================================================
  _chapter-list.jsp — MẢNH TÁI DÙNG: mục lục chương
================================================================================
  TẦNG: views/

  DÙNG Ở: trang 3 (chi tiết truyện).

          KHÔNG dùng ở trang 12 (ghi chú cũ ghi sai). Trang "Truyện của tôi"
          liệt kê TRUYỆN chứ không phải chương, nên nó dùng _story-row.

  Mảnh này chỉ vẽ DANH SÁCH. Thanh sắp xếp và phân trang nằm ở trang gọi nó
  (detail.jsp) — chúng phụ thuộc vào tham số URL của riêng trang đó.

  CÁCH DÙNG:
      <c:set var="clChapters" value="${chapters}"/>
      <c:set var="clStoryId"  value="${story.id}"/>
      <c:set var="clCanEdit"  value="${canEdit}"/>   (tuỳ chọn)
      <%@ include file="/WEB-INF/views/_partials/_chapter-list.jsp" %>

  clCanEdit bật thì mỗi hàng có thêm nút Sửa / Xoá. Cùng một danh sách, độc
  giả và tác giả nhìn thấy hai thứ khác nhau — nhưng KHÔNG phải hai file.
================================================================================
--%>
<c:choose>
    <c:when test="${not empty clChapters}">
        <div class="chapter-list">
            <c:forEach var="ch" items="${clChapters}">
                <div class="chapter-item">
                    <a class="chapter-link"
                       href="${pageContext.request.contextPath}/chapter?action=read&amp;id=${ch.id}"
                       <c:if test="${empty currentUser}">title="Cần đăng nhập để đọc chương này"</c:if>>
                        <span class="chapter-no">
                            <c:if test="${empty currentUser}"><span style="opacity: 0.7; margin-right: 3px;" title="Cần đăng nhập">🔒</span></c:if>Chương ${ch.chapterNo}
                        </span>
                        <span class="chapter-title"><c:out value="${ch.title}"/></span>
                        <c:if test="${ch.vip}">
                            <c:set var="chUnlocked" value="false"/>
                            <c:if test="${not empty unlockedChapterIds}">
                                <c:forEach var="uId" items="${unlockedChapterIds}">
                                    <c:if test="${uId eq ch.id}">
                                        <c:set var="chUnlocked" value="true"/>
                                    </c:if>
                                </c:forEach>
                            </c:if>
                            <c:choose>
                                <c:when test="${clCanEdit or (not empty currentUser and currentUser.admin)}">
                                    <span class="badge-vip badge-author" title="Bạn có quyền tác giả / quản trị viên (Đọc miễn phí)">👑 VIP <c:out value="${ch.coinPrice}"/> xu</span>
                                </c:when>
                                <c:when test="${chUnlocked}">
                                    <span class="badge-unlocked" title="Bạn đã mở khoá chương này">🔓 Đã mở</span>
                                </c:when>
                                <c:otherwise>
                                    <span class="badge-vip">🔒 VIP <c:out value="${ch.coinPrice}"/> xu</span>
                                </c:otherwise>
                            </c:choose>
                        </c:if>
                    </a>

                    <c:if test="${clCanEdit}">
                        <span class="chapter-actions">
                            <a class="btn btn-ghost btn-sm"
                               href="${pageContext.request.contextPath}/chapter?action=edit&amp;id=${ch.id}">Sửa</a>

                            <%-- Xoá là POST, và hỏi lại trước khi làm.
                                 Xoá chương KHÔNG khôi phục được — đây là chỗ
                                 duy nhất trong dự án xoá thật, vì chương không
                                 có cột status như truyện và bình luận. --%>
                            <form method="post" style="display:inline"
                                  action="${pageContext.request.contextPath}/chapter"
                                  data-confirm="Xoá chương này? Không khôi phục được."
                                  data-confirm-title="Xác nhận xoá chương"
                                  data-confirm-ok="Đồng ý xoá">
                                <input type="hidden" name="_csrf" value="${csrfToken}">
                                <input type="hidden" name="action" value="delete">
                                <input type="hidden" name="id" value="${ch.id}">
                                <button type="submit" class="btn btn-danger btn-sm">Xoá</button>
                            </form>
                        </span>
                    </c:if>
                </div>
            </c:forEach>
        </div>
    </c:when>

    <c:otherwise>
        <c:set var="emIcon"  value="📄"/>
        <c:set var="emTitle" value="Chưa có chương nào"/>
        <c:set var="emText"  value="Truyện này chưa đăng chương đầu tiên."/>
        <%@ include file="/WEB-INF/views/_partials/_empty.jsp" %>
    </c:otherwise>
</c:choose>
