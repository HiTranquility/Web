<%@ page pageEncoding="UTF-8" %>
<%-- pageEncoding la BAT BUOC cho moi file .jsp duoc include tinh:
     Tomcat doc TUNG FILE theo encoding rieng cua no. Thieu dong nay
     thi file duoc doc bang ISO-8859-1 va tieng Viet thanh ky tu la,
     du trang cha da khai UTF-8. --%>
<%--
================================================================================
  _card.jsp — MỘT thẻ truyện trong lưới
================================================================================
  Dấu gạch dưới ở đầu tên file là quy ước: "đây là mảnh, không phải trang".

  Cần biến `story` đã được đặt sẵn, thường là bởi <c:forEach var="story">.

  VÌ SAO TÁCH RA FILE RIÊNG
    Thẻ truyện xuất hiện ở trang chủ, kho truyện, kết quả lọc theo tag, trang
    bookmark, trang cá nhân tác giả. Chép đi chép lại 5 lần thì đổi thiết kế
    một cái phải sửa 5 chỗ và chắc chắn sót. Sửa ở đây là cả 5 nơi đổi theo.

  LƯU Ý: dùng <%@ include %> (include tĩnh) nên file này thấy được biến `story`
  của vòng lặp bên trang cha. Nếu dùng <jsp:include> thì không, phải truyền
  tham số tường minh.
================================================================================
--%>
<a class="story-card"
   href="${pageContext.request.contextPath}/story?action=detail&amp;id=${story.id}">

    <div class="story-cover">
        <c:set var="cvUrl"     value="${story.coverUrl}"/>
        <c:set var="cvAlt"     value="${story.title}"/>
        <c:set var="cvInitial" value="${story.initial}"/>
        <%@ include file="/WEB-INF/views/_partials/_cover.jsp" %>

        <span class="badge badge-status ${story.completed ? 'badge-done' : 'badge-going'}">
            ${story.completed ? 'Hoàn thành' : 'Đang ra'}
        </span>

        <div class="story-badges">
            <%--
              NHÃN "HOT" — ngưỡng đặt cứng 10.000 lượt xem.
            --%>
            <c:if test="${story.viewCount ge 10000}">
                <span class="badge badge-hot">🔥 Hot</span>
            </c:if>

            <%--
              NHÃN "MỚI" — truyện đăng trong 14 ngày gần đây.
            --%>
            <c:if test="${story.recent}">
                <span class="badge badge-new">✨ Mới</span>
            </c:if>

            <%-- LOẠI TRUYỆN — chỉ gắn nhãn cho truyện tranh. Truyện chữ là
                 mặc định của web, gắn nhãn cho mọi thẻ chỉ thêm nhiễu. --%>
            <c:if test="${story.comic}">
                <span class="badge badge-comic">🎨 Tranh</span>
            </c:if>
        </div>
    </div>

    <div class="story-body">
        <%-- Nhãn "vì sao gợi ý" — chỉ khối gợi ý (_recommend.jsp) đặt cardReason,
             mọi trang khác không đặt nên dòng này không hiện. --%>
        <c:if test="${not empty cardReason}">
            <span class="rec-reason"><c:out value="${cardReason}"/></span>
        </c:if>

        <%-- <c:out> escape HTML -> chống XSS. Xem ghi chú ở home.jsp. --%>
        <div class="story-title"><c:out value="${story.title}"/></div>

        <div class="story-meta">
            <span class="card-author"
                  onclick="event.preventDefault(); event.stopPropagation(); window.location.href='${pageContext.request.contextPath}/user?action=profile&amp;id=${story.authorId}';"
                  title="Xem trang tác giả"
                  style="cursor:pointer;transition:color .15s">✍️ <c:out value="${story.authorName}"/></span>
        </div>
        <div class="story-meta">
            <span>📄 ${story.chapterCount} chương</span>
            <%-- fmt:formatNumber dat dau phan cach hang nghin: "31.200" de doc
                 luot hon "31200". Dinh dang o tang view, KHONG bien so
                 thanh String trong model — model giu so nguyen thi con
                 cong tru, so sanh va sap xep duoc. --%>
            <span>👁️ <fmt:formatNumber pattern="#,##0" value="${story.viewCount}"/></span>
        </div>

        <%--
          MẢNH: sao đánh giá (chỉ hiển thị, không chấm được từ đây).

          Chấm sao ngay trên thẻ nghe tiện, nhưng thẻ này nằm trong một thẻ
          <a> bọc cả ô — nhét form vào trong link là HTML không hợp lệ và
          trình duyệt xử lý mỗi nơi một kiểu. Muốn chấm thì vào trang chi tiết.
        --%>
        <c:set var="rsStory" value="${story}"/>
        <c:set var="rsForm"  value="${false}"/>
        <%@ include file="/WEB-INF/views/_partials/_rating-stars.jsp" %>
    </div>
</a>
