<%@ page pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%--
  register.jsp — MẢNH nội dung, dùng khung layout/auth.jsp
  Nhận: message · username · email (giữ lại chữ đã gõ khi lỗi)
--%>
<h1>Đăng ký</h1>
<p>Đã có tài khoản?
   <a href="${pageContext.request.contextPath}/auth?action=login">Đăng nhập</a></p>

<c:if test="${not empty message}">
    <p class="form-error"><c:out value="${message}"/></p>
</c:if>

<form action="${pageContext.request.contextPath}/auth" method="post" id="form-register">
    <input type="hidden" name="_csrf" value="${csrfToken}">
    <input type="hidden" name="action" value="register">
    <input type="hidden" name="g-recaptcha-token" id="recaptcha-register">

    <label for="username">Tên đăng nhập</label>
    <input type="text" id="username" name="username"
           value="<c:out value='${username}'/>"
           pattern="[a-zA-Z0-9_]{3,50}"
           title="3-50 ký tự, chỉ chữ, số và dấu gạch dưới" autofocus required>

    <label for="email">Email</label>
    <input type="email" id="email" name="email" maxlength="150"
           value="<c:out value='${email}'/>" required>

    <label for="password">Mật khẩu</label>
    <div class="password-wrap">
        <input type="password" id="password" name="password" minlength="6" maxlength="128" required>
        <button type="button" class="pwd-toggle" aria-label="Hiện/ẩn mật khẩu" onclick="togglePassword('password', this)" tabindex="-1">👁️</button>
    </div>

    <label for="confirm">Nhập lại mật khẩu</label>
    <div class="password-wrap">
        <input type="password" id="confirm" name="confirm" minlength="6" maxlength="128" required>
        <button type="button" class="pwd-toggle" aria-label="Hiện/ẩn mật khẩu" onclick="togglePassword('confirm', this)" tabindex="-1">👁️</button>
    </div>

    <%--
      Mục tiêu đồ án yêu cầu có "điều dẫn sử dụng và luật cho người dùng".
      Ô tick này là chỗ người dùng chấp nhận nội quy — servlet kiểm lại lần nữa
      ở phía server, vì thuộc tính required của HTML ai cũng tắt được.
    --%>
    <label class="check">
        <input type="checkbox" name="agree" value="yes" required>
        Tôi đã đọc và đồng ý với
        <a href="${pageContext.request.contextPath}/page?name=rules" target="_blank">nội quy cộng đồng</a>
    </label>

    <button type="submit" class="btn btn-primary">Tạo tài khoản</button>
</form>

<c:if test="${googleEnabled}">
    <div class="auth-divider">
        <span>hoặc tiếp tục với</span>
    </div>

    <button type="button" class="btn-google-login">
        <svg width="18" height="18" viewBox="0 0 18 18">
            <path d="M17.64 9.2c0-.637-.057-1.251-.164-1.84H9v3.481h4.844c-.209 1.125-.843 2.078-1.796 2.717v2.258h2.908c1.702-1.567 2.684-3.874 2.684-6.616z" fill="#4285F4"/>
            <path d="M9 18c2.43 0 4.467-.806 5.956-2.184l-2.908-2.258c-.806.54-1.837.86-3.048.86-2.344 0-4.328-1.584-5.036-3.711H.957v2.332C2.438 15.983 5.482 18 9 18z" fill="#34A853"/>
            <path d="M3.964 10.707c-.18-.54-.282-1.117-.282-1.707s.102-1.167.282-1.707V4.961H.957C.347 6.173 0 7.548 0 9s.348 2.827.957 4.039l3.007-2.332z" fill="#FBBC05"/>
            <path d="M9 3.58c1.321 0 2.508.454 3.44 1.345l2.582-2.58C13.463.891 11.426 0 9 0 5.482 0 2.438 2.017.957 4.961L3.964 7.293C4.672 5.166 6.656 3.58 9 3.58z" fill="#EA4335"/>
        </svg>
        <span>Đăng ký nhanh với Google</span>
    </button>
</c:if>
