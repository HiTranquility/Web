<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%--
================================================================================
  layout/admin.jsp — KHUNG KHU QUẢN TRỊ                    (CASE 10)
================================================================================
  Khác main.jsp: có menu bên trái (sidebar).

  Vẫn dùng LẠI parts/nav.jsp của layout main — không chép lại. Nhờ vậy sửa
  logo hay menu chính một lần là cả hai khung đổi theo. Đó chính là lý do
  parts/ được tách ra từ đầu.

  AdminFilter đã chặn ở /admin/* nên tới được đây chắc chắn là admin.
================================================================================
--%>
<!DOCTYPE html>
<html lang="vi">
<head>
    <c:set var="layoutCss" value="layout-admin" scope="request"/>
    <%@ include file="parts/head.jsp" %>
</head>
<body data-ctx="${pageContext.request.contextPath}">

<%-- Dùng chung với layout main — không chép lại --%>
<%@ include file="parts/nav.jsp" %>

<div class="admin-shell">
    <aside class="admin-side">
        <h5>Quản trị</h5>
        <nav>
            <a href="${pageContext.request.contextPath}/admin/dashboard"
               class="${adminSection eq 'dashboard' ? 'is-active' : ''}">📊 Tổng quan</a>
            <c:if test="${currentUser.admin or currentUser.hasPermission('MANAGE_STORIES')}">
                <a href="${pageContext.request.contextPath}/admin/story"
                   class="${adminSection eq 'story' ? 'is-active' : ''}">📚 Truyện</a>
            </c:if>
            <c:if test="${currentUser.admin or currentUser.hasPermission('MANAGE_USERS')}">
                <a href="${pageContext.request.contextPath}/admin/user"
                   class="${adminSection eq 'user' ? 'is-active' : ''}">👤 Tài khoản</a>
            </c:if>
            <c:if test="${currentUser.admin or currentUser.hasPermission('MANAGE_STORIES')}">
                <a href="${pageContext.request.contextPath}/admin/tag"
                   class="${adminSection eq 'tag' ? 'is-active' : ''}">🏷️ Thể loại</a>
            </c:if>
            <c:if test="${currentUser.admin or currentUser.hasPermission('MODERATE_COMMENTS')}">
                <a href="${pageContext.request.contextPath}/admin/comment"
                   class="${adminSection eq 'comment' ? 'is-active' : ''}">💬 Bình luận</a>
            </c:if>
            <c:if test="${currentUser.admin or currentUser.hasPermission('HANDLE_REPORTS')}">
                <a href="${pageContext.request.contextPath}/admin/report"
                   class="${adminSection eq 'report' ? 'is-active' : ''}">🛡️ Báo cáo</a>
            </c:if>
            <c:if test="${currentUser.admin or currentUser.hasPermission('MANAGE_WALLET')}">
                <a href="${pageContext.request.contextPath}/admin/wallet"
                   class="${adminSection eq 'wallet' ? 'is-active' : ''}">💰 Ví xu</a>
            </c:if>
            <c:if test="${currentUser.admin or currentUser.hasPermission('MANAGE_SYSTEM') or currentUser.hasPermission('MANAGE_WALLET')}">
                <a href="${pageContext.request.contextPath}/admin/audit"
                   class="${adminSection eq 'audit' ? 'is-active' : ''}">📜 Nhật ký</a>
            </c:if>
        </nav>
        <p class="admin-hint">
            Gỡ truyện và khoá tài khoản đều là <b>xoá mềm</b> — bấm nhầm vẫn
            khôi phục được.
        </p>
    </aside>

    <main class="admin-main">
        <%-- Thong bao sau khi chuyen trang — xem ghi chu day du o main.jsp --%>
        <c:if test="${not empty flash}">
            <div class="panel panel-ok"><c:out value="${flash}"/></div>
            <c:remove var="flash" scope="session"/>
        </c:if>
        <c:if test="${not empty flashWarn}">
            <div class="panel panel-warn"><c:out value="${flashWarn}"/></div>
            <c:remove var="flashWarn" scope="session"/>
        </c:if>

        <c:if test="${not empty message}">
            <div class="panel panel-warn"><c:out value="${message}"/></div>
        </c:if>
        <jsp:include page="${contentPage}" />
    </main>
</div>

<%@ include file="parts/footer.jsp" %>

<%-- Hệ thống Modal Toàn Cục: Nạp Xu Nhanh & Hộp Thoại Xác Nhận --%>
<%@ include file="/WEB-INF/views/_partials/_quick-topup-modal.jsp" %>
<%@ include file="/WEB-INF/views/_partials/_confirm-modal.jsp" %>

</body>
</html>
