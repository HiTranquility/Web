<%@ page pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>

<%--
  Dải cảnh báo truyện đã bị gỡ (ISSUE-025). Chỉ admin mới vào được tới đây —
  StoryServlet.detail() trả 404 cho mọi người khác. Không có dải này thì admin
  bấm từ trang báo cáo sang sẽ thấy một trang truyện trông hoàn toàn bình
  thường và tưởng mình chưa gỡ.
--%>
<c:if test="${storyRemoved}">
    <div class="panel panel-err" style="margin-bottom:16px">
        🚫 <b>Truyện này đã bị gỡ.</b>
        Người đọc không mở được trang này — bạn thấy được vì đang là quản trị viên.
    </div>
</c:if>
<%--
================================================================================
  story/detail.jsp — MẢNH NỘI DUNG: Chi tiết truyện               TRANG 3
================================================================================
  TẦNG: views/

  Nhận: story · tags · chapters · comments · canEdit
        bookmarked · myRating · following

  Trang đông đặc nhất dự án: mô tả, mục lục, chấm sao, theo dõi tác giả, lưu
  truyện, tải .txt, chia sẻ, báo cáo, bình luận. Vì vậy nó dùng lại nhiều mảnh
  nhất — _rating-stars, _chapter-list, _comment, _empty.
================================================================================
--%>
<div class="story-detail">
    <div class="detail-cover">
        <c:set var="cvUrl"     value="${story.coverUrl}"/>
        <c:set var="cvAlt"     value="${story.title}"/>
        <c:set var="cvInitial" value="${story.initial}"/>
        <%@ include file="/WEB-INF/views/_partials/_cover.jsp" %>
    </div>

    <div class="detail-info">
        <h1><c:out value="${story.title}"/>
            <c:if test="${story.comic}"><span class="badge badge-comic detail-type-badge">🎨 Truyện tranh</span></c:if></h1>

        <p class="detail-author">
            ✍️
            <%-- Tên tác giả là LINK sang hồ sơ (trang 4). Trước đây chỉ là
                 chữ — đọc xong một truyện hay mà không có đường tìm truyện
                 khác của cùng người viết là bỏ phí. --%>
            <a href="${pageContext.request.contextPath}/user?action=profile&amp;id=${story.authorId}">
                <c:out value="${story.authorName}"/></a>

            <c:if test="${story.status eq 'DRAFT'}">
                <span class="pill pill-warn" style="margin-left:8px">Bản nháp</span>
            </c:if>

            <%-- Nút theo dõi tác giả. Không hiện trên hồ sơ của chính mình. --%>
            <c:choose>
                <c:when test="${not empty currentUser and currentUser.id ne story.authorId}">
                    <form method="post" style="display:inline;margin-left:10px"
                          action="${pageContext.request.contextPath}/follow" id="author-follow-form">
                        <input type="hidden" name="_csrf" value="${csrfToken}">
                        <input type="hidden" name="do" id="author-follow-do" value="${following ? 'unfollow' : 'follow'}">
                        <input type="hidden" name="authorId" value="${story.authorId}">
                        <input type="hidden" name="back" value="story">
                        <input type="hidden" name="storyId" value="${story.id}">
                        <button type="submit" class="btn btn-ghost btn-sm" id="author-follow-btn">
                            <span id="author-follow-label">${following ? '✓ Đang theo dõi' : '+ Theo dõi'}</span>
                        </button>
                    </form>
                    <button type="button" class="btn btn-warning btn-sm" style="margin-left:8px;"
                            data-author-id="${story.authorId}"
                            data-author-name="<c:out value='${story.authorName}'/>"
                            data-story-id="${story.id}"
                            data-story-title="<c:out value='${story.title}'/>"
                            onclick="triggerTipModal(this)"
                            title="Tặng xu khích lệ tác giả">🪙 Tặng xu</button>
                </c:when>
                <c:when test="${empty currentUser}">
                    <a class="btn btn-ghost btn-sm" id="author-follow-btn-guest" style="margin-left:10px"
                       href="${pageContext.request.contextPath}/auth?action=login&amp;reason=follow&amp;redirect=${pageContext.request.contextPath}/story?action=detail%26id=${story.id}"
                       title="Đăng nhập để theo dõi tác giả">
                        <span>+ Theo dõi</span>
                    </a>
                    <a class="btn btn-ghost btn-sm" style="margin-left:8px"
                       href="${pageContext.request.contextPath}/auth?action=login&amp;reason=tip&amp;redirect=${pageContext.request.contextPath}/story?action=detail%26id=${story.id}"
                       title="Đăng nhập để tặng xu tác giả">
                        <span>🪙 Tặng xu</span>
                    </a>
                </c:when>
            </c:choose>
        </p>

        <div class="tag-row" style="margin:14px 0">
            <c:forEach var="t" items="${tags}">
                <a class="tag"
                   href="${pageContext.request.contextPath}/story?action=list&amp;tag=${t.slug}">
                    <c:out value="${t.name}"/></a>
            </c:forEach>
        </div>

        <div class="detail-stats">
            <span>${story.comic ? '🎨' : '📄'} ${story.chapterCount} chương</span>
            <span>👁️ <fmt:formatNumber pattern="#,##0" value="${story.viewCount}"/> lượt xem</span>
            <span class="${story.completed ? 'yes' : ''}">
                ${story.completed ? '✓ Hoàn thành' : '⏳ Đang ra'}</span>
        </div>

        <%-- MẢNH: sao đánh giá, bản CÓ chấm được (rsForm) --%>
        <c:set var="rsStory" value="${story}"/>
        <c:set var="rsForm"  value="${true}"/>
        <c:set var="rsMine"  value="${myRating}"/>
        <%@ include file="/WEB-INF/views/_partials/_rating-stars.jsp" %>

        <p class="detail-desc"><c:out value="${story.description}"/></p>

        <div class="detail-actions">
            <%-- Đọc tiếp nếu đã có tiến độ --%>
            <c:if test="${not empty resumeChapterId and resumeChapterId gt 0}">
                <a class="btn btn-primary"
                   href="${pageContext.request.contextPath}/chapter?action=read&amp;id=${resumeChapterId}">
                    ▶ Đọc tiếp (Chương ${resumeChapterNo})</a>
            </c:if>

            <%-- Đọc từ đầu: cố định vào chương 1 (firstChapter) thay vì lấy theo trang/thứ tự mục lục --%>
            <c:choose>
                <c:when test="${not empty firstChapter}">
                    <a class="btn ${empty resumeChapterId ? 'btn-primary' : 'btn-ghost'}"
                       href="${pageContext.request.contextPath}/chapter?action=read&amp;id=${firstChapter.id}">
                        <c:choose>
                            <c:when test="${empty currentUser}">🔒 Đọc từ đầu (Cần đăng nhập)</c:when>
                            <c:otherwise>Đọc từ đầu</c:otherwise>
                        </c:choose>
                    </a>
                </c:when>
                <c:when test="${not empty chapters}">
                    <a class="btn ${empty resumeChapterId ? 'btn-primary' : 'btn-ghost'}"
                       href="${pageContext.request.contextPath}/chapter?action=read&amp;id=${chapters[0].id}">
                        <c:choose>
                            <c:when test="${empty currentUser}">🔒 Đọc từ đầu (Cần đăng nhập)</c:when>
                            <c:otherwise>Đọc từ đầu</c:otherwise>
                        </c:choose>
                    </a>
                </c:when>
            </c:choose>

            <%-- Nút lưu/bỏ lưu.
                 - Đã đăng nhập: Form POST với AJAX chuyển đổi trạng thái tức thì.
                 - Chưa đăng nhập: Nút bấm dẫn đến đăng nhập kèm ghi nhớ quay lại trang truyện. --%>
            <c:choose>
                <c:when test="${not empty currentUser}">
                    <form action="${pageContext.request.contextPath}/bookmark" method="post"
                          style="display:inline" id="bookmark-form">
                        <input type="hidden" name="_csrf" value="${csrfToken}">
                        <input type="hidden" name="action" id="bookmark-action" value="${bookmarked ? 'remove' : 'add'}">
                        <input type="hidden" name="storyId" value="${story.id}">
                        <button type="submit" class="btn btn-ghost" id="bookmark-btn">
                            <span id="bookmark-label">${bookmarked ? '★ Đã lưu' : '☆ Lưu truyện'}</span>
                        </button>
                    </form>
                </c:when>
                <c:otherwise>
                    <a class="btn btn-ghost" id="bookmark-btn-guest"
                       href="${pageContext.request.contextPath}/auth?action=login&amp;reason=bookmark&amp;redirect=${pageContext.request.contextPath}/story?action=detail%26id=${story.id}"
                       title="Đăng nhập để lưu truyện vào tủ sách">
                        <span id="bookmark-label">☆ Lưu truyện</span>
                    </a>
                </c:otherwise>
            </c:choose>

            <%-- Tải .txt / EPUB chỉ dành cho truyện CHỮ — truyện tranh là ảnh,
                 ghép thành .txt thì ra file rỗng. DownloadServlet cũng chặn. --%>
            <c:if test="${not story.comic}">
                <a class="btn btn-ghost"
                   href="${pageContext.request.contextPath}/download?storyId=${story.id}">
                    ⬇ Tải .txt</a>
                <a class="btn btn-ghost"
                   href="${pageContext.request.contextPath}/download?storyId=${story.id}&amp;format=epub"
                   title="Tải sách điện tử EPUB (đọc trên Kindle, Apple Books, Moon+ Reader)">
                    📕 Tải EPUB</a>
            </c:if>

            <%-- Tặng xu khích lệ tác giả --%>
            <c:choose>
                <c:when test="${not empty currentUser and currentUser.id ne story.authorId}">
                    <button type="button" class="btn btn-warning"
                            data-author-id="${story.authorId}"
                            data-author-name="<c:out value='${story.authorName}'/>"
                            data-story-id="${story.id}"
                            data-story-title="<c:out value='${story.title}'/>"
                            onclick="triggerTipModal(this)"
                            title="Tặng xu khích lệ tác giả sáng tác">
                        🪙 Tặng xu
                    </button>
                </c:when>
                <c:when test="${empty currentUser}">
                    <a class="btn btn-ghost"
                       href="${pageContext.request.contextPath}/auth?action=login&amp;reason=tip&amp;redirect=${pageContext.request.contextPath}/story?action=detail%26id=${story.id}"
                       title="Đăng nhập để tặng xu cho tác giả">
                        🪙 Tặng xu
                    </a>
                </c:when>
            </c:choose>

            <%-- canEdit do servlet tính: chủ truyện HOẶC admin --%>
            <c:if test="${canEdit}">
                <a class="btn btn-ghost"
                   href="${pageContext.request.contextPath}/story?action=edit&amp;id=${story.id}">Sửa</a>
                <a class="btn btn-ghost"
                   href="${pageContext.request.contextPath}/chapter?action=create&amp;storyId=${story.id}">+ Thêm chương</a>
            </c:if>
            <c:if test="${googleDriveEnabled and not story.comic and not empty currentUser and currentUser.id eq story.authorId}">
                <button type="button" class="btn btn-ghost btn-drive-backup"
                        data-story-id="${story.id}"
                        data-story-title="<c:out value='${story.title}'/>"
                        title="Sao lưu toàn bộ chương truyện lên Google Drive cá nhân">
                    ☁️ Sao lưu Drive</button>
            </c:if>
        </div>

        <%--
          CHIA SẺ — ba mạng phổ biến, dựng bằng link thuần.

          Không nhúng nút chính chủ của Facebook/X. Nút của họ kéo theo mã
          JavaScript của bên thứ ba và theo dõi mọi người mở trang, kể cả
          người không bấm chia sẻ. Một thẻ <a> tới URL chia sẻ của họ làm đúng
          việc cần làm mà không gửi gì đi trước khi người dùng chủ động bấm.

          rel="noopener" bắt buộc khi có target="_blank": thiếu nó, trang mới
          mở ra có thể điều khiển ngược trang này qua window.opener.
        --%>
        <div class="share-row">
            <span class="share-label">Chia sẻ:</span>
            <c:set var="shareUrl"
                   value="${pageContext.request.scheme}://${pageContext.request.serverName}:${pageContext.request.serverPort}${pageContext.request.contextPath}/story?action=detail&id=${story.id}"/>
            <button type="button" class="share-btn" id="btn-copy-link" style="cursor:pointer; display:inline-flex; align-items:center; gap:4px; font-family:inherit;" title="Sao chép liên kết truyện">
                <span>🔗 Sao chép link</span>
            </button>
            <a class="share-btn" target="_blank" rel="noopener"
               href="https://www.facebook.com/sharer/sharer.php?u=${fn:escapeXml(shareUrl)}">Facebook</a>
            <a class="share-btn" target="_blank" rel="noopener"
               href="https://twitter.com/intent/tweet?url=${fn:escapeXml(shareUrl)}&amp;text=${fn:escapeXml(story.title)}">X</a>
            <a class="share-btn" target="_blank" rel="noopener"
               href="https://t.me/share/url?url=${fn:escapeXml(shareUrl)}">Telegram</a>

            <%-- Báo cáo truyện vi phạm. Form gọn nằm ngay đây, không bắt
                 chuyển trang — bắt đổi trang để tố cáo là cách chắc chắn
                 khiến không ai buồn báo cáo. --%>
            <c:if test="${not empty currentUser}">
                <details class="report-box" id="story-report-box" style="margin-left:auto">
                    <summary class="report-trigger-btn" id="btn-report-story">🚩 Báo cáo vi phạm</summary>
                    <%--
                      enctype BẮT BUỘC có, không thì ảnh không đi kèm và
                      request.getParts() ở servlet ném lỗi (ISSUE-025).
                    --%>
                    <form method="post" enctype="multipart/form-data"
                          class="report-form"
                          action="${pageContext.request.contextPath}/report">
                        <input type="hidden" name="_csrf" value="${csrfToken}">
                        <input type="hidden" name="targetType" value="STORY">
                        <input type="hidden" name="targetId" value="${story.id}">
                        <input type="hidden" name="storyId" value="${story.id}">

                        <label class="report-field">
                            <span>Loại vi phạm</span>
                            <select name="category" id="report-category-select" class="inline-input" required>
                                <option value="">— Chọn loại vi phạm —</option>
                                <c:forEach var="cat" items="${reportCategoriesStory}">
                                    <option value="${cat}">${reportCategoryLabels[cat]}</option>
                                </c:forEach>
                            </select>
                        </label>

                        <label class="report-field">
                            <span>Mô tả thêm</span>
                            <input type="text" name="reason" id="report-reason-input" maxlength="500"
                                   class="inline-input"
                                   placeholder="Bắt buộc nếu chọn &quot;Khác&quot;">
                        </label>

                        <label class="report-field">
                            <span>Ảnh bằng chứng <em>(tối đa 3, mỗi ảnh ≤ 2 MB)</em></span>
                            <input type="file" name="evidence" id="report-evidence-file" accept="image/*" multiple
                                   class="report-file-input" data-max="3">
                            <span class="report-file-hint"></span>
                        </label>

                        <button type="submit" id="btn-submit-report" class="btn btn-danger btn-sm">Gửi báo cáo</button>
                    </form>
                </details>
            </c:if>
        </div>
    </div>
</div>

<%--
  ĐẾM CẢ TRẢ LỜI, không chỉ bình luận gốc.

  fn:length(comments) chỉ đếm phần tử ở cấp một — mà từ khi có trả lời lồng
  nhau, mỗi phần tử còn mang theo một danh sách con. Truyện có 3 bình luận gốc
  và 2 trả lời sẽ hiện "Bình luận (3)" trong khi trên màn hình đếm được 5
  khối. Con số sai kiểu này không gây lỗi, chỉ làm người đọc nghi ngờ mọi con
  số khác trên trang.

  Tính Ở ĐÂY, trước thanh thẻ, vì cả nhãn trên thẻ lẫn tiêu đề bên dưới đều
  cần. Tính ở chỗ cũ (trong phần bình luận) thì thanh thẻ nằm trên không thấy
  biến — JSP chạy từ trên xuống.
--%>
<c:set var="nCmtTotal" value="0"/>
<c:forEach var="x" items="${comments}">
    <c:set var="nCmtTotal" value="${nCmtTotal + 1 + x.replyCount}"/>
</c:forEach>

<%--
================================================================================
  HAI THẺ: MỤC LỤC · BÌNH LUẬN
================================================================================
  VÌ SAO CẦN
    Trang này dài nhất dự án. Mục lục 50 chương đẩy phần bình luận xuống tận
    đáy — muốn đọc bình luận phải cuộn qua 50 dòng không liên quan.

  CHẠY ĐƯỢC CẢ KHI TẮT JAVASCRIPT
    Không có JavaScript: hai khối hiện ĐẦY ĐỦ như trước, và hai nút trên kia
    là link neo thường, bấm là nhảy xuống đúng chỗ. Không mất gì.
    Có JavaScript: chúng thành hai thẻ, mỗi lúc chỉ hiện một.

    Đây là lý do dùng thẻ <a href="#..."> chứ không phải <button>: <button>
    mà không có JavaScript thì bấm không ra gì cả.

  hidden-khi-có-JS được đặt bằng chính JavaScript (thêm lớp .tabs-on), không
  viết sẵn trong HTML. Viết sẵn thì người tắt JavaScript mất luôn phần bình
  luận — hỏng nặng hơn là không có thẻ.
--%>
<div class="tab-bar" id="story-tabs">
    <a class="tab-btn is-on" href="#muc-luc" data-panel="panel-chapters">
        Mục lục <span class="tab-count">${chapterTotal}</span></a>
    <a class="tab-btn" href="#reviews" data-panel="panel-reviews">
        Đánh giá <span class="tab-count">${fn:length(reviews)}</span></a>
    <a class="tab-btn" href="#comments" data-panel="panel-comments">
        Bình luận <span class="tab-count">${nCmtTotal}</span></a>
</div>

<section id="panel-chapters" class="tab-panel">

<%-- ---- Mục lục chương — MẢNH _chapter-list ---- --%>
<%--
  id="muc-luc" là ĐÍCH NEO.

  Mục lục nằm giữa trang chi tiết. Không có neo thì bấm "Sau ›" ở phân trang
  sẽ tải lại trang và nhảy về đầu — người dùng phải cuộn xuống lại mỗi lần
  lật trang. Neo giữ họ đúng chỗ đang xem.
--%>
<div class="section-head" id="muc-luc">
    <h2>Danh sách chương</h2>
    <span class="more">${chapterTotal} chương</span>
</div>

<c:if test="${chapterTotal gt 0}">
    <div class="chapter-toolbar">
        <%--
          ĐẢO THỨ TỰ.

          Là LINK chứ không phải nút JavaScript: thứ tự nằm trên URL nên
          F5 hay chia sẻ link đều giữ nguyên lựa chọn, và chạy được cả khi
          tắt JavaScript.

          Quay về cpage=1 khi đổi thứ tự — giữ nguyên số trang là vô nghĩa:
          "trang 3 tính từ đầu" và "trang 3 tính từ cuối" là hai tập chương
          hoàn toàn khác nhau, người dùng sẽ tưởng mình lạc chỗ.
        --%>
        <span class="toolbar-label">Sắp xếp:</span>
        <a class="chip ${not cDesc ? 'is-on' : ''}"
           href="${pageContext.request.contextPath}/story?action=detail&amp;id=${story.id}&amp;cpage=1#muc-luc">
            Cũ nhất trước</a>
        <a class="chip ${cDesc ? 'is-on' : ''}"
           href="${pageContext.request.contextPath}/story?action=detail&amp;id=${story.id}&amp;order=desc&amp;cpage=1#muc-luc">
            Mới nhất trước</a>

        <c:if test="${cTotalPages gt 1}">
            <span class="toolbar-note">
                Trang ${cpage}/${cTotalPages} &middot; 50 chương mỗi trang
            </span>
        </c:if>

        <%-- Ô lọc nhanh chương theo số hoặc tiêu đề (ISSUE-032) --%>
        <div class="chapter-search-box" style="margin-left: auto; display: flex; align-items: center; gap: 6px; position: relative;">
            <input type="search" id="chapter-filter-input" class="input input-sm"
                   placeholder="🔍 Tìm nhanh chương..."
                   style="max-width: 220px; padding: 4px 26px 4px 12px; font-size: 0.85rem; border-radius: 20px;"
                   title="Gõ số chương hoặc từ khóa tiêu đề để lọc nhanh (nhấn Enter để cuộn đến)" />
            <button type="button" id="chapter-filter-clear" title="Xóa tìm kiếm"
                    style="display:none; position:absolute; right:8px; top:50%; transform:translateY(-50%); background:none; border:none; color:var(--text-dim); cursor:pointer; font-size:1.15rem; line-height:1; padding:0 4px;">&times;</button>
        </div>
    </div>
</c:if>

<c:if test="${empty currentUser}">
    <div class="login-prompt-banner" style="background: rgba(255, 122, 26, 0.08); border: 1px solid rgba(255, 122, 26, 0.25); border-radius: var(--radius-md); padding: 12px 18px; margin: 12px 0 16px; display: flex; align-items: center; justify-content: space-between; gap: 12px; flex-wrap: wrap;">
        <div style="display: flex; align-items: center; gap: 10px; color: var(--ink-200); font-size: 0.92rem;">
            <span style="font-size: 1.25rem;">🔒</span>
            <span>Bạn cần <strong>đăng nhập tài khoản</strong> để bắt đầu đọc hoặc tải các chương truyện này.</span>
        </div>
        <a href="${pageContext.request.contextPath}/auth?action=login" class="btn btn-primary btn-sm" style="white-space: nowrap;">Đăng nhập ngay</a>
    </div>
</c:if>

<c:set var="clChapters" value="${chapters}"/>
<c:set var="clStoryId"  value="${story.id}"/>
<c:set var="clCanEdit"  value="${canEdit}"/>
<%@ include file="/WEB-INF/views/_partials/_chapter-list.jsp" %>
<div id="chapter-filter-empty" style="display:none; text-align:center; padding:28px 16px; color:var(--text-dim); font-size:0.92rem; background:rgba(255,255,255,0.02); border:1px dashed var(--border); border-radius:8px; margin:12px 0;">
    🔍 Không tìm thấy chương nào khớp với từ khóa tìm kiếm.
</div>

<%--
  MẢNH: phân trang mục lục.

  _pagination.jsp đọc hai biến tên cố định là page và totalPages, nên phải
  gán từ cpage/cTotalPages ngay trước khi include. Không đổi tên biến trong
  mảnh chung vì năm trang khác đang dùng đúng hai tên đó.

  pgParam="cpage" để link sinh ra là "&cpage=2" chứ không phải "&page=2".
  pgHash="#muc-luc" để lật trang xong vẫn đứng ở mục lục.
--%>
<c:set var="page"       value="${cpage}"/>
<c:set var="totalPages" value="${cTotalPages}"/>
<c:set var="pgBase"  value="story?action=detail" scope="request"/>
<c:set var="pgQuery" value="&id=${story.id}${cDesc ? '&order=desc' : ''}" scope="request"/>
<c:set var="pgParam" value="cpage"    scope="request"/>
<c:set var="pgHash"  value="#muc-luc" scope="request"/>
<%@ include file="/WEB-INF/views/_partials/_pagination.jsp" %>

</section>

<section id="panel-reviews" class="tab-panel">
    <%-- ---- Đánh giá chi tiết (ISSUE-022) ---- --%>
    <div class="section-head" id="reviews" style="display:flex; justify-content:space-between; align-items:center;">
        <h2>Đánh giá từ độc giả (${fn:length(reviews)})</h2>
        <c:if test="${not empty currentUser and currentUser.id ne story.authorId}">
            <button type="button" class="btn btn-primary btn-sm" onclick="var f = document.getElementById('review-form-wrapper'); f.style.display = (f.style.display === 'none' ? 'block' : 'none'); if (f.style.display === 'block') f.scrollIntoView({behavior:'smooth'});">
                ✍️ ${empty myReview ? 'Viết đánh giá' : 'Sửa đánh giá của bạn'}
            </button>
        </c:if>
    </div>

    <%-- Form soạn bài đánh giá --%>
    <c:if test="${not empty currentUser and currentUser.id ne story.authorId}">
        <div id="review-form-wrapper" class="review-compose-card" style="display:${empty myReview ? 'none' : 'block'}; margin-bottom:24px; padding:18px 20px; border:1px solid var(--border); border-radius:10px; background:var(--card-bg, rgba(255,255,255,0.02)); box-shadow:0 4px 16px rgba(0,0,0,0.1);">
            <h3 style="margin-top:0; font-size:1.15rem; color:var(--text);">
                ${empty myReview ? '✍️ Viết cảm nhận cho tác phẩm' : '✏️ Chỉnh sửa bài đánh giá của bạn'}
            </h3>
            <form action="${pageContext.request.contextPath}/rating" method="post" id="story-review-form">
                <input type="hidden" name="_csrf" value="${csrfToken}">
                <input type="hidden" name="action" value="review">
                <input type="hidden" name="storyId" value="${story.id}">

                <c:set var="currentScore" value="${not empty myReview and myReview.score gt 0 ? myReview.score : (not empty myRating and myRating gt 0 ? myRating : 5)}"/>
                <div style="margin-bottom:14px; display:flex; align-items:center; gap:12px; flex-wrap:wrap;">
                    <label style="margin:0; font-weight:600">Đánh giá sao:</label>
                    <input type="hidden" name="score" id="review-score-input" value="${currentScore}">
                    <div class="interactive-star-picker" id="interactive-star-picker" title="Chọn số sao đánh giá (1 - 5 sao)">
                        <span class="star-item ${currentScore ge 1 ? 'is-active' : ''}" data-val="1">★</span>
                        <span class="star-item ${currentScore ge 2 ? 'is-active' : ''}" data-val="2">★</span>
                        <span class="star-item ${currentScore ge 3 ? 'is-active' : ''}" data-val="3">★</span>
                        <span class="star-item ${currentScore ge 4 ? 'is-active' : ''}" data-val="4">★</span>
                        <span class="star-item ${currentScore ge 5 ? 'is-active' : ''}" data-val="5">★</span>
                    </div>
                    <span id="star-label-text" style="font-weight:600; font-size:0.92rem; color:var(--text-dim);">
                        <c:choose>
                            <c:when test="${currentScore eq 5}">(5/5 sao - Tuyệt tác)</c:when>
                            <c:when test="${currentScore eq 4}">(4/5 sao - Rất hay)</c:when>
                            <c:when test="${currentScore eq 3}">(3/5 sao - Khá ổn)</c:when>
                            <c:when test="${currentScore eq 2}">(2/5 sao - Tạm được)</c:when>
                            <c:otherwise>(1/5 sao - Cần cải thiện)</c:otherwise>
                        </c:choose>
                    </span>
                </div>

                <div style="margin-bottom:14px;">
                    <label for="revTitle" style="display:block; margin-bottom:6px; font-weight:600">Tiêu đề bài viết *</label>
                    <input type="text" id="revTitle" name="title" maxlength="150" required
                           class="input" style="width:100%; box-sizing:border-box; padding:8px 12px; border-radius:6px; border:1px solid var(--border); background:var(--bg); color:var(--text);"
                           placeholder="Ví dụ: Cốt truyện sâu sắc, xây dựng tâm lý nhân vật tuyệt vời..."
                           value="<c:out value='${myReview.title}'/>">
                </div>

                <div style="margin-bottom:14px;">
                    <label for="revContent" style="display:block; margin-bottom:6px; font-weight:600">Nội dung cảm nhận chi tiết *</label>
                    <textarea id="revContent" name="content" rows="4" maxlength="4000" required
                              class="input" style="width:100%; box-sizing:border-box; padding:10px 12px; border-radius:6px; border:1px solid var(--border); background:var(--bg); color:var(--text); line-height:1.6;"
                              placeholder="Hãy chia sẻ lý do bạn thích hoặc chưa thích, các điểm nhấn của truyện..."><c:out value="${myReview.content}"/></textarea>
                </div>

                <div style="margin-bottom:16px; display:flex; align-items:center; gap:8px;">
                    <input type="checkbox" id="hasSpoiler" name="hasSpoiler" value="1" ${myReview.hasSpoiler ? 'checked' : ''} style="width:16px; height:16px;">
                    <label for="hasSpoiler" style="margin:0; cursor:pointer; font-weight:500;">
                        ⚠️ Bài đánh giá này có chứa tiết lộ nội dung (Spoiler)
                    </label>
                </div>

                <div style="display:flex; gap:10px;">
                    <button type="submit" class="btn btn-primary btn-sm">
                        ${empty myReview ? 'Đăng bài đánh giá' : 'Cập nhật bài đánh giá'}
                    </button>
                    <button type="button" class="btn btn-ghost btn-sm" onclick="document.getElementById('review-form-wrapper').style.display='none';">
                        Đóng lại
                    </button>
                </div>
            </form>
        </div>
    </c:if>

    <%-- Danh sách bài đánh giá --%>
    <div class="reviews-container">
        <c:choose>
            <c:when test="${not empty reviews}">
                <c:forEach var="r" items="${reviews}">
                    <%@ include file="/WEB-INF/views/_partials/_review.jsp" %>
                </c:forEach>
            </c:when>
            <c:otherwise>
                <div class="empty-state text-center" style="padding:36px 12px; border:1px dashed var(--border); border-radius:10px; margin:16px 0;">
                    <span style="font-size:2.2rem; display:block; margin-bottom:10px">⭐</span>
                    <p style="margin:0 0 6px 0; font-weight:600; font-size:1.05rem">Chưa có bài đánh giá chi tiết nào</p>
                    <p class="muted small" style="margin:0">Hãy chia sẻ góc nhìn và cảm nhận của bạn để cộng đồng cùng thảo luận!</p>
                </div>
            </c:otherwise>
        </c:choose>
    </div>
</section>

<section id="panel-comments" class="tab-panel">

<%-- ---- Bình luận ---- --%>
<div class="section-head" id="comments">
    <%--
      ĐẾM CẢ TRẢ LỜI, không chỉ bình luận gốc.

      fn:length(comments) chỉ đếm phần tử ở cấp một — mà từ khi có trả lời
      lồng nhau, mỗi phần tử còn mang theo một danh sách con. Truyện có 3 bình
      luận gốc và 2 trả lời sẽ hiện "Bình luận (3)" trong khi trên màn hình
      đếm được 5 khối. Con số sai kiểu này không gây lỗi, chỉ làm người đọc
      nghi ngờ mọi con số khác trên trang.
    --%>
    <h2>Bình luận (${nCmtTotal})</h2>
</div>

<c:choose>
    <c:when test="${not empty currentUser}">
        <form action="${pageContext.request.contextPath}/comment" method="post"
              class="comment-form">
            <input type="hidden" name="_csrf" value="${csrfToken}">
            <input type="hidden" name="action" value="add">
            <input type="hidden" name="storyId" value="${story.id}">
            <input type="hidden" name="g-recaptcha-token" class="recaptcha-token">
            <textarea name="content" rows="3" maxlength="1000" required
                      placeholder="Viết bình luận… Nhớ giữ lời lẽ văn minh."></textarea>
            <button type="submit" class="btn btn-primary btn-sm">Gửi bình luận</button>
        </form>
    </c:when>
    <c:otherwise>
        <p class="muted-note">
            <a href="${pageContext.request.contextPath}/auth?action=login">Đăng nhập</a>
            để bình luận.
        </p>
    </c:otherwise>
</c:choose>

<%-- MẢNH: mỗi bình luận. cmStoryId để nút gỡ biết quay về truyện nào. --%>
<c:set var="cmStoryId" value="${story.id}" scope="request"/>
<c:forEach var="cm" items="${comments}">
    <%@ include file="/WEB-INF/views/_partials/_comment.jsp" %>
</c:forEach>

<c:if test="${empty comments}">
    <c:set var="emIcon"  value="💬"/>
    <c:set var="emTitle" value="Chưa có bình luận nào"/>
    <c:set var="emText"  value="Hãy là người đầu tiên chia sẻ cảm nhận về truyện này."/>
    <%@ include file="/WEB-INF/views/_partials/_empty.jsp" %>
</c:if>

</section>

<%--
  ---- Gợi ý truyện ----

  Đặt SAU phần bình luận, không đặt trên.

  Người đã cuộn tới đây là người đã đọc xong mô tả và xem hết mục lục — họ
  đang ở đúng thời điểm cần câu hỏi "đọc gì tiếp". Đặt khối gợi ý ngay dưới
  mô tả thì nó tranh chỗ với chính truyện mà người ta vừa bấm vào.

  MỘT khối, MỘT mẫu — xem _partials/_recommend.jsp và
  StoryDAO.findRecommendations() (độc giả cũng đọc → cùng thể loại → đang
  được đọc nhiều, bỏ trùng).
--%>
<%@ include file="/WEB-INF/views/_partials/_recommend.jsp" %>

<%--
  ĐÁNH DẤU CHƯƠNG ĐÃ ĐỌC.

  Danh sách chương đã đọc do trang đọc ghi vào localStorage (xem
  layout/reader.jsp). Ở đây chỉ đọc lại và làm mờ những hàng tương ứng.

  Chạy được cho cả khách chưa đăng nhập — đó là ưu điểm so với lưu vào CSDL,
  và cũng là hạn chế: đổi máy là mất. Vị trí đọc "chính thức" vẫn nằm ở bảng
  reading_progress cho người đã đăng nhập.
--%>
<script>
(function () {
    try {
        var done = JSON.parse(localStorage.getItem('read.${story.id}') || '[]');
        if (!done.length) return;
        document.querySelectorAll('.chapter-item').forEach(function (row) {
            var a = row.querySelector('.chapter-link');
            if (!a) return;
            var m = a.getAttribute('href').match(/id=(\d+)/);
            if (m && done.indexOf(m[1]) !== -1) {
                row.classList.add('chapter-read');
            }
        });
    } catch (e) { /* trình duyệt chặn lưu trữ — mục lục vẫn dùng bình thường */ }
})();


/* ===========================================================================
   HAI THẺ: MỤC LỤC · BÌNH LUẬN
   ===========================================================================
   Đoạn này chỉ NÂNG CẤP. HTML gửi xuống đã đầy đủ và dùng được: hai khối hiện
   hết, hai nút trên kia là link neo thường. Tắt JavaScript thì trang lùi về
   đúng dạng đó, không mất chức năng nào.

   Vì vậy lớp .tabs-on được THÊM BẰNG JAVASCRIPT chứ không viết sẵn trong
   HTML — mọi luật CSS ẩn bớt khối đều nằm sau lớp này. Viết sẵn trong HTML
   thì người tắt JavaScript mất hẳn phần bình luận.
   ======================================================================== */
(function () {
    var bar = document.getElementById('story-tabs');
    if (!bar) return;

    var nut = [].slice.call(bar.querySelectorAll('.tab-btn'));
    var panel = {};
    nut.forEach(function (a) {
        panel[a.getAttribute('data-panel')] =
            document.getElementById(a.getAttribute('data-panel'));
    });
    /* Thiếu một panel nào đó thì thà không bật thẻ còn hơn ẩn nhầm nội dung */
    if (nut.some(function (a) { return !panel[a.getAttribute('data-panel')]; })) return;

    bar.classList.add('tabs-on');

    function chon(ten) {
        nut.forEach(function (a) {
            var id = a.getAttribute('data-panel');
            var on = id === ten;
            a.classList.toggle('is-on', on);
            /* .hidden thay vì style.display: thuộc tính chuẩn, và CSS của
               trang không cần biết gì về nó */
            panel[id].hidden = !on;
        });
    }

    nut.forEach(function (a) {
        a.addEventListener('click', function (e) {
            /*
             * Chặn hành vi mặc định để trang KHÔNG nhảy.
             *
             * Nhưng vẫn ghi neo vào thanh địa chỉ bằng replaceState: người
             * dùng sao chép link lúc đang mở thẻ Bình luận thì gửi cho bạn
             * bè cũng mở đúng thẻ đó. Dùng replaceState chứ không pushState —
             * đổi thẻ không phải là "đi tới trang khác", nhét vào lịch sử thì
             * bấm Back mười lần vẫn quanh quẩn trong một trang.
             */
            e.preventDefault();
            chon(a.getAttribute('data-panel'));
            if (history.replaceState) {
                history.replaceState(null, '', a.getAttribute('href'));
            }
        });
    });

    function theoNeo() {
        if (location.hash === '#reviews') {
            chon('panel-reviews');
        } else if (location.hash === '#comments') {
            chon('panel-comments');
        } else {
            chon('panel-chapters');
        }
    }

    /*
     * Mở trang với sẵn một neo thì chọn đúng thẻ chứa neo đó.
     * Quan trọng với phân trang mục lục: mọi link "Sau ›" đều kèm #muc-luc.
     */
    theoNeo();

    /*
     * VÀ PHẢI NGHE hashchange NỮA.
     *
     * Đổi neo trên CÙNG một trang thì trình duyệt KHÔNG tải lại trang, nên
     * đoạn khởi tạo trên không chạy lần hai. Hậu quả bắt được lúc kiểm: đang
     * mở thẻ Bình luận, đổi địa chỉ sang #muc-luc — thẻ vẫn nằm ở Bình luận,
     * mà thanh địa chỉ lại ghi #muc-luc. Người dùng bấm nút Back cũng gặp
     * đúng cảnh đó.
     *
     * Dòng này nối trạng thái hiển thị vào đúng một nguồn sự thật là cái neo,
     * dù neo đổi bằng cách nào.
     */
    window.addEventListener('hashchange', theoNeo);
})();

/*
 * AJAX BOOKMARK & FOLLOW — Lưu truyện & Theo dõi tác giả tức thì
 */
(function () {
    var toastFn = window.showToast || function (msg) {
        var old = document.getElementById('global-toast');
        if (old) old.remove();
        var toast = document.createElement('div');
        toast.id = 'global-toast';
        toast.className = 'toast-bubble';
        toast.textContent = msg;
        document.body.appendChild(toast);
        setTimeout(function () { toast.classList.add('is-show'); }, 20);
        setTimeout(function () {
            toast.classList.remove('is-show');
            setTimeout(function () { toast.remove(); }, 280);
        }, 2800);
    };

    var bForm = document.getElementById('bookmark-form');
    var bBtn = document.getElementById('bookmark-btn');
    var bLabel = document.getElementById('bookmark-label');
    var bAction = document.getElementById('bookmark-action');
    if (bForm && bBtn && bLabel && bAction && window.fetch) {
        bForm.addEventListener('submit', function (e) {
            e.preventDefault();
            bBtn.disabled = true;
            var data = new URLSearchParams(new FormData(bForm));
            fetch(bForm.action, {
                method: 'POST',
                body: data,
                headers: { 'X-Requested-With': 'XMLHttpRequest' }
            })
            .then(function (r) {
                if (!r.ok) throw new Error('Lỗi HTTP ' + r.status);
                return r.json();
            })
            .then(function (res) {
                bBtn.disabled = false;
                if (res.bookmarked) {
                    bAction.value = 'remove';
                    bLabel.textContent = '★ Đã lưu';
                    toastFn('✨ Đã thêm truyện vào tủ sách!');
                } else {
                    bAction.value = 'add';
                    bLabel.textContent = '☆ Lưu truyện';
                    toastFn('Đã bỏ lưu truyện.');
                }
            })
            .catch(function () {
                bForm.submit();
            });
        });
    }

    var fForm = document.getElementById('author-follow-form');
    var fBtn = document.getElementById('author-follow-btn');
    var fLabel = document.getElementById('author-follow-label');
    var fDo = document.getElementById('author-follow-do');
    if (fForm && fBtn && fLabel && fDo && window.fetch) {
        fForm.addEventListener('submit', function (e) {
            e.preventDefault();
            fBtn.disabled = true;
            var data = new URLSearchParams(new FormData(fForm));
            fetch(fForm.action, {
                method: 'POST',
                body: data,
                headers: { 'X-Requested-With': 'XMLHttpRequest' }
            })
            .then(function (r) {
                if (!r.ok) throw new Error('Lỗi HTTP ' + r.status);
                return r.json();
            })
            .then(function (res) {
                fBtn.disabled = false;
                if (res.following) {
                    fDo.value = 'unfollow';
                    fLabel.textContent = '✓ Đang theo dõi';
                    toastFn(res.message || '✨ Đã theo dõi tác giả!');
                } else {
                    fDo.value = 'follow';
                    fLabel.textContent = '+ Theo dõi';
                    toastFn(res.message || 'Đã bỏ theo dõi tác giả.');
                }
            })
            .catch(function () {
                fForm.submit();
            });
        });
    }

    var bGuest = document.getElementById('bookmark-btn-guest');
    if (bGuest) {
        bGuest.addEventListener('click', function (e) {
            e.preventDefault();
            toastFn('🔒 Vui lòng đăng nhập để lưu truyện vào tủ sách!');
            setTimeout(function () {
                window.location.href = bGuest.href;
            }, 600);
        });
    }

    var fGuest = document.getElementById('author-follow-btn-guest');
    if (fGuest) {
        fGuest.addEventListener('click', function (e) {
            e.preventDefault();
            toastFn('🔒 Vui lòng đăng nhập để theo dõi tác giả!');
            setTimeout(function () {
                window.location.href = fGuest.href;
            }, 600);
        });
    }

    /* Sao chép liên kết truyện (ISSUE-018) */
    var copyBtn = document.getElementById('btn-copy-link');
    if (copyBtn) {
        copyBtn.addEventListener('click', function () {
            var url = window.location.href;
            if (navigator.clipboard && navigator.clipboard.writeText) {
                navigator.clipboard.writeText(url).then(function () {
                    toastFn('🔗 Đã sao chép liên kết truyện vào bộ nhớ tạm!');
                }).catch(function () {
                    prompt('Sao chép liên kết:', url);
                });
            } else {
                prompt('Sao chép liên kết:', url);
            }
        });
    }

    /* =========================================================================
       ISSUE-031: Interactive Star Rating Picker & Review Debounce
       ========================================================================= */
    var starPicker = document.getElementById('interactive-star-picker');
    var scoreInput = document.getElementById('review-score-input');
    var starLabel = document.getElementById('star-label-text');
    var starLabels = {
        1: '(1/5 sao - Cần cải thiện)',
        2: '(2/5 sao - Tạm được)',
        3: '(3/5 sao - Khá ổn)',
        4: '(4/5 sao - Rất hay)',
        5: '(5/5 sao - Tuyệt tác)'
    };

    if (starPicker && scoreInput) {
        var stars = starPicker.querySelectorAll('.star-item');

        function setHighlight(val, isHover) {
            stars.forEach(function (s) {
                var v = parseInt(s.getAttribute('data-val'), 10);
                if (isHover) {
                    s.classList.toggle('is-hover', v <= val);
                } else {
                    s.classList.toggle('is-active', v <= val);
                    s.classList.remove('is-hover');
                }
            });
            if (starLabel && starLabels[val]) {
                starLabel.textContent = starLabels[val];
            }
        }

        stars.forEach(function (star) {
            star.addEventListener('mouseenter', function () {
                var val = parseInt(this.getAttribute('data-val'), 10);
                setHighlight(val, true);
            });
            star.addEventListener('click', function () {
                var val = parseInt(this.getAttribute('data-val'), 10);
                scoreInput.value = val;
                setHighlight(val, false);
            });
        });

        starPicker.addEventListener('mouseleave', function () {
            var currentVal = parseInt(scoreInput.value, 10) || 5;
            setHighlight(currentVal, false);
        });
    }

    var revForm = document.getElementById('story-review-form');
    if (revForm) {
        revForm.addEventListener('submit', function (e) {
            var submitBtn = revForm.querySelector('button[type="submit"]');
            if (submitBtn) {
                if (submitBtn.disabled) {
                    e.preventDefault();
                    return;
                }
                submitBtn.disabled = true;
                submitBtn.dataset.originalText = submitBtn.innerHTML;
                submitBtn.innerHTML = '⏳ Đang lưu đánh giá...';
                setTimeout(function () {
                    submitBtn.disabled = false;
                    if (submitBtn.dataset.originalText) {
                        submitBtn.innerHTML = submitBtn.dataset.originalText;
                    }
                }, 5000);
            }
        });
    }

    /* =========================================================================
       ISSUE-031: AJAX Review Helpful Voting
       ========================================================================= */
    document.addEventListener('submit', function (e) {
        var form = e.target;
        if (!form || !form.classList.contains('review-vote-form')) return;

        e.preventDefault();
        var btn = form.querySelector('.btn-helpful-vote');
        if (!btn || btn.disabled) return;
        btn.disabled = true;

        var formData = new FormData(form);
        var params = new URLSearchParams();
        formData.forEach(function (value, key) {
            params.append(key, value);
        });

        fetch(form.action, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
                'X-Requested-With': 'XMLHttpRequest'
            },
            body: params.toString()
        })
        .then(function (res) { return res.json(); })
        .then(function (data) {
            btn.disabled = false;
            if (data.needLogin) {
                toastFn(data.message || '🔒 Vui lòng đăng nhập để bình chọn.');
                return;
            }
            if (data.success) {
                btn.classList.toggle('btn-primary', data.voted);
                btn.classList.toggle('btn-ghost', !data.voted);
                btn.setAttribute('data-voted', data.voted ? 'true' : 'false');
                btn.setAttribute('title', data.voted ? 'Bỏ bấm hữu ích' : 'Bấm nếu bạn thấy đánh giá này có ích');
                var countSpan = btn.querySelector('.helpful-count');
                if (countSpan && typeof data.count !== 'undefined') {
                    countSpan.textContent = data.count;
                }
                toastFn(data.voted ? '👍 Đã ghi nhận bình chọn hữu ích!' : 'Đã hủy bình chọn hữu ích.');
            } else if (data.message) {
                toastFn(data.message);
            }
        })
        .catch(function (err) {
            btn.disabled = false;
            console.error('Lỗi khi bình chọn đánh giá:', err);
            toastFn('Có lỗi kết nối khi bình chọn.');
        });
    });

    /* =========================================================================
       ISSUE-032: Chapter Quick Filter, Clear & Enter Key Jumper
       ========================================================================= */
    var chFilter = document.getElementById('chapter-filter-input');
    var chClear = document.getElementById('chapter-filter-clear');
    var chEmpty = document.getElementById('chapter-filter-empty');

    if (chFilter) {
        function filterChapters() {
            var q = chFilter.value.trim().toLowerCase();
            if (chClear) {
                chClear.style.display = q ? 'block' : 'none';
            }
            var items = document.querySelectorAll('.chapter-item');
            var visibleCount = 0;
            items.forEach(function (item) {
                var txt = item.textContent.toLowerCase();
                var matched = (q === '' || txt.indexOf(q) !== -1);
                item.style.display = matched ? '' : 'none';
                if (matched) visibleCount++;
            });

            if (chEmpty) {
                chEmpty.style.display = (visibleCount === 0 && q.length > 0) ? 'block' : 'none';
            }
        }

        chFilter.addEventListener('input', filterChapters);

        if (chClear) {
            chClear.addEventListener('click', function () {
                chFilter.value = '';
                filterChapters();
                chFilter.focus();
            });
        }

        chFilter.addEventListener('keydown', function (e) {
            if (e.key === 'Enter') {
                e.preventDefault();
                var firstVisible = document.querySelector('.chapter-item:not([style*="display: none"])');
                if (firstVisible) {
                    firstVisible.scrollIntoView({ behavior: 'smooth', block: 'center' });
                    firstVisible.classList.add('chapter-pulse');
                    setTimeout(function () {
                        firstVisible.classList.remove('chapter-pulse');
                    }, 1600);
                    var noEl = firstVisible.querySelector('.chapter-no');
                    var noText = noEl ? noEl.textContent.trim() : 'chương';
                    toastFn('📍 Đã chuyển đến ' + noText);
                }
            }
        });
    }
})();
</script>

<c:if test="${googleDriveEnabled and not story.comic and not empty currentUser and currentUser.id eq story.authorId}">
    <script>
        window.APP_CONTEXT = '${pageContext.request.contextPath}';
        window.GOOGLE_CLIENT_ID = '<c:out value="${googleClientId}"/>';
        window.CSRF_TOKEN = '<c:out value="${csrfToken}"/>';
    </script>
    <script src="${pageContext.request.contextPath}/assets/js/drive-backup.js" defer></script>
</c:if>

<%@ include file="/WEB-INF/views/_partials/_tip-modal.jsp" %>

