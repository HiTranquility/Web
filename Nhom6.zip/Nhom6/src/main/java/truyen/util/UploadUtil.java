package truyen.util;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.security.SecureRandom;
import java.time.LocalDate;
import java.util.Base64;
import javax.servlet.ServletContext;
import javax.servlet.http.Part;

/**
 * Nhận ảnh bìa người dùng tải lên.
 *
 * VÌ SAO LƯU NGOÀI THƯ MỤC WEBAPP
 *   Để trong webapp thì mỗi lần triển khai lại, Tomcat xoá sạch thư mục cũ và
 *   ảnh của người dùng bay theo. Đây đúng là cái bẫy getRealPath() — nó trả về
 *   một đường dẫn CÓ THẬT nên code chạy ngon, chỉ mất dữ liệu về sau.
 *
 *   Đường dẫn đọc từ context-param "uploadDir" trong web.xml: đổi máy chỉ cần
 *   sửa một dòng, không phải biên dịch lại.
 *
 * HẬU QUẢ: Tomcat KHÔNG tự phục vụ được thư mục đó nữa. Vì vậy có thêm
 * UploadedFileServlet map vào /uploads/* để đọc file ra. Đó là cái giá phải
 * trả, và trả là đúng.
 */
public final class UploadUtil {

    /** Giới hạn mềm; @MultipartConfig của servlet mới là chốt chặn thật. */
    public static final long MAX_BYTES = 2L * 1024 * 1024;   // 2 MB

    private static final SecureRandom RANDOM = new SecureRandom();

    private UploadUtil() { }

    /** Lỗi có câu chữ đưa thẳng cho người dùng đọc được. */
    public static class UploadException extends Exception {
        public UploadException(String message) { super(message); }
    }

    /**
     * Lưu file, trả về đường dẫn công khai ("/uploads/abc123.png").
     * Trả null nếu người dùng không chọn file nào.
     */
    public static String save(Part part, ServletContext ctx)
            throws UploadException, IOException {

        if (part == null || part.getSize() == 0) {
            return null;      // không chọn file -> không phải lỗi
        }
        if (part.getSize() > MAX_BYTES) {
            throw new UploadException("Ảnh quá "
                    + (MAX_BYTES / 1024 / 1024) + " MB. Chọn ảnh nhỏ hơn.");
        }

        String ext;
        try (InputStream in = part.getInputStream()) {
            ext = sniff(in);
        }
        if (ext == null) {
            throw new UploadException(
                    "File này không phải ảnh PNG, JPG, GIF hay WebP.");
        }

        File folder = resolveUploadFolder(ctx);

        /*
         * TÊN FILE DO MÌNH SINH, TUYỆT ĐỐI KHÔNG DÙNG TÊN NGƯỜI DÙNG GỬI LÊN.
         *
         * Tên gốc có thể là "../../../web.xml" (ghi đè file hệ thống), có thể
         * trùng tên file người khác (đè mất ảnh của họ), có thể chứa thẻ HTML
         * (thành lỗ XSS khi in tên ra trang). Sinh tên ngẫu nhiên là hết cả
         * ba, không cần lọc gì.
         */
        byte[] bytes = new byte[12];
        RANDOM.nextBytes(bytes);
        String name = Base64.getUrlEncoder().withoutPadding().encodeToString(bytes) + ext;

        Path dest = folder.toPath().resolve(name);
        try (InputStream in = part.getInputStream()) {
            Files.copy(in, dest, StandardCopyOption.REPLACE_EXISTING);
        }
        return "/uploads/" + name;
    }

    /** Tiền tố thư mục của ảnh bằng chứng — xem ghi chú ở {@link #saveEvidence}. */
    public static final String EVIDENCE_PREFIX = "evidence/";

    /**
     * Lưu một ảnh bằng chứng của báo cáo vi phạm (ISSUE-025).
     *
     * <p>Trả về đường dẫn <b>tương đối với thư mục uploads</b>, dạng
     * {@code evidence/2026/09/AbC123.jpg} — <b>không</b> có tiền tố
     * {@code /uploads/} như {@link #save}. Lý do: giá trị này đi thẳng vào cột
     * {@code report_evidence.file_path}, và bảng đó lưu đường dẫn tương đối để
     * còn đổi được chỗ chứa mà không phải sửa dữ liệu.
     *
     * <p><b>VÌ SAO PHẢI NẰM RIÊNG TRONG {@code evidence/}.</b> Ảnh bìa truyện
     * vốn để khoe, ai xem cũng được. Ảnh tố cáo thì ngược lại: nó có thể là
     * ảnh chụp tin nhắn riêng, thông tin cá nhân của người bị tố, hoặc chính
     * nội dung phản cảm đang bị báo cáo. {@code UploadedFileServlet} nhìn đúng
     * tiền tố này để chặn người không phải admin — nên đây là một <b>hàng
     * rào</b>, không phải quy ước đặt tên cho gọn.
     *
     * <p>Chia thêm theo {@code YYYY/MM} để một thư mục không phình tới hàng
     * vạn file — thư mục quá lớn làm chậm mọi thao tác trên file, và dọn dẹp
     * theo tháng cũng dễ hơn.
     *
     * @return đường dẫn tương đối, hoặc null nếu người dùng không chọn file
     */
    public static String saveEvidence(Part part, ServletContext ctx)
            throws UploadException, IOException {

        if (part == null || part.getSize() == 0) {
            return null;
        }
        if (part.getSize() > MAX_BYTES) {
            throw new UploadException("Ảnh bằng chứng quá "
                    + (MAX_BYTES / 1024 / 1024) + " MB. Chọn ảnh nhỏ hơn.");
        }

        String ext;
        try (InputStream in = part.getInputStream()) {
            ext = sniff(in);
        }
        if (ext == null) {
            throw new UploadException(
                    "File bằng chứng phải là ảnh PNG, JPG, GIF hoặc WebP.");
        }

        LocalDate today = LocalDate.now();
        String sub = EVIDENCE_PREFIX
                   + today.getYear() + "/"
                   + String.format("%02d", today.getMonthValue());

        File root = resolveUploadFolder(ctx);
        Path dir = root.toPath().resolve(sub);
        Files.createDirectories(dir);

        // Tên ngẫu nhiên, cùng lý lẽ với save(): không bao giờ dùng tên người
        // dùng gửi lên. Xem chú thích dài ở save().
        byte[] bytes = new byte[12];
        RANDOM.nextBytes(bytes);
        String name = Base64.getUrlEncoder().withoutPadding().encodeToString(bytes) + ext;

        try (InputStream in = part.getInputStream()) {
            Files.copy(in, dir.resolve(name), StandardCopyOption.REPLACE_EXISTING);
        }
        return sub + "/" + name;
    }

    /**
     * Xoá một ảnh bằng chứng khỏi ổ đĩa.
     *
     * <p>Cần vì {@code ON DELETE CASCADE} chỉ xoá <b>dòng</b> trong CSDL, file
     * thì nằm lại mãi mãi. Trả về true nếu xoá được.
     *
     * <p>Chỉ nhận đường dẫn bắt đầu bằng {@code evidence/} và từ chối mọi
     * đường có {@code ".."} — để một giá trị rác trong CSDL không biến hàm này
     * thành công cụ xoá file bất kỳ trên máy chủ.
     */
    public static boolean deleteEvidence(String relPath, ServletContext ctx) {
        if (relPath == null
                || !relPath.startsWith(EVIDENCE_PREFIX)
                || relPath.contains("..")) {
            return false;
        }
        try {
            Path root = resolveUploadFolder(ctx).toPath().toAbsolutePath().normalize();
            Path target = root.resolve(relPath).normalize();
            // Sau khi normalize vẫn phải nằm trong thư mục uploads.
            if (!target.startsWith(root)) {
                return false;
            }
            return Files.deleteIfExists(target);
        } catch (UploadException | IOException e) {
            return false;
        }
    }

    /**
     * Đọc vài byte đầu để đoán định dạng thật. Trả phần đuôi file, hoặc null
     * nếu không phải ảnh mình chấp nhận.
     *
     * Đây gọi là "magic number" — mỗi định dạng có một chuỗi byte mở đầu cố
     * định do chuẩn của nó quy định.
     */
    private static String sniff(InputStream in) throws IOException {
        byte[] h = new byte[12];
        int n = 0;
        while (n < h.length) {
            int r = in.read(h, n, h.length - n);
            if (r < 0) break;
            n += r;
        }
        if (n < 12) {
            return null;     // ngắn hơn cả phần đầu -> chắc chắn không phải ảnh
        }

        // PNG: 89 50 4E 47 0D 0A 1A 0A
        if ((h[0] & 0xFF) == 0x89 && h[1] == 'P' && h[2] == 'N' && h[3] == 'G') {
            return ".png";
        }
        // JPEG: FF D8 FF
        if ((h[0] & 0xFF) == 0xFF && (h[1] & 0xFF) == 0xD8 && (h[2] & 0xFF) == 0xFF) {
            return ".jpg";
        }
        // GIF: "GIF87a" hoac "GIF89a"
        if (h[0] == 'G' && h[1] == 'I' && h[2] == 'F') {
            return ".gif";
        }
        // WebP: "RIFF" ....(4 byte do dai).... "WEBP"
        if (h[0] == 'R' && h[1] == 'I' && h[2] == 'F' && h[3] == 'F'
                && h[8] == 'W' && h[9] == 'E' && h[10] == 'B' && h[11] == 'P') {
            return ".webp";
        }
        return null;
    }

    /**
     * Xác định thư mục lưu ảnh, tự động fallback an toàn nếu đường dẫn cấu hình
     * trong web.xml không khả dụng (ví dụ: Windows hardcode C:/ khi chạy trên macOS/Linux).
     */
    // ========================================================================
    //  Trang truyện tranh
    // ========================================================================

    /** Tiền tố thư mục ảnh trang — UploadedFileServlet KIỂM QUYỀN ĐỌC trước khi phát. */
    public static final String PAGES_PREFIX = "pages/";

    /**
     * Trang truyện tranh nặng hơn ảnh bìa nhiều (khổ dọc, chi tiết), nên giới
     * hạn riêng. Vẫn phải có trần: không có thì một chương 50 trang x 30 MB là
     * 1.5 GB cho một lần bấm "Lưu".
     */
    public static final long MAX_PAGE_BYTES = 5L * 1024 * 1024;   // 5 MB

    /** Kết quả lưu một trang: đường dẫn tương đối + kích thước (0 nếu không đọc được). */
    public static class SavedPage {
        public final String path;
        public final int width;
        public final int height;
        SavedPage(String path, int width, int height) {
            this.path = path; this.width = width; this.height = height;
        }
    }

    /**
     * Lưu một ảnh trang vào pages/{storyId}/{chapterId}/ với tên ngẫu nhiên.
     *
     * Thư mục theo chương: xoá chương là xoá gọn cả thư mục, và UploadedFileServlet
     * đọc được chapterId ngay từ đường dẫn để kiểm quyền mà khỏi tra CSDL.
     */
    public static SavedPage savePage(Part part, int storyId, int chapterId, ServletContext ctx)
            throws UploadException, IOException {
        if (part == null || part.getSize() == 0) return null;
        if (part.getSize() > MAX_PAGE_BYTES) {
            throw new UploadException("Có trang nặng quá " + (MAX_PAGE_BYTES / 1024 / 1024)
                    + " MB (" + safeName(part) + "). Nén ảnh lại rồi thử lại nhé.");
        }
        String ext;
        try (InputStream in = part.getInputStream()) {
            ext = sniff(in);
        }
        if (ext == null) {
            throw new UploadException("\"" + safeName(part) + "\" không phải ảnh PNG, JPG, GIF hay WebP.");
        }
        int[] dim;
        try (InputStream in = part.getInputStream()) {
            dim = ImageInfo.dimensions(in);
        }

        String sub = PAGES_PREFIX + storyId + "/" + chapterId;
        Path dir = resolveUploadFolder(ctx).toPath().resolve(sub);
        Files.createDirectories(dir);

        byte[] bytes = new byte[12];
        RANDOM.nextBytes(bytes);
        String name = Base64.getUrlEncoder().withoutPadding().encodeToString(bytes) + ext;
        try (InputStream in = part.getInputStream()) {
            Files.copy(in, dir.resolve(name), StandardCopyOption.REPLACE_EXISTING);
        }
        return new SavedPage(sub + "/" + name, dim == null ? 0 : dim[0], dim == null ? 0 : dim[1]);
    }

    /** Xoá một file trang. Chỉ nhận đường dẫn trong pages/ — không bao giờ xoá lan ra ngoài. */
    public static boolean deletePage(String relPath, ServletContext ctx) {
        if (relPath == null || !relPath.startsWith(PAGES_PREFIX) || relPath.contains("..")) {
            return false;
        }
        try {
            Path root = resolveUploadFolder(ctx).toPath().toAbsolutePath().normalize();
            Path target = root.resolve(relPath).normalize();
            if (!target.startsWith(root.resolve(PAGES_PREFIX))) return false;
            return Files.deleteIfExists(target);
        } catch (UploadException | IOException e) {
            return false;
        }
    }

    /**
     * Lấy chapterId từ đường dẫn "pages/{storyId}/{chapterId}/x.jpg".
     * @return chapterId, hoặc 0 nếu đường dẫn không đúng dạng.
     */
    public static int chapterIdOfPage(String relPath) {
        if (relPath == null || !relPath.startsWith(PAGES_PREFIX)) return 0;
        String[] seg = relPath.substring(PAGES_PREFIX.length()).split("/");
        if (seg.length != 3) return 0;
        try {
            int id = Integer.parseInt(seg[1]);
            return id > 0 ? id : 0;
        } catch (NumberFormatException e) {
            return 0;
        }
    }

    /** Tên file người dùng chọn — CHỈ để in vào thông báo lỗi, đã cắt ngắn. */
    private static String safeName(Part part) {
        String n = part.getSubmittedFileName();
        if (n == null || n.isEmpty()) return "ảnh";
        n = n.replaceAll("[\\r\\n\"<>]", "");
        return n.length() > 60 ? n.substring(0, 60) + "…" : n;
    }

    public static File resolveUploadFolder(ServletContext ctx) throws UploadException {
        String dir = ctx.getInitParameter("uploadDir");
        File folder = null;
        if (dir != null && !dir.trim().isEmpty()) {
            folder = new File(dir.trim());
        }
        if (folder == null || (!folder.exists() && !folder.mkdirs())) {
            String fallback = System.getProperty("user.home") + File.separator + "truyen-uploads";
            folder = new File(fallback);
            if (!folder.isDirectory() && !folder.mkdirs()) {
                throw new UploadException("Không tạo được thư mục lưu ảnh: " + folder.getAbsolutePath());
            }
        }
        return folder;
    }
}
