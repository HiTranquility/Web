package truyen.controller.admin;

import java.io.IOException;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import truyen.dao.CommentDAO;
import static truyen.util.ServletHelper.parseIntOr;

/** TRANG 29 — Quản lý bình luận. */
@WebServlet("/admin/comment")
public class AdminCommentServlet extends HttpServlet {

    private CommentDAO commentDAO;

    @Override
    public void init() throws ServletException {
        commentDAO = new CommentDAO();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        handle(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        handle(request, response);
    }

    private void handle(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        request.setCharacterEncoding("UTF-8");
        String action = request.getParameter("action");
        String filter = request.getParameter("filter");

        if ("hide".equals(action) || "unhide".equals(action)) {
            if (!"POST".equalsIgnoreCase(request.getMethod())) {
                response.sendError(HttpServletResponse.SC_METHOD_NOT_ALLOWED);
                return;
            }
        }

        try {
            if ("hide".equals(action)) {
                int cId = parseIntOr(request.getParameter("id"), 0);
                commentDAO.hide(cId);
                truyen.model.User me = truyen.util.ServletHelper.currentUser(request);
                new truyen.dao.AuditDAO().log(me != null ? me.getId() : 0, "HIDE_COMMENT", "COMMENT", cId, "Bình luận #" + cId, "Ẩn bình luận vi phạm");
                response.sendRedirect(request.getContextPath() + "/admin/comment"
                        + (filter != null && !filter.isEmpty() ? "?filter=" + filter : ""));
                return;
            } else if ("unhide".equals(action)) {
                int cId = parseIntOr(request.getParameter("id"), 0);
                commentDAO.unhide(cId);
                truyen.model.User me = truyen.util.ServletHelper.currentUser(request);
                new truyen.dao.AuditDAO().log(me != null ? me.getId() : 0, "SHOW_COMMENT", "COMMENT", cId, "Bình luận #" + cId, "Khôi phục hiển thị bình luận");
                response.sendRedirect(request.getContextPath() + "/admin/comment"
                        + (filter != null && !filter.isEmpty() ? "?filter=" + filter : ""));
                return;
            }

            boolean onlyHidden = "hidden".equals(filter);
            request.setAttribute("comments", commentDAO.findAllForAdmin(onlyHidden));
            request.setAttribute("filter", filter);

        } catch (SQLException e) {
            log("AdminCommentServlet: lỗi truy vấn, action=" + action, e);
            request.setAttribute("message", "Không tải được danh sách bình luận.");
            request.setAttribute("comments", java.util.Collections.emptyList());
        }

        request.setAttribute("pageTitle", "Quản trị — Bình luận");
        request.setAttribute("activeNav", "admin");
        request.setAttribute("adminSection", "comment");
        request.setAttribute("contentPage", "/WEB-INF/views/admin/comments.jsp");
        getServletContext()
                .getRequestDispatcher("/WEB-INF/views/layout/admin.jsp")
                .forward(request, response);
    }
}
