package truyen.controller.common;

import java.io.IOException;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import java.security.SecureRandom;
import java.util.Base64;

import truyen.dao.IdentityDAO;
import truyen.dao.PasswordResetDAO;
import truyen.dao.UserDAO;
import truyen.model.User;
import truyen.model.UserIdentity;
import truyen.util.GoogleConfig;
import truyen.util.GoogleTokenVerifier;
import truyen.util.PasswordUtil;
import truyen.util.RateLimiter;

import static truyen.util.ServletHelper.trimOrEmpty;

/** CASE 01 — Đăng ký / Đăng nhập / Đăng xuất. */
@WebServlet("/auth")
public class AuthServlet extends HttpServlet {

    private UserDAO userDAO;
    private PasswordResetDAO resetDAO;
    private IdentityDAO identityDAO;
    private GoogleTokenVerifier googleTokenVerifier;

    /* SecureRandom, KHÔNG phải Random. */
    private static final SecureRandom RANDOM = new SecureRandom();

    @Override
    public void init() throws ServletException {
        userDAO = new UserDAO();
        resetDAO = new PasswordResetDAO();
        identityDAO = new IdentityDAO();
        googleTokenVerifier = new GoogleTokenVerifier();
    }

    public void setGoogleTokenVerifier(GoogleTokenVerifier verifier) {
        this.googleTokenVerifier = verifier;
    }

    // GET: hiện form. POST: xử lý form. Cả hai vào chung handle().
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        handle(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        handle(request, response);
    }

    private void handle(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // Trước mọi getParameter() — nếu không, tên tiếng Việt thành dấu hỏi
        request.setCharacterEncoding("UTF-8");

        String action = request.getParameter("action");
        if (action == null) {
            action = "login";
        }

        String url;
        try {
            switch (action) {
                case "logout":
                    logout(request, response);
                    return;                       // đã redirect, KHÔNG forward nữa
                case "register":
                    url = register(request, response);
                    break;
                case "forgot":
                    url = forgot(request);
                    break;
                case "reset":
                    url = reset(request, response);
                    break;
                case "firebase-google":
                    firebaseGoogleLogin(request, response);
                    return;
                case "login":
                    url = login(request, response);
                    break;
                default:
                    response.sendError(HttpServletResponse.SC_NOT_FOUND);
                    return;
            }
        } catch (SQLException e) {
            log("AuthServlet: lỗi truy vấn khi action=" + action, e);
            if ("firebase-google".equals(action) || "1".equals(request.getParameter("ajax"))) {
                sendJsonResponse(response, false, "Hệ thống đang bận, vui lòng thử lại.", null);
                return;
            }
            request.setAttribute("message", "Hệ thống đang bận, vui lòng thử lại.");
            if ("register".equals(action)) {
                url = "/WEB-INF/views/auth/register.jsp";
            } else if ("forgot".equals(action)) {
                url = "/WEB-INF/views/auth/forgot.jsp";
            } else {
                url = "/WEB-INF/views/auth/login.jsp";
            }
        }

        // url là null nghĩa là method con đã redirect xong -> không forward nữa
        if (url == null) {
            return;
        }

        request.setAttribute("contentPage", url);
        request.setAttribute("googleEnabled", GoogleConfig.isEnabled());
        request.setAttribute("googleApiKey", GoogleConfig.getApiKey());
        request.setAttribute("googleAuthDomain", GoogleConfig.getAuthDomain());
        request.setAttribute("googleProjectId", GoogleConfig.getProjectId());
        request.setAttribute("googleAppId", GoogleConfig.getAppId());
        getServletContext()
                .getRequestDispatcher("/WEB-INF/views/layout/auth.jsp")
                .forward(request, response);
    }

    // ---- ĐĂNG NHẬP ---------------------------------------------------------

    private String login(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException {

        request.setAttribute("pageTitle", "Đăng nhập");

        // GET = chỉ hiện form, chưa có gì để xử lý
        if (!"POST".equals(request.getMethod())) {
            String redirect = request.getParameter("redirect");
            String safeRedirect = truyen.util.RedirectUtil.localPath(redirect, request.getContextPath());
            if (safeRedirect != null) {
                request.getSession(true).setAttribute("redirectAfterLogin", safeRedirect);
            }
            String reason = request.getParameter("reason");
            if ("bookmark".equals(reason)) {
                request.getSession(true).setAttribute("flash", "Vui lòng đăng nhập để lưu truyện vào tủ sách nhé!");
            } else if ("follow".equals(reason)) {
                request.getSession(true).setAttribute("flash", "Vui lòng đăng nhập để theo dõi tác giả nhé!");
            }
            return "/WEB-INF/views/auth/login.jsp";
        }

        String username = trimOrEmpty(request.getParameter("username"));
        String password = request.getParameter("password");
        String clientIp = RateLimiter.getClientIp(request);

        // Kiểm tra xem IP + username có đang bị tạm khóa do brute-force không
        if (RateLimiter.isLoginBlocked(clientIp, username)) {
            long remainingMin = RateLimiter.getLoginBlockedRemainingMinutes(clientIp, username);
            request.setAttribute("message", "Bạn đã thử đăng nhập sai quá nhiều lần ("
                    + RateLimiter.MAX_LOGIN_ATTEMPTS + " lần). Vui lòng thử lại sau "
                    + remainingMin + " phút.");
            request.setAttribute("username", username);
            return "/WEB-INF/views/auth/login.jsp";
        }

        if (username.isEmpty() || password == null || password.isEmpty()) {
            request.setAttribute("message", "Vui lòng nhập đủ tên đăng nhập và mật khẩu.");
            request.setAttribute("username", username);   // giữ lại chữ đã gõ
            return "/WEB-INF/views/auth/login.jsp";
        }

        User user = userDAO.findByUsername(username);

        // Hướng dẫn nếu tài khoản đăng ký qua Google nhưng chưa đặt mật khẩu
        if (user != null && !user.hasPassword()) {
            request.setAttribute("message", "Tài khoản này được đăng ký qua Google. Vui lòng bấm 'Đăng nhập với Google' bên dưới, hoặc dùng 'Quên mật khẩu' để đặt mật khẩu mới.");
            request.setAttribute("username", username);
            return "/WEB-INF/views/auth/login.jsp";
        }

        /* MỘT THÔNG BÁO CHUNG CHO CẢ HAI TRƯỜNG HỢP SAI.
           Mật khẩu dài quá trần thì không thể đúng (đăng ký không cho đặt) —
           coi là sai luôn, khỏi chạy PBKDF2 trên vài MB dữ liệu rác. */
        if (user == null || password.length() > PasswordUtil.MAX_LENGTH
                || !PasswordUtil.verify(password, user.getPasswordHash())) {
            RateLimiter.recordLoginFailure(clientIp, username);
            int remaining = RateLimiter.getRemainingAttempts(clientIp, username);
            String warn = remaining > 0 ? " (Bạn còn " + remaining + " lần thử)" : " (Tài khoản bị tạm khóa 15 phút)";
            request.setAttribute("message", "Tên đăng nhập hoặc mật khẩu không đúng." + warn);
            request.setAttribute("username", username);
            return "/WEB-INF/views/auth/login.jsp";
        }

        // Đăng nhập thành công -> xóa lịch sử thất bại của IP + username
        RateLimiter.resetLoginAttempts(clientIp, username);

        // Bị ban thì chặn đăng nhập, nhưng truyện của họ vẫn còn trên web
        if (user.isBanned()) {
            String reason = (user.getBanReason() == null || user.getBanReason().isEmpty())
                    ? "" : " Lý do: " + user.getBanReason();
            request.setAttribute("message", "Tài khoản đã bị khoá." + reason);
            return "/WEB-INF/views/auth/login.jsp";
        }

        /*
         * LẤY ĐÍCH ĐẾN RA TRƯỚC KHI HUỶ PHIÊN.
         *
         * AuthFilter/AdminFilter lưu "redirectAfterLogin" vào phiên CŨ khi đá
         * khách về đây. Ngay dưới là lệnh invalidate() — huỷ phiên là xoá sạch
         * mọi thuộc tính trong đó, kể cả cái này. Đọc sau khi huỷ thì luôn
         * nhận null và người dùng luôn bị ném về trang chủ.
         *
         * Không đổi được thứ tự: đổi id phiên PHẢI làm trước khi đặt
         * currentUser, nếu không thì kẻ tấn công đã biết id phiên từ trước
         * vẫn dùng lại được nó sau khi nạn nhân đăng nhập (session fixation).
         */
        HttpSession old = request.getSession(false);
        String target = old == null ? null : (String) old.getAttribute("redirectAfterLogin");
        if (old != null) {
            old.invalidate();
        }
        HttpSession session = request.getSession(true);

        // KHÔNG mang chuỗi băm vào session — không có lý do gì để nó ở đó
        user.setPasswordHash(null);
        // Thống kê đọc không được ngăn việc nạp quyền.
        try {
            user.setReadChapters(userDAO.countReadChapters(user.getId()));
        } catch (SQLException ex) {
            log("Không tải được thống kê đọc khi đăng nhập.");
        }
        try {
            new truyen.dao.RbacDAO().populateRbac(user);
        } catch (SQLException ex) {
            log("Không tải được quyền bổ sung khi đăng nhập.");
        }
        session.setAttribute("currentUser", user);

        /*
         * REDIRECT chứ không forward.
         * Mẫu Post/Redirect/Get: sau khi POST đã làm thay đổi trạng thái, kết
         * thúc bằng redirect thì request cuối trong lịch sử là một GET vô hại.
         * F5 chỉ tải lại trang, không gửi lại form đăng nhập.
         */
        response.sendRedirect(request.getContextPath() + landingPage(user, target));
        return null;
    }

    /**
     * Đăng nhập xong thì thả người dùng xuống đâu?
     *
     * Thứ tự ưu tiên, dừng ở điều kiện đầu tiên đúng:
     *
     *   1. NƠI HỌ ĐỊNH ĐẾN. Ai đó bấm vào link một chương, bị đá về đăng nhập,
     *      thì đăng nhập xong phải thấy đúng chương đó. Ném về trang chủ là bắt
     *      họ tự mò lại từ đầu — mà thường là họ bỏ luôn.
     *
     *   2. ADMIN -> thẳng bảng điều khiển. Admin đăng nhập gần như luôn là để
     *      làm việc quản trị, không phải để đọc truyện. Thả xuống trang chủ rồi
     *      bắt tìm menu là thừa một bước cho mọi lần đăng nhập.
     *
     *   3. Còn lại -> trang chủ.
     *
     * KIỂM ĐÍCH ĐẾN TRƯỚC KHI DÙNG
     *   target lấy từ getRequestURI() nên vốn đã là đường dẫn nội bộ. Nhưng
     *   hàm này không tự biết điều đó, và chỉ cần sau này có ai truyền đích đến
     *   qua tham số URL là lỗ hổng chuyển hướng mở (open redirect) xuất hiện:
     *   trang đăng nhập của chính mình lại đẩy người dùng sang web lừa đảo.
     *
     *   Nên chặn ngay tại đây: bắt buộc bắt đầu bằng "/" và KHÔNG bắt đầu bằng
     *   "//" — vì "//ac.com/x" là URL tuyệt đối hợp lệ trong trình duyệt, chỉ
     *   là viết tắt phần giao thức.
     */
    private String landingPage(User user, String target) {
        return truyen.util.RedirectUtil.afterLogin(user, target, getServletContext().getContextPath());
    }

    // ---- ĐĂNG KÝ -----------------------------------------------------------

    private String register(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException {

        request.setAttribute("pageTitle", "Đăng ký");

        if (!"POST".equals(request.getMethod())) {
            return "/WEB-INF/views/auth/register.jsp";
        }

        String username = trimOrEmpty(request.getParameter("username"));
        String email    = trimOrEmpty(request.getParameter("email"));
        String password = request.getParameter("password");
        String confirm  = request.getParameter("confirm");
        String agree    = request.getParameter("agree");

        // Giữ lại chữ đã gõ để lỗi thì không phải nhập lại từ đầu
        request.setAttribute("username", username);
        request.setAttribute("email", email);

        String message = validateRegister(username, email, password, confirm, agree);
        if (message == null && userDAO.exists(username, email)) {
            message = "Tên đăng nhập hoặc email này đã có người dùng.";
        }
        if (message != null) {
            request.setAttribute("message", message);
            return "/WEB-INF/views/auth/register.jsp";
        }

        User user = new User();
        user.setUsername(username);
        user.setEmail(email);
        user.setDisplayName(username);

        // Băm Ở ĐÂY, không phải trong DAO. DAO chỉ đọc ghi database.
        user.setPasswordHash(PasswordUtil.hash(password));

        userDAO.insert(user);

        // Đăng ký xong đăng nhập luôn — đỡ bắt người dùng gõ lại
        user.setPasswordHash(null);
        HttpSession old = request.getSession(false);
        if (old != null) old.invalidate();
        request.getSession(true).setAttribute("currentUser", user);

        response.sendRedirect(request.getContextPath() + "/");
        return null;
    }

    /**
     * Trả về câu báo lỗi, hoặc null nếu mọi thứ hợp lệ.
     *
     * Tách riêng để method register() ở trên đọc là hiểu luồng, không bị chìm
     * trong một khối if dài mười mấy dòng.
     */
    private String validateRegister(String username, String email,
                                    String password, String confirm, String agree) {
        if (username.isEmpty() || email.isEmpty()
                || password == null || password.isEmpty()) {
            return "Vui lòng điền đủ các ô.";
        }
        if (username.length() < 3 || username.length() > 50) {
            return "Tên đăng nhập phải từ 3 đến 50 ký tự.";
        }
        // Chỉ cho chữ, số, gạch dưới — vì username đi vào URL trang cá nhân
        if (!username.matches("[a-zA-Z0-9_]+")) {
            return "Tên đăng nhập chỉ được dùng chữ, số và dấu gạch dưới.";
        }
        if (!truyen.util.ServletHelper.isValidEmail(email)) {
            return "Email không hợp lệ (tối đa " + truyen.util.ServletHelper.EMAIL_MAX + " ký tự).";
        }
        String pwError = truyen.util.PasswordUtil.lengthError(password);
        if (pwError != null) {
            return pwError;
        }
        if (!password.equals(confirm)) {
            return "Hai ô mật khẩu không khớp nhau.";
        }
        // Mục tiêu đồ án: người dùng phải đồng ý nội quy trước khi tham gia
        if (agree == null) {
            return "Bạn cần đồng ý với nội quy cộng đồng.";
        }
        return null;
    }

    // ---- ĐĂNG XUẤT ---------------------------------------------------------

    private void logout(HttpServletRequest request, HttpServletResponse response)
            throws IOException {
        /*
         * CHỐNG LOGOUT CSRF (bug-009):
         * Phương thức POST bắt buộc phải mang CSRF token hợp lệ (đã được CsrfFilter kiểm soát).
         * Với phương thức GET: chỉ chấp nhận huỷ phiên khi có đính kèm CSRF token hợp lệ của phiên
         * (chống tấn công Logout CSRF qua thẻ <img> nhưng vẫn cho phép huỷ phiên an toàn nếu có token).
         * Nếu GET không có token hợp lệ -> từ chối huỷ phiên và chuyển hướng an toàn về trang chủ.
         */
        boolean isPost = "POST".equalsIgnoreCase(request.getMethod());
        boolean isGetWithCsrf = "GET".equalsIgnoreCase(request.getMethod()) && truyen.util.CsrfUtil.isValid(request);

        if (!isPost && !isGetWithCsrf) {
            response.sendRedirect(request.getContextPath() + "/");
            return;
        }

        HttpSession session = request.getSession(false);
        if (session != null) {
            /*
             * invalidate() xoá TOÀN BỘ phiên, không phải chỉ removeAttribute.
             * Xoá mỗi currentUser thì mọi thứ khác trong phiên vẫn còn, và id
             * phiên cũ vẫn dùng được — người dùng máy chung sẽ để lại dấu vết.
             */
            session.invalidate();
        }
        response.sendRedirect(request.getContextPath() + "/");
    }

    /** null-safe trim: getParameter trả null khi ô không được gửi lên. */

    // ---- QUÊN MẬT KHẨU -----------------------------------------------------

    /** TRANG 21 — Xin cấp vé đặt lại mật khẩu (ISSUE-002: gửi qua email, không in ra màn hình). */
    private String forgot(HttpServletRequest request) throws SQLException {
        String email = trimOrEmpty(request.getParameter("email"));
        String clientIp = RateLimiter.getClientIp(request);

        if ("POST".equalsIgnoreCase(request.getMethod()) && !email.isEmpty()) {
            if (RateLimiter.isForgotSpam(clientIp, email)) {
                request.setAttribute("message", "Bạn đã yêu cầu gửi email quá nhiều lần. Vui lòng chờ 15 phút để bảo vệ tài khoản.");
                request.setAttribute("pageTitle", "Quên mật khẩu");
                return "/WEB-INF/views/auth/forgot.jsp";
            }
            RateLimiter.recordForgot(clientIp, email);

            User u = userDAO.findByEmail(email);
            if (u != null) {
                String token = newToken();
                resetDAO.create(token, u.getId());

                // Dựng liên kết đầy đủ gửi đến hòm thư người dùng
                String scheme = request.getScheme();
                String serverName = request.getServerName();
                int serverPort = request.getServerPort();
                String portPart = (serverPort == 80 || serverPort == 443) ? "" : (":" + serverPort);
                String resetUrl = scheme + "://" + serverName + portPart
                        + request.getContextPath() + "/auth?action=reset&token=" + token;

                // Gửi thư ngầm (không làm chậm trang web)
                truyen.util.MailSender.sendPasswordResetEmailAsync(u.getEmail(), u.getName(), resetUrl);

                // Nếu đang ở môi trường phát triển / đồ án (chưa có SMTP thật), cung cấp devLink để demo
                if (!truyen.util.MailSender.isMailEnabled()) {
                    request.setAttribute("devLink", resetUrl);
                }
            }
            // Luôn báo sent = true để không lộ thông tin email có tồn tại hay không (OWASP recommendation)
            request.setAttribute("sent", true);
        }

        request.setAttribute("pageTitle", "Quên mật khẩu");
        return "/WEB-INF/views/auth/forgot.jsp";
    }

    /** TRANG 22 — Đặt lại mật khẩu bằng vé. */
    private String reset(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException {

        String token = trimOrEmpty(request.getParameter("token"));
        int userId = resetDAO.findValidUserId(token);

        if (userId == 0) {
            request.setAttribute("message",
                    "Liên kết không hợp lệ hoặc đã hết hạn. Hãy xin lại liên kết mới.");
            request.setAttribute("pageTitle", "Đặt lại mật khẩu");
            return "/WEB-INF/views/auth/forgot.jsp";
        }

        request.setAttribute("token", token);
        request.setAttribute("pageTitle", "Đặt lại mật khẩu");

        if (!"POST".equalsIgnoreCase(request.getMethod())) {
            return "/WEB-INF/views/auth/reset.jsp";
        }

        String pass    = request.getParameter("password");
        String confirm = request.getParameter("confirmPassword");

        String pwError = truyen.util.PasswordUtil.lengthError(pass);
        if (pwError != null) {
            request.setAttribute("message", pwError);
            return "/WEB-INF/views/auth/reset.jsp";
        }
        if (!pass.equals(confirm)) {
            request.setAttribute("message", "Hai lần nhập không khớp.");
            return "/WEB-INF/views/auth/reset.jsp";
        }

        // Kiểm tra lại hiệu lực ngay lúc ghi để hai POST không dùng lại cùng vé.
        if (!resetDAO.resetPassword(token, PasswordUtil.hash(pass))) {
            request.setAttribute("message", "Liên kết không hợp lệ hoặc đã hết hạn. Hãy xin lại liên kết mới.");
            return "/WEB-INF/views/auth/forgot.jsp";
        }

        request.getSession().setAttribute("flash",
                "Đã đổi mật khẩu. Đăng nhập lại nhé.");
        response.sendRedirect(request.getContextPath() + "/auth?action=login");
        return null;
    }

    /** Sinh token 32 byte ngẫu nhiên, mã hoá base64 an-toàn-cho-URL. */
    private String newToken() {
        byte[] bytes = new byte[32];
        RANDOM.nextBytes(bytes);
        return Base64.getUrlEncoder().withoutPadding().encodeToString(bytes);
    }

    /**
     * ĐĂNG NHẬP / ĐĂNG KÝ BẰNG GOOGLE QUA FIREBASE AUTH (ISSUE-001 Phase 2)
     *
     * Thứ tự kiểm tra nghiêm ngặt (chặn đứng bug-001):
     *   1. Không phải POST                      -> 405
     *   2. GoogleConfig.isEnabled() == false    -> JSON success:false
     *   3. idToken rỗng                         -> JSON success:false
     *   4. verifier.verify(idToken) == null     -> JSON success:false (Chặn giả mạo)
     *   -- từ dòng này trở xuống, KHÔNG đọc request.getParameter("email"|"uid") --
     *   5. sub, email, name, picture := lấy từ GoogleUser đã verify
     *   6. identity := IdentityDAO.findByProviderUid("GOOGLE", sub)
     *      6a. có   -> user := UserDAO.findById(identity.getUserId())
     *      6b. chưa -> UserDAO.findByEmail(email)
     *          - ra user -> JSON success:false (Không tự gắn - chống Account Takeover)
     *          - null    -> tạo user mới (password_hash = NULL) + IdentityDAO.insert(...)
     *   7. user.isAdmin()  -> JSON success:false
     *   8. user.isBanned() -> JSON success:false + lý do
     *   9. session.invalidate() rồi getSession(true) (chống Session Fixation)
     *   10. đặt currentUser vào phiên, JSON success:true
     */
    private void firebaseGoogleLogin(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException {

        if (!"POST".equalsIgnoreCase(request.getMethod())) {
            response.sendError(HttpServletResponse.SC_METHOD_NOT_ALLOWED);
            return;
        }

        if (!GoogleConfig.isEnabled()) {
            sendJsonResponse(response, false, "Đăng nhập Google hiện chưa được kích hoạt.", null);
            return;
        }

        String idToken = trimOrEmpty(request.getParameter("idToken"));
        if (idToken.isEmpty()) {
            sendJsonResponse(response, false, "Thiếu mã xác thực Google (idToken).", null);
            return;
        }

        // BẢO MẬT: Kiểm tra chữ ký số idToken qua máy chủ OIDC của Google (Chặn đứng bug-001)
        GoogleTokenVerifier.GoogleUser googleUser = googleTokenVerifier.verify(idToken);
        if (googleUser == null) {
            sendJsonResponse(response, false, "Xác minh tài khoản Google thất bại hoặc phiên đã hết hạn. Vui lòng thử lại.", null);
            return;
        }

        // TUYỆT ĐỐI KHÔNG đọc request.getParameter("email") hay ("uid")
        String sub = googleUser.getSub();
        String email = googleUser.getEmail();
        String displayName = googleUser.getName() != null ? googleUser.getName() : "";
        String photoUrl = googleUser.getPicture() != null ? googleUser.getPicture() : "";
        if (photoUrl.length() > 1000) {
            photoUrl = photoUrl.substring(0, 1000);
        }

        UserIdentity identity = identityDAO.findByProviderUid("GOOGLE", sub);
        User user = null;

        if (identity != null) {
            // Đã liên kết trước đó: đăng nhập lần 2 trở đi
            user = userDAO.findById(identity.getUserId());
            if (user == null) {
                sendJsonResponse(response, false, "Không tìm thấy thông tin tài khoản người dùng.", null);
                return;
            }
            // Cập nhật avatar nếu người dùng chưa có
            if ((user.getAvatarUrl() == null || user.getAvatarUrl().isEmpty()) && !photoUrl.isEmpty()) {
                userDAO.updateAvatar(user.getId(), photoUrl);
                user.setAvatarUrl(photoUrl);
            }
        } else {
            // Chưa có liên kết Google: kiểm tra xem email đã có tài khoản mật khẩu chưa
            User existingUser = userDAO.findByEmail(email);
            if (existingUser != null) {
                // TUYỆT ĐỐI KHÔNG tự gắn Google vào tài khoản đã có (Chống Account Takeover - bug-001)
                sendJsonResponse(response, false,
                        "Email này (" + email + ") đã có tài khoản trên hệ thống. " +
                        "Vui lòng đăng nhập bằng mật khẩu, sau đó vào trang Hồ sơ cá nhân để liên kết tài khoản Google.", null);
                return;
            }

            // Tạo tài khoản mới: password_hash = NULL (vì chỉ dùng Google)
            String baseUsername = email.substring(0, email.indexOf('@')).replaceAll("[^a-zA-Z0-9_]", "_");
            if (baseUsername.length() < 3) {
                baseUsername = "user_" + baseUsername;
            }
            if (baseUsername.length() > 40) {
                baseUsername = baseUsername.substring(0, 40);
            }

            String username = baseUsername;
            int attempts = 0;
            while (userDAO.findByUsername(username) != null && attempts < 10) {
                username = baseUsername + "_" + (RANDOM.nextInt(9000) + 1000);
                attempts++;
            }

            user = new User();
            user.setUsername(username);
            user.setEmail(email);
            user.setDisplayName(displayName.isEmpty() ? username : displayName);
            user.setAvatarUrl(photoUrl.isEmpty() ? null : photoUrl);
            user.setRole("USER");
            user.setStatus("ACTIVE");
            user.setPasswordHash(null); // NULL: Tài khoản Google không cần chuỗi băm rác

            userDAO.insert(user);
            int newUserId = user.getId();

            // Ghi nhận liên kết vào user_identities
            UserIdentity newIdentity = new UserIdentity(newUserId, "GOOGLE", sub, email);
            identityDAO.insert(newIdentity);
        }

        // BẢO MẬT: Chặn tuyệt đối tài khoản ADMIN đăng nhập qua Google
        if (user.isAdmin()) {
            sendJsonResponse(response, false,
                    "Tài khoản Quản trị viên (ADMIN) không được phép đăng nhập qua Google. Vui lòng đăng nhập bằng mật khẩu.", null);
            return;
        }

        if (user.isBanned()) {
            String reason = (user.getBanReason() == null || user.getBanReason().isEmpty())
                    ? "" : " Lý do: " + user.getBanReason();
            sendJsonResponse(response, false, "Tài khoản của bạn đã bị khoá." + reason, null);
            return;
        }

        // Tái tạo phiên đăng nhập (chống Session Fixation)
        HttpSession old = request.getSession(false);
        String target = old == null ? null : (String) old.getAttribute("redirectAfterLogin");
        if (old != null) {
            old.invalidate();
        }
        HttpSession session = request.getSession(true);

        user.setPasswordHash(null);
        // Thống kê đọc không được ngăn việc nạp quyền.
        try {
            user.setReadChapters(userDAO.countReadChapters(user.getId()));
        } catch (SQLException ex) {
            log("Không tải được thống kê đọc khi đăng nhập.");
        }
        try {
            new truyen.dao.RbacDAO().populateRbac(user);
        } catch (SQLException ex) {
            log("Không tải được quyền bổ sung khi đăng nhập.");
        }
        session.setAttribute("currentUser", user);

        String redirect = request.getContextPath() + landingPage(user, target);

        boolean isAjax = "XMLHttpRequest".equalsIgnoreCase(request.getHeader("X-Requested-With"))
                || (request.getHeader("Accept") != null && request.getHeader("Accept").contains("application/json"))
                || "1".equals(request.getParameter("ajax"));

        if (isAjax) {
            sendJsonResponse(response, true, "Đăng nhập Google thành công!", redirect);
        } else {
            response.sendRedirect(redirect);
        }
    }

    private void sendJsonResponse(HttpServletResponse response, boolean success, String message, String redirect)
            throws IOException {
        response.setContentType("application/json;charset=UTF-8");
        StringBuilder sb = new StringBuilder();
        sb.append("{");
        sb.append("\"success\":").append(success).append(",");
        sb.append("\"message\":\"").append(escapeJson(message)).append("\"");
        if (redirect != null) {
            sb.append(",\"redirect\":\"").append(escapeJson(redirect)).append("\"");
        }
        sb.append("}");
        response.getWriter().write(sb.toString());
    }

    private String escapeJson(String s) {
        if (s == null) return "";
        return s.replace("\\", "\\\\")
                .replace("\"", "\\\"")
                .replace("\n", "\\n")
                .replace("\r", "\\r");
    }

}
