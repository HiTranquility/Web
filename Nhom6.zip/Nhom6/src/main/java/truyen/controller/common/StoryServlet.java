package truyen.controller.common;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import truyen.dao.BookmarkDAO;
import truyen.dao.ChapterDAO;
import truyen.dao.CommentDAO;
import truyen.dao.StoryDAO;
import truyen.dao.FollowDAO;
import truyen.dao.RatingDAO;
import truyen.dao.TagDAO;
import truyen.util.AppListener;
import truyen.model.Chapter;
import truyen.model.Story;
import truyen.model.Tag;
import truyen.model.User;
import truyen.util.DBConnection;
import truyen.util.GoogleConfig;
import truyen.util.ServletHelper;
import truyen.util.SlugUtil;
import truyen.util.UploadUtil;
import truyen.util.ChapterAccess;

import static truyen.util.ServletHelper.parseIntOr;
import static truyen.util.ServletHelper.trimOrEmpty;

/**
 * CASE 02, 03, 04, 05 — Truyện.
 *
 * @MultipartConfig BẮT BUỘC để nhận ảnh bìa tải lên. Thiếu nó thì
 * request.getPart() ném IllegalStateException, và tệ hơn: mọi
 * getParameter() trên form multipart đều trả null — form gửi lên trông như
 * người dùng bỏ trống hết mọi ô, không có lỗi nào để lần ra.
 *
 * maxFileSize là chốt chặn THẬT (UploadUtil.MAX_BYTES chỉ để báo lỗi tử tế):
 * Tomcat từ chối ngay khi đọc, không để file 500 MB kịp vào bộ nhớ.
 * fileSizeThreshold: dưới ngưỡng thì giữ trong RAM, trên thì ghi ra đĩa tạm.
 */
@WebServlet("/story")
@MultipartConfig(
        fileSizeThreshold = 512 * 1024,      // 512 KB
        maxFileSize       = 2L * 1024 * 1024,  // 2 MB mỗi file
        maxRequestSize    = 3L * 1024 * 1024)  // 3 MB cả request
public class StoryServlet extends HttpServlet {

    private StoryDAO storyDAO;
    private TagDAO tagDAO;
    private RatingDAO ratingDAO;
    private FollowDAO followDAO;
    private ChapterDAO chapterDAO;
    private CommentDAO commentDAO;
    private BookmarkDAO bookmarkDAO;
    private truyen.dao.ReadingProgressDAO progressDAO;
    private truyen.dao.ReviewDAO reviewDAO;
    private truyen.dao.UnlockDAO unlockDAO;
    private truyen.dao.WalletDAO walletDAO;

    /** Số truyện mỗi trang. Đọc từ context-param nên đổi được mà khỏi biên dịch lại. */
    private int pageSize = 24;

    /**
     * Số chương mỗi trang mục lục (trang 3).
     *
     * Để riêng, KHÔNG dùng chung pageSize: thẻ truyện là ô vuông có ảnh bìa
     * nên 24 cái đã đầy màn hình, còn chương chỉ là một hàng chữ — 50 hàng
     * vẫn gọn. Hai thứ khác kích thước thì không có lý do đếm bằng nhau.
     */
    private static final int CHAPTER_PAGE_SIZE = 50;

    /** Số thẻ gợi ý — 8 ở trang chi tiết (2 hàng x 4), 4 ở cuối trang đọc (1 hàng). */
    private static final int DETAIL_RECOMMEND_COUNT = 8;
    private static final int READER_RECOMMEND_COUNT = 4;

    @Override
    public void init() throws ServletException {
        storyDAO = new StoryDAO();
        tagDAO = new TagDAO();
        ratingDAO = new RatingDAO();
        followDAO = new FollowDAO();
        chapterDAO = new ChapterDAO();
        commentDAO = new CommentDAO();
        bookmarkDAO = new BookmarkDAO();
        progressDAO = new truyen.dao.ReadingProgressDAO();
        reviewDAO = new truyen.dao.ReviewDAO();
        unlockDAO = new truyen.dao.UnlockDAO();
        walletDAO = new truyen.dao.WalletDAO();

        String cfg = getServletContext().getInitParameter("pageSize");
        if (cfg != null) {
            try {
                pageSize = Integer.parseInt(cfg);
            } catch (NumberFormatException ignore) {
                // web.xml ghi sai số -> dùng mặc định, không làm sập app
            }
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        handle(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        handle(request, response);
    }

    private void handle(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        request.setCharacterEncoding("UTF-8");

        String action = request.getParameter("action");
        if (action == null) {
            if (request.getParameter("id") != null || request.getParameter("slug") != null) {
                action = "detail";
            } else {
                action = "list";
            }
        }

        String url;
        try {
            switch (action) {
                case "detail": url = detail(request, response); break;
                case "mine":   url = mine(request);             break;
                case "create": url = createOrEdit(request, response, true);  break;
                case "edit":   url = createOrEdit(request, response, false); break;
                case "delete": url = delete(request, response);  break;
                case "stats":   url = stats(request);             break;
                case "search":  url = search(request);            break;
                case "suggest": suggest(request, response);       return;
                case "recommend": recommend(request, response);   return;
                default:        url = list(request);              break;
            }
        } catch (SQLException e) {
            log("StoryServlet: lỗi truy vấn, action=" + action, e);

            /*
             * Phân biệt hai loại lỗi để báo cho đúng:
             *   - chưa cấu hình database  -> hướng dẫn cài đặt
             *   - lỗi truy vấn thật       -> xin lỗi chung chung
             * Báo sai loại thì người dùng đi tìm nhầm hướng. Trang Kho truyện
             * mà hiện "không tìm thấy truyện nào" trong khi thật ra chưa có DB
             * là kiểu thông báo gây hiểu lầm nhất.
             */
            String hint = DBConnection.checkConnection();
            request.setAttribute("message", hint != null
                    ? "Chưa kết nối được cơ sở dữ liệu. Xem hướng dẫn cài đặt ở trang chủ."
                    : "Không tải được dữ liệu. Vui lòng thử lại.");

            request.setAttribute("stories", java.util.Collections.emptyList());
            request.setAttribute("tags", java.util.Collections.emptyList());
            request.setAttribute("totalStories", 0);
            request.setAttribute("page", 1);
            request.setAttribute("totalPages", 1);
            url = "/WEB-INF/views/common/story/list.jsp";
        }

        if (url == null) {
            return;    // method con đã redirect hoặc sendError xong
        }

        request.setAttribute("contentPage", url);
        getServletContext()
                .getRequestDispatcher("/WEB-INF/views/layout/main.jsp")
                .forward(request, response);
    }

    // ---- CASE 02 + 03: danh sách, phân trang, lọc tag ----------------------

    private String list(HttpServletRequest request) throws SQLException {
        String tag = request.getParameter("tag");
        String keyword = trimOrEmpty(request.getParameter("q"));
        String sort = request.getParameter("sort");

        /*
         * Lọc theo tình trạng ra / hoàn thành.
         *
         * Không kiểm giá trị ở đây vì DAO đã so sánh với chuỗi hằng số: giá
         * trị lạ rơi vào "không lọc gì". Kiểm hai lần cũng được nhưng sẽ có
         * hai danh sách hợp lệ ở hai nơi, sớm muộn lệch nhau.
         */
        String progress = request.getParameter("progress");

        // Loại truyện: chữ / tranh. null = tất cả (xem Story.filterType).
        String storyType = Story.filterType(request.getParameter("type"));

        // Lọc số lượng chương: short (< 10), medium (10..50), long (> 50).
        String chaptersParam = request.getParameter("chapters");
        String chapters = ("short".equals(chaptersParam) || "medium".equals(chaptersParam) || "long".equals(chaptersParam))
                ? chaptersParam : null;

        int page = parseIntOr(request.getParameter("page"), 1);
        if (page < 1) {
            page = 1;   // ?page=-5 không được thành OFFSET âm
        }

        int total = storyDAO.countPage(tag, keyword, progress, storyType, chapters);
        int totalPages = Math.max(1, (int) Math.ceil(total / (double) pageSize));
        if (page > totalPages) {
            page = totalPages;
        }

        List<Story> stories = storyDAO.findPage(tag, keyword, sort, progress, storyType, chapters,
                                                (page - 1) * pageSize, pageSize);

        request.setAttribute("stories", stories);
        /*
         * Doc tu APPLICATION SCOPE thay vi chay SQL.
         * Danh sach the loai gan nhu khong doi ma trang nay ai cung mo —
         * xem ghi chu day du trong util/AppListener.
         */
        request.setAttribute("tags", AppListener.tags(getServletContext()));
        request.setAttribute("currentTag", tag);
        request.setAttribute("keyword", keyword);
        request.setAttribute("sort", sort);
        request.setAttribute("progress", progress);
        request.setAttribute("storyType", storyType == null ? null : storyType.toLowerCase());
        request.setAttribute("chapters", chapters);

        /*
         * Bản ĐÃ MÃ HOÁ URL của từ khoá và thể loại, cho list.jsp ghép vào href.
         *
         * Trước đây JSP ghép thẳng ${keyword} vào href — gõ từ khoá có dấu nháy
         * kép là phá được thuộc tính href và chèn được mã (XSS phản xạ: gửi ai đó
         * một link tìm kiếm là đủ). URLEncoder biến mọi ký tự đặc biệt thành %xx,
         * nên chuỗi ghép vào href không còn gì để "thoát ra".
         */
        request.setAttribute("keywordUrl", urlEncode(keyword));
        request.setAttribute("tagUrl", urlEncode(tag));
        request.setAttribute("page", page);
        request.setAttribute("totalPages", totalPages);
        request.setAttribute("totalStories", total);
        request.setAttribute("pageTitle", "Kho truyện");
        request.setAttribute("activeNav", "browse");
        return "/WEB-INF/views/common/story/list.jsp";
    }

    // ---- CASE 04: chi tiết -------------------------------------------------

    private String detail(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException {

        int id = parseIntOr(request.getParameter("id"), 0);
        if (id <= 0) {
            response.sendRedirect(request.getContextPath() + "/story");
            return null;
        }
        Story story = storyDAO.findById(id);

        if (story == null) {
            response.sendError(HttpServletResponse.SC_NOT_FOUND);
            return null;
        }

        User me = ServletHelper.currentUser(request);

        /*
         * TRUYỆN ĐÃ GỠ: 404 với mọi người, TRỪ ADMIN  (ISSUE-025).
         *
         * Trước đây 404 với tất cả. Nghe thì chặt chẽ, nhưng nó làm hỏng đúng
         * việc admin cần làm: trang xử lý báo cáo dựng link tới bình luận bị
         * tố, mà bình luận đó rất hay nằm trong truyện vừa bị gỡ vì một báo
         * cáo khác. Admin bấm vào thì nhận 404 — không xem được mình vừa gỡ
         * cái gì, cũng không đọc được bình luận đang phải phân xử.
         *
         * Người đọc thường vẫn nhận 404 y như cũ: truyện đã gỡ là biến mất,
         * không có cửa sau nào.
         */
        boolean isAdmin = me != null && me.isAdmin();
        if ("DELETED".equals(story.getStatus()) && !isAdmin) {
            response.sendError(HttpServletResponse.SC_NOT_FOUND);
            return null;
        }
        // Để JSP hiện dải cảnh báo "truyện này đã bị gỡ" cho admin.
        request.setAttribute("storyRemoved", "DELETED".equals(story.getStatus()));

        /*
         * Truyện DRAFT chỉ tác giả và admin xem được.
         * Trả 404 chứ không phải 403 — cố ý. 403 vô tình xác nhận "truyện này
         * CÓ tồn tại", còn 404 thì không tiết lộ gì cả.
         */
        if ("DRAFT".equals(story.getStatus()) && !canEdit(me, story)) {
            response.sendError(HttpServletResponse.SC_NOT_FOUND);
            return null;
        }

        /*
         * Truyện đã gỡ thì KHÔNG cộng lượt xem. Chỉ admin vào được, và đó là
         * đi xử lý báo cáo chứ không phải đọc truyện — cộng vào là làm bẩn số
         * liệu bằng chính thao tác quản trị của mình.
         */
        if (!"DELETED".equals(story.getStatus())) {
            storyDAO.increaseView(id);
        }

        /*
         * Ghi thêm một dòng vào nhật ký lượt xem.
         *
         * TÁCH RIÊNG khỏi increaseView() có chủ ý: bộ đếm view_count phải luôn
         * đúng vì nó hiện trên mọi thẻ truyện, còn nhật ký thiếu vài dòng thì
         * chỉ làm bảng xếp hạng tuần lệch chút — không đáng để cả trang chi
         * tiết hỏng theo. Vì vậy lỗi ở đây được nuốt, chỉ ghi log.
         */
        try {
            storyDAO.logView(id, me != null ? me.getId() : 0);
        } catch (SQLException e) {
            log("Không ghi được nhật ký lượt xem cho truyện " + id, e);
        }

        request.setAttribute("story", story);
        request.setAttribute("tags", tagDAO.findByStory(id));

        /*
         * MỤC LỤC CÓ PHÂN TRANG.
         *
         * Trước đây là chapterDAO.findByStory(id) — lấy sạch mọi chương. Với
         * truyện dài thì đó là hàng trăm hàng trong một trang, đẩy phần bình
         * luận xuống tận đáy.
         *
         * Tham số tên "cpage" chứ không phải "page": trang này còn có thể có
         * phân trang khác sau này, và "page" là tên quá chung để dành riêng
         * cho mục lục.
         */
        int total = chapterDAO.countByStory(id);
        int totalPages = Math.max(1, (int) Math.ceil(total / (double) CHAPTER_PAGE_SIZE));

        int cpage = parseIntOr(request.getParameter("cpage"), 1);
        if (cpage < 1) cpage = 1;
        if (cpage > totalPages) cpage = totalPages;

        /* Mặc định CŨ->MỚI: người mới vào truyện đọc từ chương 1. Ai đang
           theo truyện dài thì bật "Mới nhất trước" để thấy chương vừa ra. */
        boolean desc = "desc".equals(request.getParameter("order"));

        request.setAttribute("chapters", chapterDAO.findByStory(
                id, (cpage - 1) * CHAPTER_PAGE_SIZE, CHAPTER_PAGE_SIZE, desc));
        request.setAttribute("chapterTotal", total);
        request.setAttribute("cpage", cpage);
        request.setAttribute("cTotalPages", totalPages);
        request.setAttribute("cDesc", desc);

        request.setAttribute("firstChapter", chapterDAO.findFirstChapter(id));
        List<truyen.model.Comment> comments = commentDAO.findByStory(id);
        commentDAO.populateLikes(comments, me != null ? me.getId() : 0);
        request.setAttribute("comments", comments);
        request.setAttribute("canEdit", canEdit(me, story));
        if (me != null) {
            request.setAttribute("bookmarked", bookmarkDAO.exists(me.getId(), id));
            request.setAttribute("myRating", ratingDAO.findScore(me.getId(), id));
            request.setAttribute("following",
                    followDAO.isFollowing(me.getId(), story.getAuthorId()));
            request.setAttribute("unlockedChapterIds",
                    unlockDAO.findUnlockedChapterIds(me.getId(), id));
            truyen.model.ReadingProgress progress = progressDAO.find(me.getId(), id);
            if (progress != null && progress.getChapterId() > 0) {
                request.setAttribute("resumeChapterId", progress.getChapterId());
                request.setAttribute("resumeChapterNo", progress.getChapterNo());
            }
        }
        // Gợi ý truyện — MỘT khối, xem StoryDAO.findRecommendations(). Hỏng
        // thì bỏ qua — khối gợi ý biến mất, trang chi tiết vẫn đọc được.
        setRecommendations(request, id, DETAIL_RECOMMEND_COUNT);

        // Đánh giá chi tiết (ISSUE-022)
        try {
            int currentUserId = me != null ? me.getId() : 0;
            request.setAttribute("reviews", reviewDAO.findByStory(id, currentUserId));
            if (me != null) {
                request.setAttribute("myReview", reviewDAO.findByUserAndStory(me.getId(), id));
            }
        } catch (SQLException e) {
            log("Không lấy được bài đánh giá cho truyện " + id, e);
        }

        request.setAttribute("googleClientId", GoogleConfig.getClientId());
        request.setAttribute("googleDriveEnabled", GoogleConfig.isDriveEnabled());
        request.setAttribute("pageTitle", story.getTitle());
        request.setAttribute("activeNav", "browse");
        return "/WEB-INF/views/common/story/detail.jsp";
    }

    /** Truyện của tôi — gồm cả bản nháp. */
    private String mine(HttpServletRequest request) throws SQLException {
        User me = ServletHelper.currentUser(request);
        request.setAttribute("stories", storyDAO.findByAuthor(me.getId()));
        request.setAttribute("googleClientId", GoogleConfig.getClientId());
        request.setAttribute("googleDriveEnabled", GoogleConfig.isDriveEnabled());
        request.setAttribute("pageTitle", "Truyện của tôi");
        request.setAttribute("mine", true);
        return "/WEB-INF/views/user/story/mine.jsp";
    }

    /**
     * TRANG 16 — Thống kê truyện của tôi.
     *
     * Mỗi truyện một bộ ba số: lượt xem, số người đánh dấu, số bình luận.
     * Gọi DAO một lần cho mỗi truyện. Với tác giả có vài chục truyện thì chấp
     * nhận được; nếu có ai đăng hàng trăm truyện thì phải gộp thành một câu
     * SQL duy nhất — ghi lại đây để người sau biết chỗ cần sửa.
     */
    private String stats(HttpServletRequest request) throws SQLException {
        User me = ServletHelper.currentUser(request);
        List<Story> stories = storyDAO.findByAuthor(me.getId());

        /*
         * Map<id truyện, [xem, lưu, bình luận]>.
         *
         * Dùng Map thay vì nhét vào chính object Story: ba con số này chỉ
         * đúng một trang cần. Thêm ba trường vào Story là bắt 30 chỗ khác
         * trong dự án mang theo ba trường luôn bằng 0.
         */
        Map<Integer, int[]> stats = new LinkedHashMap<>();
        Map<Integer, Integer> storyIncomes = new LinkedHashMap<>();
        int totalViews = 0, totalSaves = 0, totalComments = 0, totalEarnings = 0;
        for (Story s : stories) {
            int[] row = storyDAO.statsOf(s.getId());
            stats.put(s.getId(), row);
            totalViews += row[0];
            totalSaves += row[1];
            totalComments += row[2];

            int inc = walletDAO.getStoryIncome(me.getId(), s.getId());
            storyIncomes.put(s.getId(), inc);
            totalEarnings += inc;
        }

        /*
         * Luot xem 14 ngay cua truyen DUOC XEM NHIEU NHAT.
         *
         * Ve mot bieu do cho MOI truyen thi tac gia co 10 truyen se nhan 10
         * bieu do nho xiu, khong doc duoc cai nao. Mot bieu do cua truyen chinh
         * tra loi dung cau hoi hay gap nhat: "dao nay co ai doc khong".
         */
        Story top = null;
        for (Story s2 : stories) {
            if (top == null || s2.getViewCount() > top.getViewCount()) top = s2;
        }
        if (top != null) {
            int[] d = storyDAO.viewsByDay(top.getId(), 14);
            int m = 0;
            for (int x : d) if (x > m) m = x;
            request.setAttribute("topStory", top);
            request.setAttribute("dViews", d);
            request.setAttribute("mViews", m);
            List<Chapter> topChapters = chapterDAO.findByStory(top.getId());
            request.setAttribute("topChapters", topChapters);
        }

        request.setAttribute("stories", stories);
        request.setAttribute("stats", stats);
        request.setAttribute("storyIncomes", storyIncomes);
        request.setAttribute("totalViews", totalViews);
        request.setAttribute("totalSaves", totalSaves);
        request.setAttribute("totalComments", totalComments);
        request.setAttribute("totalEarnings", totalEarnings);
        request.setAttribute("recentEarnings", walletDAO.findEarningsByAuthorId(me.getId(), 10));
        request.setAttribute("topPatrons", walletDAO.findTopPatronsByAuthor(me.getId(), 5));
        request.setAttribute("pageTitle", "Thống kê truyện của tôi");
        return "/WEB-INF/views/user/story/stats.jsp";
    }

    /** TRANG 2b — Tim kiem SAU trong noi dung chuong. */
    private String search(HttpServletRequest request) throws SQLException {
        String keyword = trimOrEmpty(request.getParameter("q"));

        request.setAttribute("keyword", keyword);
        request.setAttribute("keywordUrl", urlEncode(keyword));   // cho href, xem list()
        request.setAttribute("results", keyword.isEmpty()
                ? java.util.Collections.emptyList()
                : chapterDAO.searchContent(keyword, 30));

        request.setAttribute("pageTitle", keyword.isEmpty()
                ? "Tìm trong nội dung"
                : "Tìm: " + keyword);
        request.setAttribute("activeNav", "browse");
        return "/WEB-INF/views/common/story/search.jsp";
    }

    /**
     * Đặt recommendations + recReasons cho _partials/_recommend.jsp.
     * Gợi ý là phần phụ: hỏng CSDL thì khối gợi ý biến mất, trang vẫn chạy.
     */
    private void setRecommendations(HttpServletRequest request, int storyId, int limit) {
        try {
            truyen.model.RecommendationSet recs = storyDAO.findRecommendations(storyId, limit);
            request.setAttribute("recommendations", recs.getStories());
            request.setAttribute("recReasons", recs.getReasons());
        } catch (SQLException e) {
            log("Không lấy được gợi ý cho truyện " + storyId, e);
        }
    }

    /**
     * Khối gợi ý TRẦN (không khung trang) — trang đọc nạp bằng fetch() khi
     * người đọc tới cuối chương cuối cùng.
     *
     * Trả HTML do cùng mảnh _recommend.jsp dựng, không trả JSON: trang chi
     * tiết và trang đọc nhờ vậy hiện ĐÚNG một mẫu thẻ, và <c:out> lo escape
     * như mọi nơi khác — không có chỗ thứ hai sinh HTML bằng JavaScript.
     */
    private void recommend(HttpServletRequest request, HttpServletResponse response)
            throws IOException, ServletException {
        int id = parseIntOr(request.getParameter("id"), 0);
        setRecommendations(request, id, READER_RECOMMEND_COUNT);
        request.setAttribute("recTitle", "Đọc xong rồi? Thử truyện này nhé");
        response.setContentType("text/html;charset=UTF-8");
        getServletContext()
                .getRequestDispatcher("/WEB-INF/views/common/story/recommend.jsp")
                .forward(request, response);
    }

    /** Gợi ý tìm kiếm tức thì (Live Search Autocomplete) trả về JSON. */
    private void suggest(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException {
        String keyword = trimOrEmpty(request.getParameter("q"));
        response.setContentType("application/json;charset=UTF-8");

        if (keyword.length() < 2) {
            response.getWriter().write("[]");
            return;
        }

        List<Story> stories = storyDAO.findPage(null, keyword, "popular", null, 0, 5);
        StringBuilder json = new StringBuilder("[");
        for (int i = 0; i < stories.size(); i++) {
            Story s = stories.get(i);
            if (i > 0) json.append(",");
            json.append("{")
                .append("\"id\":").append(s.getId()).append(",")
                .append("\"title\":").append(jsonEscape(s.getTitle())).append(",")
                .append("\"author\":").append(jsonEscape(s.getAuthorName())).append(",")
                .append("\"cover\":").append(jsonEscape(s.getCoverUrl() != null ? s.getCoverUrl() : "")).append(",")
                .append("\"chapters\":").append(s.getChapterCount()).append(",")
                .append("\"views\":").append(s.getViewCount()).append(",")
                .append("\"completed\":").append(s.isCompleted())
                .append("}");
        }
        json.append("]");
        response.getWriter().write(json.toString());
    }

    private String jsonEscape(String s) {
        if (s == null) return "\"\"";
        StringBuilder sb = new StringBuilder("\"");
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            switch (c) {
                case '"': sb.append("\\\""); break;
                case '\\': sb.append("\\\\"); break;
                case '\b': sb.append("\\b"); break;
                case '\f': sb.append("\\f"); break;
                case '\n': sb.append("\\n"); break;
                case '\r': sb.append("\\r"); break;
                case '\t': sb.append("\\t"); break;
                default:
                    if (c < ' ') {
                        String hex = "000" + Integer.toHexString(c);
                        sb.append("\\u").append(hex.substring(hex.length() - 4));
                    } else {
                        sb.append(c);
                    }
            }
        }
        sb.append("\"");
        return sb.toString();
    }

    // ---- CASE 05: đăng / sửa ----------------------------------------------

    private String createOrEdit(HttpServletRequest request, HttpServletResponse response,
                                boolean isCreate) throws SQLException, IOException {

        User me = ServletHelper.currentUser(request);
        Story story;

        if (isCreate) {
            story = new Story();
            story.setAuthorId(me.getId());
            story.setStatus("DRAFT");
            story.setProgress("ONGOING");
        } else {
            story = storyDAO.findById(parseIntOr(request.getParameter("id"), 0));
            if (story == null) {
                response.sendRedirect(request.getContextPath() + "/story?action=mine");
                return null;
            }
            /*
             * KIỂM TRA QUYỀN SỞ HỮU — không chỉ kiểm vai trò.
             *
             * AuthFilter đã chặn khách chưa đăng nhập, nhưng nó KHÔNG biết
             * truyện id=6 là của ai. Thiếu đoạn này thì người dùng A sửa
             * ?id=5 thành ?id=6 là sửa được truyện của người dùng B.
             */
            if (!canEdit(me, story)) {
                response.sendError(HttpServletResponse.SC_FORBIDDEN);
                return null;
            }
        }

        // GET = chỉ hiện form
        if (!"POST".equals(request.getMethod())) {
            request.setAttribute("story", story);
            request.setAttribute("allTags", AppListener.tags(getServletContext()));
            request.setAttribute("selectedTags", isCreate
                    ? java.util.Collections.emptyList()
                    : tagDAO.findByStory(story.getId()));
            request.setAttribute("pageTitle", isCreate ? "Đăng truyện mới" : "Sửa truyện");
            return "/WEB-INF/views/user/story/form.jsp";
        }

        // POST = lưu
        String title = trimOrEmpty(request.getParameter("title"));
        String description = trimOrEmpty(request.getParameter("description"));
        String coverUrl = trimOrEmpty(request.getParameter("coverUrl"));

        String status = request.getParameter("status");
        String progress = request.getParameter("progress");
        String[] tagIds = request.getParameterValues("tagIds");

        story.setTitle(title);
        story.setDescription(description);
        story.setCoverUrl(coverUrl.isEmpty() ? null : coverUrl);
        story.setStatus("PUBLISHED".equals(status) ? "PUBLISHED" : "DRAFT");
        story.setProgress("COMPLETED".equals(progress) ? "COMPLETED" : "ONGOING");

        /*
         * LOẠI TRUYỆN chỉ đổi được khi truyện CHƯA CÓ CHƯƠNG NÀO.
         *
         * Chương truyện chữ lưu chữ trong chapters.content, chương truyện tranh
         * lưu ảnh trong chapter_pages. Đổi loại khi đã có chương là để lại một
         * loạt chương "chữ" trong truyện "tranh" (trang đọc hiện trắng), hoặc
         * ngược lại. Muốn đổi thì xoá hết chương trước — cố ý bắt làm tay.
         */
        String wantType = Story.normalizeType(request.getParameter("storyType"));
        if (!wantType.equals(story.getStoryType())) {
            if (!isCreate && story.getChapterCount() > 0) {
                return backToForm(request, story, isCreate,
                        "Truyện đã có chương nên không đổi được loại truyện. "
                        + "Muốn đổi, hãy xoá hết chương trước.");
            }
            story.setStoryType(wantType);
        }

        /*
         * ẢNH TẢI LÊN ĐÈ LÊN Ô DÁN LINK.
         *
         * Giữ CẢ HAI cách: dán link tiện khi ảnh đã có sẵn trên mạng, tải lên
         * cần cho ảnh nằm trong máy. Người dùng làm cả hai thì FILE THẮNG — họ
         * vừa chủ động chọn nó, còn ô link thường chỉ là giá trị cũ còn sót.
         *
         * Đặt SAU các lệnh story.setXxx() ở trên có chủ ý: lỗi tải ảnh thì
         * form hiện lại vẫn còn nguyên tiêu đề và mô tả người dùng đã gõ. Bắt
         * gõ lại cả bài mô tả chỉ vì chọn nhầm file là cách chắc chắn khiến
         * người ta bỏ cuộc.
         */
        try {
            String uploaded = UploadUtil.save(
                    request.getPart("coverFile"), getServletContext());
            if (uploaded != null) {
                story.setCoverUrl(uploaded);
            }
        } catch (UploadUtil.UploadException e) {
            // Lỗi người dùng sửa được: sai định dạng, quá nặng.
            return backToForm(request, story, isCreate, e.getMessage());
        } catch (Exception e) {
            // Lỗi phía máy chủ: hết đĩa, không có quyền ghi...
            log("Không lưu được ảnh bìa", e);
            return backToForm(request, story, isCreate,
                    "Không lưu được ảnh. Thử lại, hoặc dán link ảnh thay thế.");
        }

        if (title.isEmpty()) {
            return backToForm(request, story, isCreate,
                    "Tiêu đề không được để trống.");
        }
        if (title.length() > 200) {
            return backToForm(request, story, isCreate,
                    "Tiêu đề truyện tối đa 200 ký tự.");
        }
        if (description.length() > 5000) {
            return backToForm(request, story, isCreate,
                    "Mô tả truyện tối đa 5000 ký tự.");
        }
        if (progress != null && !progress.isEmpty() && !"ONGOING".equals(progress) && !"COMPLETED".equals(progress)) {
            return backToForm(request, story, isCreate,
                    "Tiến độ truyện không hợp lệ.");
        }

        story.setSlug(uniqueSlug(title, story.getId()));

        if (isCreate) {
            storyDAO.insert(story);
            request.getSession().setAttribute("flash", "🎉 Đã đăng truyện mới thành công!");
        } else {
            storyDAO.update(story);
            request.getSession().setAttribute("flash", "✍️ Đã lưu thay đổi truyện thành công!");
            // Thông báo kiểm duyệt nếu Admin/Editor can thiệp sửa truyện của tác giả khác
            if (me != null && me.getId() != story.getAuthorId() && story.getAuthorId() > 0) {
                new truyen.dao.NotificationDAO().sendNotification(
                    story.getAuthorId(),
                    story.getId(),
                    null,
                    "MODERATION",
                    "Truyện \"" + story.getTitle() + "\" của bạn vừa được Quản trị viên điều chỉnh nội dung/thông tin kiểm duyệt. Bạn có quyền gửi thư khiếu nại nếu có thắc mắc."
                );
            }
        }
        tagDAO.setTagsForStory(story.getId(), tagIds);
        try { new truyen.dao.AchievementDAO().getAchievements(story.getAuthorId(), null); }
        catch (SQLException ex) { log("Chưa cập nhật được thành tích sáng tác."); }

        // Post/Redirect/Get — F5 sau khi lưu không gửi lại form
        response.sendRedirect(request.getContextPath()
                + "/story?action=detail&id=" + story.getId());
        return null;
    }

    /**
     * Hiện lại form kèm một câu lỗi, GIỮ NGUYÊN mọi thứ người dùng đã gõ.
     *
     * Gom vào một chỗ vì ba nhánh lỗi đều cần đúng bốn thuộc tính này. Lặp ba
     * lần thì sớm muộn có nhánh quên allTags, và danh sách thể loại biến mất
     * đúng lúc người dùng đang bối rối vì lỗi.
     */
    private String backToForm(HttpServletRequest request, Story story,
                              boolean isCreate, String message) {
        request.setAttribute("message", message);
        request.setAttribute("story", story);
        List<Tag> allTags = AppListener.tags(getServletContext());
        request.setAttribute("allTags", allTags);

        String[] tagIds = request.getParameterValues("tagIds");
        List<Tag> selected = new ArrayList<>();
        if (tagIds != null && tagIds.length > 0) {
            Set<String> idSet = new HashSet<>(Arrays.asList(tagIds));
            if (allTags != null) {
                for (Tag t : allTags) {
                    if (idSet.contains(String.valueOf(t.getId()))) {
                        selected.add(t);
                    }
                }
            }
        } else if (!isCreate && story.getId() > 0) {
            try {
                selected = tagDAO.findByStory(story.getId());
            } catch (SQLException ignored) {}
        }
        request.setAttribute("selectedTags", selected);
        request.setAttribute("pageTitle", isCreate ? "Đăng truyện mới" : "Sửa truyện");
        return "/WEB-INF/views/user/story/form.jsp";
    }

    private String delete(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException {

        if (!"POST".equalsIgnoreCase(request.getMethod())) {
            response.sendError(HttpServletResponse.SC_METHOD_NOT_ALLOWED);
            return null;
        }

        Story story = storyDAO.findById(parseIntOr(request.getParameter("id"), 0));
        if (story == null) {
            response.sendError(HttpServletResponse.SC_NOT_FOUND);
            return null;
        }
        if (!canEdit(ServletHelper.currentUser(request), story)) {
            response.sendError(HttpServletResponse.SC_FORBIDDEN);
            return null;
        }
        storyDAO.softDelete(story.getId());   // xoá MỀM
        User me = ServletHelper.currentUser(request);
        if (me != null && me.getId() != story.getAuthorId() && story.getAuthorId() > 0) {
            new truyen.dao.NotificationDAO().sendNotification(
                story.getAuthorId(),
                story.getId(),
                null,
                "MODERATION",
                "Truyện \"" + story.getTitle() + "\" của bạn đã bị Quản trị viên gỡ bỏ. Bạn có quyền gửi thư khiếu nại nếu có thắc mắc."
            );
        }
        request.getSession().setAttribute("flash", "🗑️ Đã gỡ truyện thành công!");
        response.sendRedirect(request.getContextPath() + "/story?action=mine");
        return null;
    }

    // ---- tiện ích ----------------------------------------------------------

    /**
     * Sinh slug chưa ai dùng. Trùng thì thêm số: tien-hiep, tien-hiep-2...
     * Thử tối đa 50 lần rồi bỏ cuộc, tránh vòng lặp vô hạn nếu database lỗi.
     */
    /** Mã hoá một giá trị để ghép vào query string. null/rỗng -> "". */
    private static String urlEncode(String s) {
        if (s == null || s.isEmpty()) return "";
        return java.net.URLEncoder.encode(s, java.nio.charset.StandardCharsets.UTF_8);
    }

    private String uniqueSlug(String title, int exceptId) throws SQLException {
        String base = SlugUtil.toSlug(title);
        if (base.isEmpty()) {
            base = "truyen";
        }
        for (int n = 1; n <= 50; n++) {
            String candidate = SlugUtil.withSuffix(base, n);
            if (!storyDAO.slugExists(candidate, exceptId)) {
                return candidate;
            }
        }
        return base + "-" + System.currentTimeMillis();
    }

    /** Chủ truyện, admin hoặc người có quyền MANAGE_STORIES (Editor) thì được sửa. */
    private boolean canEdit(User user, Story story) {
        return ChapterAccess.canEdit(user, story);
    }

}
