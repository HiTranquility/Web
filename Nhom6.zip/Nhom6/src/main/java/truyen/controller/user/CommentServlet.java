package truyen.controller.user;

import java.io.IOException;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import truyen.util.DBConnection;
import truyen.util.JsonUtil;
import truyen.util.ServletHelper;

import static truyen.util.ServletHelper.parseIntOr;
import static truyen.util.ServletHelper.currentUser;
import static truyen.util.ServletHelper.trimOrEmpty;
import truyen.dao.CommentDAO;
import truyen.model.Comment;
import truyen.model.User;

/** CASE 07 — Bình luận. */
@WebServlet("/comment")
public class CommentServlet extends HttpServlet {

    /** Giới hạn độ dài — khớp với VARCHAR(1000) của cột content trong database. */
    private static final int MAX_LENGTH = 1000;

    private CommentDAO commentDAO;
    private truyen.dao.StoryDAO storyDAO;
    private truyen.dao.ChapterDAO chapterDAO;

    @Override
    public void init() throws ServletException {
        commentDAO = new CommentDAO();
        storyDAO = new truyen.dao.StoryDAO();
        chapterDAO = new truyen.dao.ChapterDAO();
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        request.setCharacterEncoding("UTF-8");

        String action = request.getParameter("action");
        if (action == null) {
            action = "add";
        }

        int storyId = parseIntOr(request.getParameter("storyId"), 0);
        int chapterId = parseIntOr(request.getParameter("chapterId"), 0);

        if ("like".equals(action)) {
            User me = ServletHelper.currentUser(request);
            if (me == null) {
                JsonUtil.sendJson(response, HttpServletResponse.SC_UNAUTHORIZED,
                        "{\"success\":false,\"needLogin\":true,\"message\":\"Vui lòng đăng nhập để thích bình luận.\"}");
                return;
            }
            int commentId = parseIntOr(request.getParameter("id"), 0);
            int count = commentDAO.toggleLike(commentId, me.getId());
            boolean liked = commentDAO.isLiked(commentId, me.getId());
            JsonUtil.sendJson(response, HttpServletResponse.SC_OK,
                    "{\"success\":true,\"liked\":" + liked + ",\"count\":" + count + ",\"message\":"
                    + JsonUtil.jsonEscape(liked ? "Đã thích bình luận!" : "Đã bỏ thích.") + "}");
            return;
        }

        try {
            if ("delete".equals(action)) {
                delete(request, response);
                return;
            } else {
                add(request, storyId, chapterId);
            }
        } catch (SQLException e) {
            log("CommentServlet: lỗi truy vấn, action=" + action, e);

            /*
             * KHONG nem trang 500 khi nguyen nhan la CHUA CO CSDL.
             *
             * O che do xem giao dien, moi lenh GHI deu that bai — dung nhu
             * thiet ke. Nhung tra ve trang 500 thi nguoi dung tuong web hong,
             * trong khi thuc te chi la chua chay setup-db.ps1.
             *
             * Noi ro nguyen nhan roi tra ho ve cho cu. Chi loi THAT SU bat ngo
             * moi dang mot trang 500.
             */
            if (!DBConnection.isReady()) {
                request.getSession().setAttribute("flash",
                        "Chưa nối cơ sở dữ liệu nên chưa lưu được. "
                        + "Chạy scripts\\setup-db.ps1 rồi tạo db.properties.");
                if (chapterId > 0) {
                    response.sendRedirect(request.getContextPath()
                            + "/chapter?action=read&id=" + chapterId);
                } else {
                    response.sendRedirect(request.getContextPath()
                            + "/story?action=detail&id=" + storyId);
                }
                return;
            }
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            return;
        }

        if (chapterId > 0) {
            response.sendRedirect(request.getContextPath()
                    + "/chapter?action=read&id=" + chapterId + "#comments");
        } else {
            response.sendRedirect(request.getContextPath()
                    + "/story?action=detail&id=" + storyId + "#comments");
        }
    }

    /**
     * Chỉ nhận POST. Không override doGet.
     *
     * Bình luận là hành động GHI, nên phải là POST — quy tắc chọn GET/POST ở
     * standards 01. Để GET thì người ta gửi được link
     * "/comment?action=add&content=spam" cho người khác bấm nhầm.
     */
    private void add(HttpServletRequest request, int storyId, int chapterId) throws SQLException {
        User me = ServletHelper.currentUser(request);
        String content = trimOrEmpty(request.getParameter("content"));

        // Rỗng thì bỏ qua lặng lẽ — không cần báo lỗi cho một ô trống
        if (me == null || storyId <= 0 || content.isEmpty()) {
            return;
        }

        // Kiểm tra chống spam bình luận (Rate Limiting / Cooldown)
        if (truyen.util.RateLimiter.isCommentSpam(me.getId())) {
            long remainingSec = truyen.util.RateLimiter.getCommentCooldownRemainingSeconds(me.getId());
            request.getSession().setAttribute("flashWarn",
                    "Bạn gửi bình luận quá nhanh. Vui lòng chờ " + remainingSec + " giây trước khi gửi tiếp.");
            return;
        }

        if (content.length() > MAX_LENGTH) {
            content = content.substring(0, MAX_LENGTH);
        }

        /*
         * Truyện phải TỒN TẠI và người này phải THẤY được (không phải nháp
         * của người khác, chưa bị gỡ); chương nếu có phải THUỘC đúng truyện.
         * Không kiểm thì storyId bịa ra đụng khoá ngoại -> trang 500, còn
         * chapterId của truyện khác làm bình luận hiện lạc sang chương lạ.
         */
        truyen.model.Story story = storyDAO.findById(storyId);
        if (!truyen.util.ChapterAccess.canSeeStory(me, story)) {
            return;
        }
        if (chapterId > 0) {
            truyen.model.Chapter ch = chapterDAO.findById(chapterId);
            if (ch == null || ch.getStoryId() != storyId) {
                return;
            }
        }

        Comment c = new Comment();
        c.setStoryId(storyId);
        if (chapterId > 0) {
            c.setChapterId(chapterId);
        }

        /*
         * parentId co thi day la TRA LOI, khong co thi la binh luan goc.
         *
         * Khong kiem o day xem cha co thuoc dung truyen nay khong —
         * CommentDAO.insert() da tra lai bang findById va tu ep ve goc.
         * Kiem hai lan cung mot thu o hai tang la cach chac chan de mot ngay
         * nao do hai noi lech nhau.
         */
        int parentId = parseIntOr(request.getParameter("parentId"), 0);
        c.setParentId(parentId > 0 ? parentId : null);
        c.setUserId(me.getId());
        c.setContent(content);
        commentDAO.insert(c);

        // Ghi nhận mốc thời gian bình luận thành công
        truyen.util.RateLimiter.recordComment(me.getId());

        // Gửi thông báo cho người viết bình luận cha hoặc tác giả truyện
        try {
            truyen.dao.NotificationDAO notifDAO = new truyen.dao.NotificationDAO();
            truyen.dao.StoryDAO sDAO = new truyen.dao.StoryDAO();
            truyen.model.Story s = sDAO.findById(storyId);
            String sTitle = s != null ? s.getTitle() : "truyện";

            Integer notifChapterId = c.getChapterId();
            String chapterDesc = "";
            if (notifChapterId != null && notifChapterId > 0) {
                truyen.dao.ChapterDAO chDAO = new truyen.dao.ChapterDAO();
                truyen.model.Chapter ch = chDAO.findById(notifChapterId);
                if (ch != null) {
                    chapterDesc = " trong chương " + ch.getChapterNo();
                }
            }

            if (c.getParentId() != null) {
                Comment parent = commentDAO.findById(c.getParentId());
                if (parent != null && parent.getUserId() != me.getId()) {
                    String msg = me.getName() + " đã trả lời bình luận của bạn" + chapterDesc + " trong truyện \"" + sTitle + "\"";
                    notifDAO.sendNotification(parent.getUserId(), storyId, notifChapterId, "SYSTEM", msg);
                }
            } else if (s != null && s.getAuthorId() != me.getId()) {
                String msg = me.getName() + " đã bình luận" + chapterDesc + " về truyện \"" + sTitle + "\"";
                notifDAO.sendNotification(s.getAuthorId(), storyId, notifChapterId, "SYSTEM", msg);
            }
        } catch (Exception e) {
            log("CommentServlet: không gửi được thông báo bình luận", e);
        }
    }

    /**
     * Ẩn bình luận. Người viết tự gỡ được, admin gỡ được của bất kỳ ai.
     *
     * KIỂM TRA QUYỀN SỞ HỮU — giống hệt truyện. Thiếu đoạn này thì ai cũng
     * xoá được bình luận của người khác chỉ bằng cách đổi id trong form.
     */
    private void delete(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException {

        User me = currentUser(request);
        Comment c = commentDAO.findById(parseIntOr(request.getParameter("id"), 0));

        if (c == null) {
            response.sendError(HttpServletResponse.SC_NOT_FOUND);
            return;
        }
        if (me == null || (me.getId() != c.getUserId() && !me.isAdmin() && !me.hasPermission("MODERATE_COMMENTS"))) {
            response.sendError(HttpServletResponse.SC_FORBIDDEN);
            return;
        }
        commentDAO.hide(c.getId());   // XOÁ MỀM — giữ lại làm bằng chứng

        int targetChapterId = c.getChapterId() != null ? c.getChapterId() : 0;
        int targetStoryId = c.getStoryId();
        if (targetChapterId > 0) {
            response.sendRedirect(request.getContextPath()
                    + "/chapter?action=read&id=" + targetChapterId + "#comments");
        } else {
            response.sendRedirect(request.getContextPath()
                    + "/story?action=detail&id=" + targetStoryId + "#comments");
        }
    }

}
