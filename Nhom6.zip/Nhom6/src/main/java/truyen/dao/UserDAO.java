package truyen.dao;

import truyen.util.DemoData;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.sql.Statement;

import truyen.model.User;
import truyen.util.DBConnection;

/**
 * Truy vấn bảng users.
 *
 * Theo đúng luật của tầng DAO (xem docs/standards/01-CODING_CONVENTIONS.md §2):
 * chỉ nói chuyện với database, không đụng request/response, ném SQLException
 * lên cho servlet xử lý.
 */
public class UserDAO {

    private static volatile boolean vipColumnChecked = false;
    private static volatile boolean hasVipColumn = true;

    public static void ensureVipColumn() {
        if (vipColumnChecked || !DBConnection.isReady()) return;
        vipColumnChecked = true;
        try (Connection con = DBConnection.get(); Statement st = con.createStatement()) {
            st.executeUpdate("ALTER TABLE users ADD COLUMN vip_expire_at DATETIME NULL");
            hasVipColumn = true;
        } catch (Exception ignored) {
            // Cột đã tồn tại hoặc không đủ quyền ALTER
        }
    }

    private static String getSelectBase() {
        ensureVipColumn();
        if (!hasVipColumn) {
            return "SELECT id, username, email, password_hash, display_name, avatar_url, "
                 + "       bio, role, status, ban_reason, created_at "
                 + "FROM users ";
        }
        return "SELECT id, username, email, password_hash, display_name, avatar_url, "
             + "       bio, role, status, ban_reason, created_at, vip_expire_at "
             + "FROM users ";
    }

    /**
     * Tìm theo username — dùng lúc đăng nhập.
     * Trả null nếu không có. Servlet phải kiểm null trước khi dùng.
     */
    public User findByUsername(String username) throws SQLException {
        // CHE DO XEM GIAO DIEN: chua co db.properties thi lay du lieu gia.
        if (!DBConnection.isReady()) return DemoData.userByUsername(username);
        ensureVipColumn();
        try {
            return queryUser(getSelectBase() + "WHERE username = ?", username);
        } catch (SQLException e) {
            if (e.getMessage() != null && e.getMessage().contains("vip_expire_at")) {
                hasVipColumn = false;
                return queryUser(getSelectBase() + "WHERE username = ?", username);
            }
            throw e;
        }
    }

    public User findById(int id) throws SQLException {
        // CHE DO XEM GIAO DIEN: chua co db.properties thi lay du lieu gia.
        if (!DBConnection.isReady()) return DemoData.user(id);
        ensureVipColumn();
        try {
            return queryUser(getSelectBase() + "WHERE id = ?", id);
        } catch (SQLException e) {
            if (e.getMessage() != null && e.getMessage().contains("vip_expire_at")) {
                hasVipColumn = false;
                return queryUser(getSelectBase() + "WHERE id = ?", id);
            }
            throw e;
        }
    }

    private User queryUser(String sql, Object param) throws SQLException {
        try (Connection con = DBConnection.get();
             PreparedStatement ps = con.prepareStatement(sql)) {
            if (param instanceof Integer) {
                ps.setInt(1, (Integer) param);
            } else {
                ps.setString(1, String.valueOf(param));
            }
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? mapRow(rs) : null;
            }
        }
    }

    /**
     * Username hoặc email đã có người dùng chưa — kiểm lúc đăng ký.
     *
     * Database đã có ràng buộc UNIQUE nên dù bỏ qua bước này cũng không tạo
     * được trùng. Nhưng kiểm trước thì báo lỗi tử tế được ("Tên này đã có
     * người dùng"), thay vì quăng SQLException khó hiểu cho người dùng xem.
     */
    public boolean exists(String username, String email) throws SQLException {
        String sql = "SELECT 1 FROM users WHERE username = ? OR email = ? LIMIT 1";
        try (Connection con = DBConnection.get();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, username);
            ps.setString(2, email);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next();
            }
        }
    }

    /** Thêm tài khoản mới, gán luôn id vừa sinh vào object user. */
    public void insert(User user) throws SQLException {
        ensureVipColumn();
        String sql = "INSERT INTO users "
                   + "(username, email, password_hash, display_name, avatar_url, role, status) "
                   + "VALUES (?, ?, ?, ?, ?, 'USER', 'ACTIVE')";
        try (Connection con = DBConnection.get();
             PreparedStatement ps = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            ps.setString(1, user.getUsername());
            ps.setString(2, user.getEmail());
            if (user.getPasswordHash() != null) {
                ps.setString(3, user.getPasswordHash());
            } else {
                ps.setNull(3, java.sql.Types.VARCHAR);
            }
            ps.setString(4, user.getDisplayName());
            ps.setString(5, safeTruncate(user.getAvatarUrl(), 1000));
            ps.executeUpdate();

            try (ResultSet keys = ps.getGeneratedKeys()) {
                if (keys.next()) {
                    user.setId(keys.getInt(1));
                }
            }
            if (user.getRole() == null) user.setRole("USER");
            if (user.getStatus() == null) user.setStatus("ACTIVE");
            if (user.getCreatedAt() == null) user.setCreatedAt(java.time.LocalDateTime.now());
        }
    }

    /**
     * Kiểm tra tài khoản có mật khẩu chưa (password_hash IS NOT NULL).
     * Phục vụ kiểm tra an toàn: không cho phép gỡ Google nếu chưa đặt mật khẩu.
     */
    public boolean hasPassword(int userId) throws SQLException {
        if (!DBConnection.isReady()) {
            User u = findById(userId);
            return u != null && u.hasPassword();
        }
        String sql = "SELECT password_hash FROM users WHERE id = ?";
        try (Connection con = DBConnection.get();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, userId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    String hash = rs.getString("password_hash");
                    return hash != null && !hash.trim().isEmpty();
                }
                return false;
            }
        }
    }

    /** Cập nhật ảnh đại diện người dùng. */
    public void updateAvatar(int userId, String avatarUrl) throws SQLException {
        String sql = "UPDATE users SET avatar_url = ? WHERE id = ?";
        try (Connection con = DBConnection.get();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, safeTruncate(avatarUrl, 1000));
            ps.setInt(2, userId);
            ps.executeUpdate();
        }
    }

    private static String safeTruncate(String val, int maxLen) {
        if (val == null) return null;
        return val.length() > maxLen ? val.substring(0, maxLen) : val;
    }

    /** Admin ban / bỏ ban một tài khoản (CASE 10). */
    public void updateStatus(int userId, String status, String reason) throws SQLException {
        String sql = "UPDATE users SET status = ?, ban_reason = ? WHERE id = ?";
        try (Connection con = DBConnection.get();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, status);
            ps.setString(2, reason);
            ps.setInt(3, userId);
            ps.executeUpdate();
        }
    }

    /**
     * Danh sách tài khoản kèm số truyện mỗi người — trang quản trị (TRANG 27).
     */
    public List<User> findAllWithStoryCount() throws SQLException {
        return searchWithStoryCount(null, null);
    }

    /**
     * Như trên nhưng có LỌC — trang 27.
     *
     * @param keyword tìm trong tên đăng nhập, tên hiển thị, email. null/rỗng = mọi người
     * @param status  ACTIVE hoặc BANNED. null/rỗng = mọi trạng thái
     *
     * VÌ SAO PHẢI CÓ Ô TÌM
     *   Câu cũ là "lấy 200 tài khoản mới nhất". Với vài chục người thì cuộn
     *   được, nhưng admin cần tìm MỘT người cụ thể — thường là người vừa bị
     *   báo cáo. Không có ô tìm thì phải Ctrl+F trên trang, mà cách đó chỉ
     *   thấy được trong 200 dòng đã tải; người thứ 201 là không tìm ra.
     *
     * DỰNG CÂU SQL BẰNG CÁCH NỐI CHUỖI — VẪN AN TOÀN
     *   Phần nối thêm là các mảnh CỐ ĐỊNH viết sẵn trong code, còn giá trị
     *   người dùng gõ luôn đi qua dấu ? và ps.setString(). Không có mẩu chữ
     *   nào của người dùng lọt vào câu lệnh, nên không có đường tiêm SQL.
     *   Sai lầm cần tránh là "... LIKE '%" + keyword + "%'" — chỗ đó mới chết.
     *
     * DẤU % ĐẶT Ở THAM SỐ, KHÔNG PHẢI TRONG CÂU SQL
     *   Viết LIKE ? rồi truyền "%kiem%" chứ không viết LIKE '%?%'. Cách sau
     *   không chạy: dấu ? nằm trong chuỗi nháy nên JDBC coi nó là ký tự thường,
     *   không phải chỗ điền tham số.
     */
    public List<User> searchWithStoryCount(String keyword, String status) throws SQLException {
        // CHE DO XEM GIAO DIEN: chua co db.properties thi lay du lieu gia.
        if (!DBConnection.isReady()) return DemoData.users();

        boolean hasKeyword = keyword != null && !keyword.trim().isEmpty();
        boolean hasStatus  = "ACTIVE".equals(status) || "BANNED".equals(status);

        StringBuilder sql = new StringBuilder(
            "SELECT u.*, "
          + "       (SELECT COUNT(*) FROM stories s "
          + "        WHERE s.author_id = u.id AND s.status != 'DELETED') AS story_count "
          + "FROM users u WHERE 1 = 1 ");

        /* "WHERE 1 = 1" ở trên để mọi điều kiện sau đều bắt đầu bằng AND.
           Không có nó thì phải nhớ điều kiện nào là cái đầu tiên để viết
           WHERE, các cái sau mới AND — đúng chỗ hay quên nhất khi thêm bộ lọc
           thứ ba. MySQL loại bỏ 1 = 1 khi tối ưu, không tốn gì. */
        if (hasKeyword) {
            sql.append("AND (u.username LIKE ? OR u.display_name LIKE ? OR u.email LIKE ?) ");
        }
        if (hasStatus) {
            sql.append("AND u.status = ? ");
        }
        sql.append("ORDER BY u.created_at DESC LIMIT 200");

        List<User> list = new ArrayList<>();
        try (Connection con = DBConnection.get();
             PreparedStatement ps = con.prepareStatement(sql.toString())) {

            int i = 1;
            if (hasKeyword) {
                String like = "%" + keyword.trim() + "%";
                ps.setString(i++, like);
                ps.setString(i++, like);
                ps.setString(i++, like);
            }
            if (hasStatus) {
                ps.setString(i++, status);
            }

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    User u = mapRow(rs);
                    u.setStoryCount(rs.getInt("story_count"));

                    // Chuoi bam KHONG duoc roi khoi tang dao khi khong can dung.
                    // Trang quan tri chi hien thi, khong xac thuc.
                    u.setPasswordHash(null);
                    list.add(u);
                }
            }
        }
        return list;
    }

    /**
     * Đổi vai trò USER <-> ADMIN (TRANG 27).
     *
     * Chỉ nhận đúng hai giá trị. Không kiểm thì một request tay chân có thể
     * đặt role = "SUPERADMIN", và mọi câu lệnh so sánh role trong dự án sẽ
     * lặng lẽ trả về false — tài khoản đó mất quyền mà không ai hiểu vì sao.
     */
    public void updateRole(int userId, String role) throws SQLException {
        if (!"ADMIN".equals(role) && !"USER".equals(role)) {
            throw new SQLException("Vai trò không hợp lệ: " + role);
        }
        String sql = "UPDATE users SET role = ? WHERE id = ?";
        try (Connection con = DBConnection.get();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, role);
            ps.setInt(2, userId);
            ps.executeUpdate();
        }
    }

    /** Người dùng tự sửa hồ sơ của mình (TRANG 15). */
    public void updateProfile(User user) throws SQLException {
        String sql = "UPDATE users SET display_name = ?, email = ?, "
                   + "avatar_url = ?, bio = ? WHERE id = ?";
        try (Connection con = DBConnection.get();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, user.getDisplayName());
            ps.setString(2, user.getEmail());
            ps.setString(3, user.getAvatarUrl());
            ps.setString(4, user.getBio());
            ps.setInt(5, user.getId());
            ps.executeUpdate();
        }
    }

    /** Đổi mật khẩu. Nhận chuỗi ĐÃ BĂM — DAO không băm hộ, không kiểm hộ. */
    public void updatePassword(int userId, String passwordHash) throws SQLException {
        String sql = "UPDATE users SET password_hash = ? WHERE id = ?";
        try (Connection con = DBConnection.get();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, passwordHash);
            ps.setInt(2, userId);
            ps.executeUpdate();
        }
    }

    /** Tìm theo email — dùng cho luồng quên mật khẩu (TRANG 21). */
    public User findByEmail(String email) throws SQLException {
        if (!DBConnection.isReady()) {
            for (User u : DemoData.users()) {
                if (u.getEmail().equalsIgnoreCase(email)) return u;
            }
            return null;
        }
        String sql = "SELECT * FROM users WHERE email = ?";
        try (Connection con = DBConnection.get();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, email);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? mapRow(rs) : null;
            }
        }
    }

    /**
     * Bảng xếp hạng tác giả nổi bật dựa trên tổng lượt xem và số người theo dõi (ISSUE-006).
     */
    public List<User> findTopAuthors(int limit) throws SQLException {
        if (!DBConnection.isReady()) {
            return DemoData.topAuthors(limit);
        }

        String sql =
            "SELECT u.id, u.username, u.email, u.password_hash, u.display_name, u.avatar_url, "
          + "       u.bio, u.role, u.status, u.ban_reason, u.created_at, "
          + "       COUNT(DISTINCT s.id) AS story_count, "
          + "       COALESCE(SUM(s.view_count), 0) AS total_views, "
          + "       (SELECT COUNT(*) FROM follows f WHERE f.author_id = u.id) AS follower_count "
          + "FROM users u "
          + "JOIN stories s ON s.author_id = u.id AND s.status = 'PUBLISHED' "
          + "WHERE u.status = 'ACTIVE' "
          + "GROUP BY u.id, u.username, u.email, u.password_hash, u.display_name, u.avatar_url, "
          + "         u.bio, u.role, u.status, u.ban_reason, u.created_at "
          + "ORDER BY total_views DESC, follower_count DESC "
          + "LIMIT ?";

        List<User> list = new ArrayList<>();
        try (Connection con = DBConnection.get();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, Math.max(1, limit));
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    User u = mapRow(rs);
                    u.setStoryCount(rs.getInt("story_count"));
                    u.setTotalViews(rs.getLong("total_views"));
                    u.setFollowerCount(rs.getInt("follower_count"));
                    list.add(u);
                }
            }
        }
        return list;
    }

    /* Đổi MỘT dòng ResultSet thành MỘT object User. Thêm cột mới thì sửa
       đúng chỗ này, không phải đi sửa từng method truy vấn. */
    private User mapRow(ResultSet rs) throws SQLException {
        User u = new User();
        u.setId(rs.getInt("id"));
        u.setUsername(rs.getString("username"));
        u.setEmail(rs.getString("email"));
        u.setPasswordHash(rs.getString("password_hash"));
        u.setDisplayName(rs.getString("display_name"));
        u.setAvatarUrl(rs.getString("avatar_url"));
        u.setBio(rs.getString("bio"));
        u.setRole(rs.getString("role"));
        u.setStatus(rs.getString("status"));
        u.setBanReason(rs.getString("ban_reason"));
        if (rs.getTimestamp("created_at") != null) {
            u.setCreatedAt(rs.getTimestamp("created_at").toLocalDateTime());
        }
        try {
            java.sql.Timestamp vipTs = rs.getTimestamp("vip_expire_at");
            if (vipTs != null) {
                u.setVipExpireAt(vipTs.toLocalDateTime());
            }
        } catch (SQLException ignored) {}
        return u;
    }

    /**
     * Nâng cấp / gia hạn Hội viên VIP thêm số ngày chỉ định.
     */
    public boolean upgradeVip(int userId, int days) throws SQLException {
        if (userId <= 0 || days <= 0 || !DBConnection.isReady()) return true;
        ensureVipColumn();
        String sql = "UPDATE users SET vip_expire_at = CASE "
                   + "    WHEN vip_expire_at IS NOT NULL AND vip_expire_at > NOW() "
                   + "    THEN DATE_ADD(vip_expire_at, INTERVAL ? DAY) "
                   + "    ELSE DATE_ADD(NOW(), INTERVAL ? DAY) "
                   + "END WHERE id = ?";
        try (Connection con = DBConnection.get();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, days);
            ps.setInt(2, days);
            ps.setInt(3, userId);
            return ps.executeUpdate() > 0;
        }
    }

    /**
     * Đếm tổng số chương truyện người này đã đọc tích luỹ.
     */
    public int countReadChapters(int userId) throws SQLException {
        if (userId <= 0 || !DBConnection.isReady()) return 0;
        ReadingActivityDAO.ensureTable();
        // Dữ liệu vị trí cũ chỉ được chuyển đổi một lần khi tạo bảng, không tính tiến độ chưa đủ điều kiện mới.
        String sql = "SELECT COUNT(*) FROM user_chapter_reads WHERE user_id = ?";
        try (Connection con = DBConnection.get(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, userId);
            try (ResultSet rs = ps.executeQuery()) { return rs.next() ? rs.getInt(1) : 0; }
        }
    }
}

