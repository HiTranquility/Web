package truyen.filter;

import java.io.IOException;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

/**
 * Đặt UTF-8 cho MỌI request, TRƯỚC khi bất kỳ ai đọc tham số.
 *
 * LỖI MÀ FILTER NÀY SỬA
 *   Tiếng Việt gõ vào form web bị hỏng khi lưu xuống CSDL:
 *       gõ  "Trả lời thử"
 *       lưu "Tráº£ lá»i thá»­"
 *
 *   Mỗi servlet đều đã gọi request.setCharacterEncoding("UTF-8") ở dòng đầu.
 *   Nhưng đặc tả Servlet nói rõ: lệnh đó chỉ có tác dụng khi gọi TRƯỚC lần
 *   đọc tham số ĐẦU TIÊN. Đọc rồi thì thân request đã được giải mã xong,
 *   đặt lại không đổi được gì nữa — và cũng KHÔNG báo lỗi.
 *
 *   Mà AuthFilter chạy trước servlet, và dòng đầu của nó là
 *       String action = request.getParameter("action");
 *   Chính dòng đó kích hoạt giải mã thân request bằng bảng mã mặc định
 *   ISO-8859-1. Servlet đặt UTF-8 sau đó là đã muộn.
 *
 * VÌ SAO CHỈ HỎNG POST, KHÔNG HỎNG GET
 *   Tham số trên URL do connector giải mã, và Tomcat 8 trở lên mặc định
 *   dùng UTF-8 cho URI. Nên tìm kiếm "cánh cổng" vẫn ra đúng.
 *   Chỉ THÂN của POST mới dùng bảng mã mặc định ISO-8859-1.
 *
 * VÌ SAO KHAI TRONG web.xml CHỨ KHÔNG DÙNG @WebFilter
 *   Thứ tự chạy giữa các filter khai bằng @WebFilter là KHÔNG XÁC ĐỊNH —
 *   đặc tả không hứa gì, mỗi container một kiểu. Mà filter này bắt buộc
 *   phải chạy trước AuthFilter, không có ngoại lệ.
 *
 *   Thứ tự các <filter-mapping> trong web.xml thì được bảo đảm, và Tomcat
 *   chạy nhóm khai trong web.xml trước nhóm khai bằng annotation. Vì vậy
 *   lớp này KHÔNG có @WebFilter — xem khai báo ở WEB-INF/web.xml.
 */
public class EncodingFilter implements Filter {

    private static final String UTF8 = "UTF-8";

    @Override
    public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain)
            throws IOException, ServletException {

        /*
         * Chỉ đặt khi CHƯA có. Nếu một filter khác đã đặt rồi thì gọi lại
         * cũng vô hại, nhưng kiểm trước cho rõ ý: filter này không giành
         * quyền, nó chỉ vá chỗ trống.
         */
        if (req.getCharacterEncoding() == null) {
            req.setCharacterEncoding(UTF8);
        }
        res.setCharacterEncoding(UTF8);

        if (res instanceof javax.servlet.http.HttpServletResponse) {
            javax.servlet.http.HttpServletResponse httpRes = (javax.servlet.http.HttpServletResponse) res;
            // HTML/JSON chứa tài khoản và CSRF token phải luôn lấy lại từ máy chủ.
            javax.servlet.http.HttpServletRequest httpReq = (javax.servlet.http.HttpServletRequest) req;
            String path = httpReq.getServletPath();
            if (path == null || !path.startsWith("/assets/")) {
                httpRes.setHeader("Cache-Control", "no-store, private");
                httpRes.setHeader("Pragma", "no-cache");
                httpRes.setDateHeader("Expires", 0);
            }
            // Bảo vệ an toàn HTTP Headers (OWASP Security Standards)
            httpRes.setHeader("X-Content-Type-Options", "nosniff");
            httpRes.setHeader("X-Frame-Options", "SAMEORIGIN");
            httpRes.setHeader("Referrer-Policy", "strict-origin-when-cross-origin");
            httpRes.setHeader("X-XSS-Protection", "1; mode=block");
            httpRes.setHeader("Permissions-Policy", "camera=(), microphone=(), geolocation=(), payment=()");
            httpRes.setHeader("Content-Security-Policy",
                    "default-src 'self'; "
                    + "script-src 'self' 'unsafe-inline' 'unsafe-eval' https://www.google.com https://www.gstatic.com https://apis.google.com; "
                    + "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; "
                    + "font-src 'self' https://fonts.gstatic.com data:; "
                    + "img-src 'self' data: blob: https:; "
                    + "media-src 'self' blob: data:; "
                    + "connect-src 'self' https://www.google.com https://identitytoolkit.googleapis.com https://securetoken.googleapis.com https://*.googleapis.com; "
                    + "frame-src 'self' https://www.google.com https://*.firebaseapp.com;");
        }

        chain.doFilter(req, res);
    }

    @Override
    public void init(javax.servlet.FilterConfig config) { }

    @Override
    public void destroy() { }
}
